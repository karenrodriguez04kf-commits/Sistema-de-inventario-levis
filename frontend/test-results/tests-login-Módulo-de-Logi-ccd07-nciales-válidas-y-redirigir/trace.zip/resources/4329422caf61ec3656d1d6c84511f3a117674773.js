import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/home.jsx");import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=66677652"; const React = __vite__cjsImport0_react; const useEffect = __vite__cjsImport0_react["useEffect"];
import { Link, Outlet, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=66677652";
import "/src/Home.css";
var _jsxFileName = "C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/home.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=66677652"; const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport3_react_jsxDevRuntime["Fragment"];
var _s = $RefreshSig$();
const Home = () => {
	_s();
	const navigate = useNavigate();
	// 1. Obtenemos el rol y el token
	const rol = localStorage.getItem("rol");
	const token = localStorage.getItem("token");
	// 2. Seguridad: Si no hay token, lo mandamos al login de una
	useEffect(() => {
		if (!token) {
			navigate("/");
		}
	}, [token, navigate]);
	const handleLogout = () => {
		localStorage.clear();
		navigate("/");
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "home-wrapper",
		children: [/* @__PURE__ */ _jsxDEV("nav", {
			className: "navbar",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "nav-logo",
				onClick: () => navigate("/home"),
				children: "LEVI'S"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 28,
				columnNumber: 17
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "nav-links",
				children: [
					/* @__PURE__ */ _jsxDEV(Link, {
						to: "/home/catalogo",
						className: "nav-item",
						children: "CATÁLOGO"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 34,
						columnNumber: 21
					}, this),
					rol === "admin" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
						/* @__PURE__ */ _jsxDEV(Link, {
							to: "/home/inventario",
							className: "nav-item",
							children: "INVENTARIO"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 39,
							columnNumber: 29
						}, this),
						/* @__PURE__ */ _jsxDEV(Link, {
							to: "/home/usuarios",
							className: "nav-item",
							children: "GESTIÓN DE USUARIOS"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 40,
							columnNumber: 28
						}, this),
						/* @__PURE__ */ _jsxDEV(Link, {
							to: "/home/reporte-ventas",
							className: "nav-item",
							children: "REPORTE DE VENTAS"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 41,
							columnNumber: 29
						}, this),
						/* @__PURE__ */ _jsxDEV(Link, {
							to: "/home/proveedores",
							className: "nav-item",
							children: "PROVEEDORES"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 42,
							columnNumber: 29
						}, this)
					] }, void 0, true),
					/* @__PURE__ */ _jsxDEV(Link, {
						to: "/home/perfil",
						className: "nav-item",
						children: "MI PERFIL"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 47,
						columnNumber: 21
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: handleLogout,
						className: "btn-logout-nav",
						children: "CERRAR SESIÓN"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 49,
						columnNumber: 21
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 32,
				columnNumber: 17
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 26,
			columnNumber: 13
		}, this), /* @__PURE__ */ _jsxDEV("main", {
			className: "main-content",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "content-container",
				children: /* @__PURE__ */ _jsxDEV(Outlet, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 58,
					columnNumber: 21
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 56,
				columnNumber: 17
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 55,
			columnNumber: 13
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 25,
		columnNumber: 9
	}, this);
};
_s(Home, "r6Y4cxllxeSwx3b1nMjC3P/JySI=", false, function() {
	return [useNavigate];
});
_c = Home;
export default Home;
var _c;
$RefreshReg$(_c, "Home");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/home.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/home.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/home.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/home.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGlCQUFpQjtBQUNqQyxTQUFTLE1BQU0sUUFBUSxtQkFBbUI7QUFDMUMsT0FBTzs7OztBQUVQLE1BQU0sYUFBYTs7Q0FDZixNQUFNLFdBQVcsYUFBYTs7Q0FHOUIsTUFBTSxNQUFNLGFBQWEsUUFBUSxNQUFNO0NBQ3ZDLE1BQU0sUUFBUSxhQUFhLFFBQVEsUUFBUTs7QUFHM0MsaUJBQWdCO0FBQ1osTUFBSSxDQUFDLE9BQU87QUFDUixZQUFTLElBQUk7O0lBRWxCLENBQUMsT0FBTyxTQUFTLENBQUM7Q0FFckIsTUFBTSxxQkFBcUI7QUFDdkIsZUFBYSxPQUFPO0FBQ3BCLFdBQVMsSUFBSTs7QUFHakIsUUFDSSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBQ0ksd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUVJLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO0lBQVcsZUFBZSxTQUFTLFFBQVE7Y0FBRTtJQUV0RDs7OzthQUVOLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FFSSx3QkFBQyxNQUFEO01BQU0sSUFBRztNQUFpQixXQUFVO2dCQUFXO01BQWU7Ozs7O0tBRzdELFFBQVEsV0FDTDtNQUNJLHdCQUFDLE1BQUQ7T0FBTSxJQUFHO09BQW1CLFdBQVU7aUJBQVc7T0FBaUI7Ozs7O01BQ25FLHdCQUFDLE1BQUQ7T0FBTSxJQUFHO09BQWlCLFdBQVU7aUJBQVc7T0FBMEI7Ozs7O01BQ3hFLHdCQUFDLE1BQUQ7T0FBTSxJQUFHO09BQXVCLFdBQVU7aUJBQVc7T0FBd0I7Ozs7O01BQzdFLHdCQUFDLE1BQUQ7T0FBTSxJQUFHO09BQW9CLFdBQVU7aUJBQVc7T0FBa0I7Ozs7O01BQ3JFO0tBSVAsd0JBQUMsTUFBRDtNQUFNLElBQUc7TUFBZSxXQUFVO2dCQUFXO01BQWdCOzs7OztLQUU3RCx3QkFBQyxVQUFEO01BQVEsU0FBUztNQUFjLFdBQVU7Z0JBQWlCO01BRWpEOzs7OztLQUNQOzs7OztZQUNKOzs7OztZQUVOLHdCQUFDLFFBQUQ7R0FBTSxXQUFVO2FBQ1osd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FFWCx3QkFBQyxRQUFELEVBQVU7Ozs7O0lBQ1I7Ozs7O0dBQ0g7Ozs7V0FDTDs7Ozs7Ozs7Ozs7QUFJZCxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImhvbWUuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IExpbmssIE91dGxldCwgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcclxuaW1wb3J0ICcuL0hvbWUuY3NzJzsgXHJcblxyXG5jb25zdCBIb21lID0gKCkgPT4ge1xyXG4gICAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xyXG4gICAgXHJcbiAgICAvLyAxLiBPYnRlbmVtb3MgZWwgcm9sIHkgZWwgdG9rZW5cclxuICAgIGNvbnN0IHJvbCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKCdyb2wnKTtcclxuICAgIGNvbnN0IHRva2VuID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ3Rva2VuJyk7XHJcblxyXG4gICAgLy8gMi4gU2VndXJpZGFkOiBTaSBubyBoYXkgdG9rZW4sIGxvIG1hbmRhbW9zIGFsIGxvZ2luIGRlIHVuYVxyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBpZiAoIXRva2VuKSB7XHJcbiAgICAgICAgICAgIG5hdmlnYXRlKCcvJyk7XHJcbiAgICAgICAgfVxyXG4gICAgfSwgW3Rva2VuLCBuYXZpZ2F0ZV0pO1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZUxvZ291dCA9ICgpID0+IHtcclxuICAgICAgICBsb2NhbFN0b3JhZ2UuY2xlYXIoKTsgLy8gQm9ycmEgVG9rZW4sIFJvbCBlIElEIGRlIHVzdWFyaW9cclxuICAgICAgICBuYXZpZ2F0ZSgnLycpO1xyXG4gICAgfTtcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaG9tZS13cmFwcGVyXCI+XHJcbiAgICAgICAgICAgIDxuYXYgY2xhc3NOYW1lPVwibmF2YmFyXCI+XHJcbiAgICAgICAgICAgICAgICB7LyogTG9nbzogYWwgZGFybGUgY2xpY2sgdnVlbHZlIGFsIGluaWNpbyBkZWwgaG9tZSAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibmF2LWxvZ29cIiBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZSgnL2hvbWUnKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgTEVWSSdTXHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJuYXYtbGlua3NcIj5cclxuICAgICAgICAgICAgICAgICAgICB7LyogQUNDRVNPIFVOSVZFUlNBTDogVG9kb3MgdmVuIGVsIGNhdMOhbG9nbyAqL31cclxuICAgICAgICAgICAgICAgICAgICA8TGluayB0bz1cIi9ob21lL2NhdGFsb2dvXCIgY2xhc3NOYW1lPVwibmF2LWl0ZW1cIj5DQVTDgUxPR088L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIEFDQ0VTTyBSRVNUUklOR0lETzogU29sbyBzaSBlbCByb2wgZ3VhcmRhZG8gZXMgJ2FkbWluJyAqL31cclxuICAgICAgICAgICAgICAgICAgICB7cm9sID09PSAnYWRtaW4nICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIHRvPVwiL2hvbWUvaW52ZW50YXJpb1wiIGNsYXNzTmFtZT1cIm5hdi1pdGVtXCI+SU5WRU5UQVJJTzwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmsgdG89XCIvaG9tZS91c3Vhcmlvc1wiIGNsYXNzTmFtZT1cIm5hdi1pdGVtXCI+R0VTVEnDk04gREUgVVNVQVJJT1M8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGluayB0bz1cIi9ob21lL3JlcG9ydGUtdmVudGFzXCIgY2xhc3NOYW1lPVwibmF2LWl0ZW1cIj5SRVBPUlRFIERFIFZFTlRBUzwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIHRvPVwiL2hvbWUvcHJvdmVlZG9yZXNcIiBjbGFzc05hbWU9XCJuYXYtaXRlbVwiPlBST1ZFRURPUkVTPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBBQ0NFU08gREUgVVNVQVJJTzogVmVyIHN1IHByb3BpbyBwZXJmaWwgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPExpbmsgdG89XCIvaG9tZS9wZXJmaWxcIiBjbGFzc05hbWU9XCJuYXYtaXRlbVwiPk1JIFBFUkZJTDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e2hhbmRsZUxvZ291dH0gY2xhc3NOYW1lPVwiYnRuLWxvZ291dC1uYXZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQ0VSUkFSIFNFU0nDk05cclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L25hdj5cclxuXHJcbiAgICAgICAgICAgIDxtYWluIGNsYXNzTmFtZT1cIm1haW4tY29udGVudFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250ZW50LWNvbnRhaW5lclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBBcXXDrSBSZWFjdCBSb3V0ZXIgcmVuZGVyaXphIGVsIGNvbXBvbmVudGUgaGlqbyAoQ2F0YWxvZ28sIEludmVudGFyaW8sIGV0Yy4pICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxPdXRsZXQgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L21haW4+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgSG9tZTsiXX0=