import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/proveedores.jsx");import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=66677652"; const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];
import api from "/src/api.js";
import "/src/Proveedores.css";
var _jsxFileName = "C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/proveedores.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=66677652"; const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
const Proveedores = () => {
	_s();
	const [proveedores, setProveedores] = useState([]);
	const [nombre, setNombre] = useState("");
	const [rol_proveedor, setRolProveedor] = useState("");
	const [correo, setCorreo] = useState("");
	const [editandoId, setEditandoId] = useState(null);
	useEffect(() => {
		cargarProveedores();
	}, []);
	const cargarProveedores = async () => {
		try {
			const res = await api.get("/proveedores");
			setProveedores(res.data);
		} catch (err) {
			console.error("Error al cargar proveedores:", err);
		}
	};
	const handleSubmit = async (e) => {
		e.preventDefault();
		if (!nombre.trim()) return alert("El nombre es obligatorio");
		if (!correo.trim()) return alert("El correo es obligatorio");
		if (!rol_proveedor.trim()) return alert("El rol del proveedor es obligatorio");
		const datosProveedor = {
			nombre,
			correo,
			rol_proveedor
		};
		try {
			if (editandoId) {
				await api.put(`/proveedores/${editandoId}`, datosProveedor);
				setEditandoId(null);
				alert("✅ Proveedor actualizado");
			} else {
				await api.post("/proveedores", datosProveedor);
				alert("✅ Proveedor registrado");
			}
			setNombre("");
			setCorreo("");
			setRolProveedor("");
			cargarProveedores();
		} catch (err) {
			console.error("Error:", err);
			alert("❌ Error en la operación");
		}
	};
	const iniciarEdicion = (proveedor) => {
		setNombre(proveedor.nombre);
		setCorreo(proveedor.correo);
		setRolProveedor(proveedor.rol_proveedor);
		setEditandoId(proveedor.id_proveedor);
	};
	const eliminarProveedor = async (id) => {
		if (window.confirm("¿Estás seguro de eliminar este proveedor?")) {
			try {
				await api.delete(`/proveedores/${id}`);
				cargarProveedores();
			} catch (err) {
				alert("❌ Error al eliminar");
			}
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "clientes-page",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "clientes-header",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "logo-levis",
					children: "LEVI'S"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 72,
					columnNumber: 17
				}, this), /* @__PURE__ */ _jsxDEV("div", { children: /* @__PURE__ */ _jsxDEV("span", { children: "GESTIÓN DE PROVEEDORES" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 73,
					columnNumber: 22
				}, this) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 73,
					columnNumber: 17
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 71,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("h2", {
				className: "seccion-titulo",
				children: "Administración de Proveedores"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 76,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("form", {
				onSubmit: handleSubmit,
				className: "clientes-form",
				children: [
					/* @__PURE__ */ _jsxDEV("input", {
						type: "text",
						placeholder: "NOMBRE",
						value: nombre,
						onChange: (e) => setNombre(e.target.value),
						required: true
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 79,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						type: "email",
						placeholder: "CORREO",
						value: correo,
						onChange: (e) => setCorreo(e.target.value),
						required: true
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 86,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						type: "text",
						placeholder: "ROL DEL PROVEEDOR",
						value: rol_proveedor,
						onChange: (e) => setRolProveedor(e.target.value),
						required: true
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 93,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						type: "submit",
						className: `btn-submit ${editandoId ? "btn-editar" : "btn-agregar"}`,
						children: editandoId ? "GUARDAR CAMBIOS" : "+ AGREGAR PROVEEDOR"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 100,
						columnNumber: 17
					}, this),
					editandoId && /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: () => {
							setEditandoId(null);
							setNombre("");
							setCorreo("");
							setRolProveedor("");
						},
						className: "btn-cancelar",
						children: "Cancelar"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 104,
						columnNumber: 21
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 78,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "tabla-container",
				children: /* @__PURE__ */ _jsxDEV("table", {
					className: "tabla-clientes",
					children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", { children: [
						/* @__PURE__ */ _jsxDEV("th", { children: "ID" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 119,
							columnNumber: 29
						}, this),
						/* @__PURE__ */ _jsxDEV("th", { children: "NOMBRE" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 120,
							columnNumber: 29
						}, this),
						/* @__PURE__ */ _jsxDEV("th", { children: "CORREO" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 121,
							columnNumber: 29
						}, this),
						/* @__PURE__ */ _jsxDEV("th", { children: "ROL" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 122,
							columnNumber: 29
						}, this),
						/* @__PURE__ */ _jsxDEV("th", { children: "ACCIONES" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 123,
							columnNumber: 29
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 118,
						columnNumber: 25
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 117,
						columnNumber: 21
					}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: proveedores.map((proveedor) => /* @__PURE__ */ _jsxDEV("tr", { children: [
						/* @__PURE__ */ _jsxDEV("td", { children: ["#", proveedor.id_proveedor] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 129,
							columnNumber: 33
						}, this),
						/* @__PURE__ */ _jsxDEV("td", { children: proveedor.nombre }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 130,
							columnNumber: 33
						}, this),
						/* @__PURE__ */ _jsxDEV("td", { children: proveedor.correo }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 131,
							columnNumber: 33
						}, this),
						/* @__PURE__ */ _jsxDEV("td", { children: proveedor.rol_proveedor }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 132,
							columnNumber: 33
						}, this),
						/* @__PURE__ */ _jsxDEV("td", { children: [/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => iniciarEdicion(proveedor),
							className: "btn-tabla btn-edit",
							children: "Editar"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 134,
							columnNumber: 37
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => eliminarProveedor(proveedor.id_proveedor),
							className: "btn-tabla btn-delete",
							children: "Eliminar"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 135,
							columnNumber: 37
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 133,
							columnNumber: 33
						}, this)
					] }, proveedor.id_proveedor, true, {
						fileName: _jsxFileName,
						lineNumber: 128,
						columnNumber: 29
					}, this)) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 126,
						columnNumber: 21
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 116,
					columnNumber: 17
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 115,
				columnNumber: 13
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 70,
		columnNumber: 9
	}, this);
};
_s(Proveedores, "oBBj5Ae76CkbUUis4umuzeNcygM=");
_c = Proveedores;
export default Proveedores;
var _c;
$RefreshReg$(_c, "Proveedores");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/proveedores.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/proveedores.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/proveedores.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/proveedores.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQWlCO0FBQzNDLE9BQU8sU0FBUztBQUNoQixPQUFPOzs7O0FBRVAsTUFBTSxvQkFBb0I7O0NBQ3RCLE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEVBQUUsQ0FBQztDQUNsRCxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsR0FBRztDQUN4QyxNQUFNLENBQUMsZUFBZSxtQkFBbUIsU0FBUyxHQUFHO0NBQ3JELE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBUyxHQUFHO0NBQ3hDLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLEtBQUs7QUFFbEQsaUJBQWdCO0FBQ1oscUJBQW1CO0lBQ3BCLEVBQUUsQ0FBQztDQUVOLE1BQU0sb0JBQW9CLFlBQVk7QUFDbEMsTUFBSTtHQUNBLE1BQU0sTUFBTSxNQUFNLElBQUksSUFBSSxlQUFlO0FBQ3pDLGtCQUFlLElBQUksS0FBSztXQUNuQixLQUFLO0FBQ1YsV0FBUSxNQUFNLGdDQUFnQyxJQUFJOzs7Q0FJMUQsTUFBTSxlQUFlLE9BQU8sTUFBTTtBQUM5QixJQUFFLGdCQUFnQjtBQUNsQixNQUFJLENBQUMsT0FBTyxNQUFNLENBQUUsUUFBTyxNQUFNLDJCQUEyQjtBQUM1RCxNQUFJLENBQUMsT0FBTyxNQUFNLENBQUUsUUFBTyxNQUFNLDJCQUEyQjtBQUM1RCxNQUFJLENBQUMsY0FBYyxNQUFNLENBQUUsUUFBTyxNQUFNLHNDQUFzQztFQUU5RSxNQUFNLGlCQUFpQjtHQUFFO0dBQVE7R0FBUTtHQUFlO0FBQ3hELE1BQUk7QUFDQSxPQUFJLFlBQVk7QUFDWixVQUFNLElBQUksSUFBSSxnQkFBZ0IsY0FBYyxlQUFlO0FBQzNELGtCQUFjLEtBQUs7QUFDbkIsVUFBTSwwQkFBMEI7VUFDN0I7QUFDSCxVQUFNLElBQUksS0FBSyxnQkFBZ0IsZUFBZTtBQUM5QyxVQUFNLHlCQUF5Qjs7QUFFbkMsYUFBVSxHQUFHO0FBQ2IsYUFBVSxHQUFHO0FBQ2IsbUJBQWdCLEdBQUc7QUFDbkIsc0JBQW1CO1dBQ2QsS0FBSztBQUNWLFdBQVEsTUFBTSxVQUFVLElBQUk7QUFDNUIsU0FBTSwwQkFBMEI7OztDQUl4QyxNQUFNLGtCQUFrQixjQUFjO0FBQ2xDLFlBQVUsVUFBVSxPQUFPO0FBQzNCLFlBQVUsVUFBVSxPQUFPO0FBQzNCLGtCQUFnQixVQUFVLGNBQWM7QUFDeEMsZ0JBQWMsVUFBVSxhQUFhOztDQUd6QyxNQUFNLG9CQUFvQixPQUFPLE9BQU87QUFDcEMsTUFBSSxPQUFPLFFBQVEsNENBQTRDLEVBQUU7QUFDN0QsT0FBSTtBQUNBLFVBQU0sSUFBSSxPQUFPLGdCQUFnQixLQUFLO0FBQ3RDLHVCQUFtQjtZQUNkLEtBQUs7QUFDVixVQUFNLHNCQUFzQjs7OztBQUt4QyxRQUNJLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FDSSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0ksd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBYTtLQUFZOzs7O2NBQ3hDLHdCQUFDLE9BQUQsWUFBSyx3QkFBQyxRQUFELFlBQU0sMEJBQTZCOzs7O2NBQU07Ozs7YUFDNUM7Ozs7OztHQUVOLHdCQUFDLE1BQUQ7SUFBSSxXQUFVO2NBQWlCO0lBQWtDOzs7OztHQUVqRSx3QkFBQyxRQUFEO0lBQU0sVUFBVTtJQUFjLFdBQVU7Y0FBeEM7S0FDSSx3QkFBQyxTQUFEO01BQ0ksTUFBSztNQUNMLGFBQVk7TUFDWixPQUFPO01BQ1AsV0FBVSxNQUFLLFVBQVUsRUFBRSxPQUFPLE1BQU07TUFDeEM7TUFDRjs7Ozs7S0FDRix3QkFBQyxTQUFEO01BQ0ksTUFBSztNQUNMLGFBQVk7TUFDWixPQUFPO01BQ1AsV0FBVSxNQUFLLFVBQVUsRUFBRSxPQUFPLE1BQU07TUFDeEM7TUFDRjs7Ozs7S0FDRix3QkFBQyxTQUFEO01BQ0ksTUFBSztNQUNMLGFBQVk7TUFDWixPQUFPO01BQ1AsV0FBVSxNQUFLLGdCQUFnQixFQUFFLE9BQU8sTUFBTTtNQUM5QztNQUNGOzs7OztLQUNGLHdCQUFDLFVBQUQ7TUFBUSxNQUFLO01BQVMsV0FBVyxjQUFjLGFBQWEsZUFBZTtnQkFDdEUsYUFBYSxvQkFBb0I7TUFDN0I7Ozs7O0tBQ1IsY0FDRyx3QkFBQyxVQUFEO01BQVEsTUFBSztNQUFTLGVBQWU7QUFDakMscUJBQWMsS0FBSztBQUNuQixpQkFBVSxHQUFHO0FBQ2IsaUJBQVUsR0FBRztBQUNiLHVCQUFnQixHQUFHOztNQUNwQixXQUFVO2dCQUFlO01BRW5COzs7OztLQUVWOzs7Ozs7R0FFUCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNYLHdCQUFDLFNBQUQ7S0FBTyxXQUFVO2VBQWpCLENBQ0ksd0JBQUMsU0FBRCxZQUNJLHdCQUFDLE1BQUQ7TUFDSSx3QkFBQyxNQUFELFlBQUksTUFBTzs7Ozs7TUFDWCx3QkFBQyxNQUFELFlBQUksVUFBVzs7Ozs7TUFDZix3QkFBQyxNQUFELFlBQUksVUFBVzs7Ozs7TUFDZix3QkFBQyxNQUFELFlBQUksT0FBUTs7Ozs7TUFDWix3QkFBQyxNQUFELFlBQUksWUFBYTs7Ozs7TUFDaEI7Ozs7ZUFDRDs7OztlQUNSLHdCQUFDLFNBQUQsWUFDSyxZQUFZLEtBQUksY0FDYix3QkFBQyxNQUFEO01BQ0ksd0JBQUMsTUFBRCxhQUFJLEtBQUUsVUFBVSxhQUFrQjs7Ozs7TUFDbEMsd0JBQUMsTUFBRCxZQUFLLFVBQVUsUUFBWTs7Ozs7TUFDM0Isd0JBQUMsTUFBRCxZQUFLLFVBQVUsUUFBWTs7Ozs7TUFDM0Isd0JBQUMsTUFBRCxZQUFLLFVBQVUsZUFBbUI7Ozs7O01BQ2xDLHdCQUFDLE1BQUQsYUFDSSx3QkFBQyxVQUFEO09BQVEsZUFBZSxlQUFlLFVBQVU7T0FBRSxXQUFVO2lCQUFxQjtPQUFlOzs7O2dCQUNoRyx3QkFBQyxVQUFEO09BQVEsZUFBZSxrQkFBa0IsVUFBVSxhQUFhO09BQUUsV0FBVTtpQkFBdUI7T0FBaUI7Ozs7ZUFDbkg7Ozs7O01BQ0osSUFUSSxVQUFVOzs7O2FBU2QsQ0FDUCxFQUNFOzs7O2NBQ0o7Ozs7OztJQUNOOzs7OztHQUNKOzs7Ozs7Ozs7QUFJZCxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbInByb3ZlZWRvcmVzLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IGFwaSBmcm9tICcuL2FwaSc7XHJcbmltcG9ydCAnLi9Qcm92ZWVkb3Jlcy5jc3MnO1xyXG5cclxuY29uc3QgUHJvdmVlZG9yZXMgPSAoKSA9PiB7XHJcbiAgICBjb25zdCBbcHJvdmVlZG9yZXMsIHNldFByb3ZlZWRvcmVzXSA9IHVzZVN0YXRlKFtdKTtcclxuICAgIGNvbnN0IFtub21icmUsIHNldE5vbWJyZV0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgICBjb25zdCBbcm9sX3Byb3ZlZWRvciwgc2V0Um9sUHJvdmVlZG9yXSA9IHVzZVN0YXRlKCcnKTtcclxuICAgIGNvbnN0IFtjb3JyZW8sIHNldENvcnJlb10gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgICBjb25zdCBbZWRpdGFuZG9JZCwgc2V0RWRpdGFuZG9JZF0gPSB1c2VTdGF0ZShudWxsKTsgXHJcblxyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBjYXJnYXJQcm92ZWVkb3JlcygpO1xyXG4gICAgfSwgW10pO1xyXG5cclxuICAgIGNvbnN0IGNhcmdhclByb3ZlZWRvcmVzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoJy9wcm92ZWVkb3JlcycpO1xyXG4gICAgICAgICAgICBzZXRQcm92ZWVkb3JlcyhyZXMuZGF0YSk7XHJcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBhbCBjYXJnYXIgcHJvdmVlZG9yZXM6XCIsIGVycik7XHJcbiAgICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICBpZiAoIW5vbWJyZS50cmltKCkpIHJldHVybiBhbGVydChcIkVsIG5vbWJyZSBlcyBvYmxpZ2F0b3Jpb1wiKTtcclxuICAgICAgICBpZiAoIWNvcnJlby50cmltKCkpIHJldHVybiBhbGVydChcIkVsIGNvcnJlbyBlcyBvYmxpZ2F0b3Jpb1wiKTtcclxuICAgICAgICBpZiAoIXJvbF9wcm92ZWVkb3IudHJpbSgpKSByZXR1cm4gYWxlcnQoXCJFbCByb2wgZGVsIHByb3ZlZWRvciBlcyBvYmxpZ2F0b3Jpb1wiKTtcclxuXHJcbiAgICAgICAgY29uc3QgZGF0b3NQcm92ZWVkb3IgPSB7IG5vbWJyZSwgY29ycmVvLCByb2xfcHJvdmVlZG9yIH07XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgaWYgKGVkaXRhbmRvSWQpIHtcclxuICAgICAgICAgICAgICAgIGF3YWl0IGFwaS5wdXQoYC9wcm92ZWVkb3Jlcy8ke2VkaXRhbmRvSWR9YCwgZGF0b3NQcm92ZWVkb3IpO1xyXG4gICAgICAgICAgICAgICAgc2V0RWRpdGFuZG9JZChudWxsKTtcclxuICAgICAgICAgICAgICAgIGFsZXJ0KFwi4pyFIFByb3ZlZWRvciBhY3R1YWxpemFkb1wiKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGF3YWl0IGFwaS5wb3N0KCcvcHJvdmVlZG9yZXMnLCBkYXRvc1Byb3ZlZWRvcik7XHJcbiAgICAgICAgICAgICAgICBhbGVydChcIuKchSBQcm92ZWVkb3IgcmVnaXN0cmFkb1wiKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBzZXROb21icmUoJycpO1xyXG4gICAgICAgICAgICBzZXRDb3JyZW8oJycpO1xyXG4gICAgICAgICAgICBzZXRSb2xQcm92ZWVkb3IoJycpO1xyXG4gICAgICAgICAgICBjYXJnYXJQcm92ZWVkb3JlcygpO1xyXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3I6XCIsIGVycik7XHJcbiAgICAgICAgICAgIGFsZXJ0KFwi4p2MIEVycm9yIGVuIGxhIG9wZXJhY2nDs25cIik7XHJcbiAgICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBpbmljaWFyRWRpY2lvbiA9IChwcm92ZWVkb3IpID0+IHtcclxuICAgICAgICBzZXROb21icmUocHJvdmVlZG9yLm5vbWJyZSk7XHJcbiAgICAgICAgc2V0Q29ycmVvKHByb3ZlZWRvci5jb3JyZW8pO1xyXG4gICAgICAgIHNldFJvbFByb3ZlZWRvcihwcm92ZWVkb3Iucm9sX3Byb3ZlZWRvcik7XHJcbiAgICAgICAgc2V0RWRpdGFuZG9JZChwcm92ZWVkb3IuaWRfcHJvdmVlZG9yKTtcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgZWxpbWluYXJQcm92ZWVkb3IgPSBhc3luYyAoaWQpID0+IHtcclxuICAgICAgICBpZiAod2luZG93LmNvbmZpcm0oXCLCv0VzdMOhcyBzZWd1cm8gZGUgZWxpbWluYXIgZXN0ZSBwcm92ZWVkb3I/XCIpKSB7XHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICBhd2FpdCBhcGkuZGVsZXRlKGAvcHJvdmVlZG9yZXMvJHtpZH1gKTtcclxuICAgICAgICAgICAgICAgIGNhcmdhclByb3ZlZWRvcmVzKCk7XHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgICAgICAgYWxlcnQoXCLinYwgRXJyb3IgYWwgZWxpbWluYXJcIik7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjbGllbnRlcy1wYWdlXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2xpZW50ZXMtaGVhZGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxvZ28tbGV2aXNcIj5MRVZJJ1M8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXY+PHNwYW4+R0VTVEnDk04gREUgUFJPVkVFRE9SRVM8L3NwYW4+PC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInNlY2Npb24tdGl0dWxvXCI+QWRtaW5pc3RyYWNpw7NuIGRlIFByb3ZlZWRvcmVzPC9oMj5cclxuXHJcbiAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IGNsYXNzTmFtZT1cImNsaWVudGVzLWZvcm1cIj5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIk5PTUJSRVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e25vbWJyZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXROb21icmUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkNPUlJFT1wiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2NvcnJlb31cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRDb3JyZW8oZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiUk9MIERFTCBQUk9WRUVET1JcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtyb2xfcHJvdmVlZG9yfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldFJvbFByb3ZlZWRvcihlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBjbGFzc05hbWU9e2BidG4tc3VibWl0ICR7ZWRpdGFuZG9JZCA/ICdidG4tZWRpdGFyJyA6ICdidG4tYWdyZWdhcid9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAge2VkaXRhbmRvSWQgPyAnR1VBUkRBUiBDQU1CSU9TJyA6ICcrIEFHUkVHQVIgUFJPVkVFRE9SJ31cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAge2VkaXRhbmRvSWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0RWRpdGFuZG9JZChudWxsKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0Tm9tYnJlKCcnKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q29ycmVvKCcnKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0Um9sUHJvdmVlZG9yKCcnKTtcclxuICAgICAgICAgICAgICAgICAgICB9fSBjbGFzc05hbWU9XCJidG4tY2FuY2VsYXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQ2FuY2VsYXJcclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZm9ybT5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGFibGEtY29udGFpbmVyXCI+XHJcbiAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidGFibGEtY2xpZW50ZXNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8dGhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aD5JRDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGg+Tk9NQlJFPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aD5DT1JSRU88L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoPlJPTDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGg+QUNDSU9ORVM8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRib2R5PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7cHJvdmVlZG9yZXMubWFwKHByb3ZlZWRvciA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtwcm92ZWVkb3IuaWRfcHJvdmVlZG9yfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQ+I3twcm92ZWVkb3IuaWRfcHJvdmVlZG9yfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkPntwcm92ZWVkb3Iubm9tYnJlfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkPntwcm92ZWVkb3IuY29ycmVvfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkPntwcm92ZWVkb3Iucm9sX3Byb3ZlZWRvcn08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBpbmljaWFyRWRpY2lvbihwcm92ZWVkb3IpfSBjbGFzc05hbWU9XCJidG4tdGFibGEgYnRuLWVkaXRcIj5FZGl0YXI8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBlbGltaW5hclByb3ZlZWRvcihwcm92ZWVkb3IuaWRfcHJvdmVlZG9yKX0gY2xhc3NOYW1lPVwiYnRuLXRhYmxhIGJ0bi1kZWxldGVcIj5FbGltaW5hcjwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgICAgICAgICAgPC90YWJsZT5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgUHJvdmVlZG9yZXM7Il19