import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/catalogo.jsx");import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=66677652"; const React = __vite__cjsImport0_react; const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];
import api, { BASE_URL } from "/src/api.js";
import "/src/catalogo.css";
import { FaShoppingCart, FaTrash, FaSearch, FaPlus, FaMinus, FaReceipt, FaChevronDown, FaChevronUp, FaTimes } from "/node_modules/.vite/deps/react-icons_fa.js?v=66677652";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=66677652";
var _jsxFileName = "C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/catalogo.jsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=66677652"; const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
function Catalogo() {
	_s();
	const [productos, setProductos] = useState([]);
	const [categoriasDB, setCategoriasDB] = useState([]);
	const [busqueda, setBusqueda] = useState("");
	const [generosSeleccionados, setGenerosSeleccionados] = useState([]);
	const [tallasSeleccionadas, setTallasSeleccionadas] = useState([]);
	const [categoriasSeleccionadas, setCategoriasSeleccionadas] = useState([]);
	const [coloresSeleccionados, setColoresSeleccionados] = useState([]);
	const [carrito, setCarrito] = useState([]);
	const [mostrarCarrito, setMostrarCarrito] = useState(false);
	// Estados para el Modal de Selección Múltiple de Tallas
	const [productoModal, setProductoModal] = useState(null);
	const [cantidadesModal, setCantidadesModal] = useState({});
	// Estados para controlar los menús desplegables de los filtros
	const [desplegadoCat, setDesplegadoCat] = useState(true);
	const [desplegadoGen, setDesplegadoGen] = useState(true);
	const [desplegadoCol, setDesplegadoCol] = useState(true);
	const [desplegadoTal, setDesplegadoTal] = useState(true);
	const navigate = useNavigate();
	useEffect(() => {
		fetchProductos();
		fetchCategorias();
	}, []);
	const fetchProductos = async () => {
		try {
			const response = await api.get("/productos/catalogo");
			setProductos(response.data);
		} catch (err) {
			console.error("Error al traer productos:", err);
		}
	};
	const fetchCategorias = async () => {
		try {
			const response = await api.get("/categorias");
			setCategoriasDB(response.data);
		} catch (err) {
			console.error("Error al traer categorías de BD:", err);
		}
	};
	// Abre el modal de múltiples tallas limpiando las selecciones previas
	const abrirModalSeleccion = (producto) => {
		setProductoModal(producto);
		setCantidadesModal({});
	};
	const modificarCantidad = (id_producto, talla, accion) => {
		setCarrito((prev) => prev.map((item) => {
			if (item.id_producto === id_producto && item.talla === talla) {
				const nuevaCant = accion === "mas" ? item.cantidad + 1 : item.cantidad - 1;
				const stockMax = item.stockMaximoTalla || 999;
				if (nuevaCant > stockMax) {
					alert(`Lo sentimos, solo hay ${stockMax} unidades disponibles para la talla ${talla}`);
					return item;
				}
				return {
					...item,
					cantidad: Math.max(1, nuevaCant)
				};
			}
			return item;
		}));
	};
	const calcularTotal = () => {
		return carrito.reduce((acc, p) => acc + (p.precioProducto || p.precio || 0) * p.cantidad, 0);
	};
	const finalizarCompra = async () => {
		if (carrito.length === 0) return alert("El carrito está vacío");
		const idUsuarioLogueado = localStorage.getItem("id_usuario") || localStorage.getItem("usuario_id");
		if (!idUsuarioLogueado) {
			alert("Debes iniciar sesión para realizar la compra");
			navigate("/login");
			return;
		}
		try {
			const datosParaEnviar = {
				id_usuario: !isNaN(idUsuarioLogueado) ? Number(idUsuarioLogueado) : idUsuarioLogueado,
				total: calcularTotal(),
				productos: carrito.map((item) => ({
					id_producto: item.id_producto,
					cantidad: item.cantidad,
					precioProducto: item.precioProducto || item.precio,
					talla: item.talla
				}))
			};
			const response = await api.post("/productos/finalizar-compra", datosParaEnviar);
			if (response.status === 200 || response.status === 201) {
				alert("¡Compra finalizada con éxito! ✨");
				setCarrito([]);
				setMostrarCarrito(false);
				fetchProductos();
				navigate("/home/mis-pedidos");
			}
		} catch (error) {
			console.error("Error en el pago:", error);
			alert(error.response?.data?.Message || error.response?.data?.error || "Error al procesar la compra");
		}
	};
	const normalizarTexto = (texto) => texto?.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim() || "";
	// Filtrado general adaptado al array de tallas
	let productosFiltrados = productos.filter((p) => normalizarTexto(p.nombreProducto).includes(normalizarTexto(busqueda)));
	if (generosSeleccionados.length > 0) {
		productosFiltrados = productosFiltrados.filter((p) => generosSeleccionados.some((g) => normalizarTexto(g) === normalizarTexto(p.genero)));
	}
	if (categoriasSeleccionadas.length > 0) {
		productosFiltrados = productosFiltrados.filter((p) => categoriasSeleccionadas.some((c) => normalizarTexto(c) === normalizarTexto(p.categoria)));
	}
	if (tallasSeleccionadas.length > 0) {
		productosFiltrados = productosFiltrados.filter((p) => {
			if (!p.tallas) return false;
			return tallasSeleccionadas.some((t) => {
				const encontrada = p.tallas.find((item) => item.talla.toUpperCase() === t.toUpperCase());
				return encontrada && Number(encontrada.stock) > 0;
			});
		});
	}
	if (coloresSeleccionados.length > 0) {
		productosFiltrados = productosFiltrados.filter((p) => coloresSeleccionados.some((col) => normalizarTexto(col) === normalizarTexto(p.color)));
	}
	const limpiarYCapitalizar = (arr) => {
		const unicos = new Set();
		arr.forEach((item) => {
			if (item) {
				let limpio = item.trim();
				limpio = limpio.charAt(0).toUpperCase() + limpio.slice(1).toLowerCase();
				unicos.add(limpio);
			}
		});
		return Array.from(unicos).sort();
	};
	const listaCatRaw = categoriasDB.length > 0 ? categoriasDB.map((c) => c.nombre) : productos.map((p) => p.categoria);
	const categoriasDisponibles = limpiarYCapitalizar(listaCatRaw);
	const generosDisponibles = limpiarYCapitalizar(productos.map((p) => p.genero));
	const coloresDisponibles = limpiarYCapitalizar(productos.map((p) => p.color));
	const tallasDisponibles = [
		"S",
		"M",
		"L",
		"XL",
		"XXL"
	];
	const toggleFiltro = (valor, lista, setLista) => {
		if (lista.includes(valor)) {
			setLista(lista.filter((i) => i !== valor));
		} else {
			setLista([...lista, valor]);
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "catalogo-page",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "catalogo-tools",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "search-bar",
					children: [/* @__PURE__ */ _jsxDEV(FaSearch, { className: "search-icon" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 189,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						type: "text",
						placeholder: "¿Qué estás buscando hoy?",
						value: busqueda,
						onChange: (e) => setBusqueda(e.target.value)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 190,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 188,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "header-actions",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						className: "btn-orders",
						onClick: () => navigate("/home/mis-pedidos"),
						children: [
							/* @__PURE__ */ _jsxDEV(FaReceipt, { size: 18 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 200,
								columnNumber: 13
							}, this),
							" ",
							/* @__PURE__ */ _jsxDEV("span", { children: "Mis Pedidos" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 200,
								columnNumber: 37
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 199,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "cart-trigger",
						onClick: () => setMostrarCarrito(!mostrarCarrito),
						children: [/* @__PURE__ */ _jsxDEV(FaShoppingCart, { size: 22 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 203,
							columnNumber: 13
						}, this), carrito.length > 0 && /* @__PURE__ */ _jsxDEV("span", {
							className: "cart-badge",
							children: carrito.reduce((acc, p) => acc + p.cantidad, 0)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 205,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 202,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 198,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 187,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "catalogo-layout",
				children: [/* @__PURE__ */ _jsxDEV("aside", {
					className: "catalogo-sidebar",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "sidebar-header-filter",
							children: /* @__PURE__ */ _jsxDEV("h3", { children: "Filtros de Búsqueda" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 217,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 216,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "filter-section",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "accordion-header",
								onClick: () => setDesplegadoCat(!desplegadoCat),
								children: [/* @__PURE__ */ _jsxDEV("h4", {
									className: "sidebar-title",
									children: "Categoría"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 222,
									columnNumber: 15
								}, this), desplegadoCat ? /* @__PURE__ */ _jsxDEV(FaChevronUp, { size: 12 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 223,
									columnNumber: 32
								}, this) : /* @__PURE__ */ _jsxDEV(FaChevronDown, { size: 12 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 223,
									columnNumber: 60
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 221,
								columnNumber: 13
							}, this), desplegadoCat && /* @__PURE__ */ _jsxDEV("div", {
								className: "filter-options-list",
								children: categoriasDisponibles.map((cat) => /* @__PURE__ */ _jsxDEV("label", {
									className: `custom-checkbox-label ${categoriasSeleccionadas.includes(cat) ? "active" : ""}`,
									children: [
										/* @__PURE__ */ _jsxDEV("input", {
											type: "checkbox",
											checked: categoriasSeleccionadas.includes(cat),
											onChange: () => toggleFiltro(cat, categoriasSeleccionadas, setCategoriasSeleccionadas)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 229,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { className: "checkbox-custom" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 234,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "checkbox-text",
											children: cat
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 235,
											columnNumber: 21
										}, this)
									]
								}, cat, true, {
									fileName: _jsxFileName,
									lineNumber: 228,
									columnNumber: 19
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 226,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 220,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "filter-section",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "accordion-header",
								onClick: () => setDesplegadoGen(!desplegadoGen),
								children: [/* @__PURE__ */ _jsxDEV("h4", {
									className: "sidebar-title",
									children: "Género"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 244,
									columnNumber: 15
								}, this), desplegadoGen ? /* @__PURE__ */ _jsxDEV(FaChevronUp, { size: 12 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 245,
									columnNumber: 32
								}, this) : /* @__PURE__ */ _jsxDEV(FaChevronDown, { size: 12 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 245,
									columnNumber: 60
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 243,
								columnNumber: 13
							}, this), desplegadoGen && /* @__PURE__ */ _jsxDEV("div", {
								className: "filter-options-list",
								children: generosDisponibles.map((g) => /* @__PURE__ */ _jsxDEV("label", {
									className: `custom-checkbox-label ${generosSeleccionados.includes(g) ? "active" : ""}`,
									children: [
										/* @__PURE__ */ _jsxDEV("input", {
											type: "checkbox",
											checked: generosSeleccionados.includes(g),
											onChange: () => toggleFiltro(g, generosSeleccionados, setGenerosSeleccionados)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 251,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { className: "checkbox-custom" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 256,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "checkbox-text",
											children: g
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 257,
											columnNumber: 21
										}, this)
									]
								}, g, true, {
									fileName: _jsxFileName,
									lineNumber: 250,
									columnNumber: 19
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 248,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 242,
							columnNumber: 11
						}, this),
						coloresDisponibles.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
							className: "filter-section",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "accordion-header",
								onClick: () => setDesplegadoCol(!desplegadoCol),
								children: [/* @__PURE__ */ _jsxDEV("h4", {
									className: "sidebar-title",
									children: "Color"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 267,
									columnNumber: 17
								}, this), desplegadoCol ? /* @__PURE__ */ _jsxDEV(FaChevronUp, { size: 12 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 268,
									columnNumber: 34
								}, this) : /* @__PURE__ */ _jsxDEV(FaChevronDown, { size: 12 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 268,
									columnNumber: 62
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 266,
								columnNumber: 15
							}, this), desplegadoCol && /* @__PURE__ */ _jsxDEV("div", {
								className: "filter-options-list",
								children: coloresDisponibles.map((color) => /* @__PURE__ */ _jsxDEV("label", {
									className: `custom-checkbox-label ${coloresSeleccionados.includes(color) ? "active" : ""}`,
									children: [
										/* @__PURE__ */ _jsxDEV("input", {
											type: "checkbox",
											checked: coloresSeleccionados.includes(color),
											onChange: () => toggleFiltro(color, coloresSeleccionados, setColoresSeleccionados)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 274,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { className: "checkbox-custom" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 279,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "checkbox-text",
											children: color
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 280,
											columnNumber: 23
										}, this)
									]
								}, color, true, {
									fileName: _jsxFileName,
									lineNumber: 273,
									columnNumber: 21
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 271,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 265,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "filter-section",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "accordion-header",
								onClick: () => setDesplegadoTal(!desplegadoTal),
								children: [/* @__PURE__ */ _jsxDEV("h4", {
									className: "sidebar-title",
									children: "Tallas"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 290,
									columnNumber: 15
								}, this), desplegadoTal ? /* @__PURE__ */ _jsxDEV(FaChevronUp, { size: 12 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 291,
									columnNumber: 32
								}, this) : /* @__PURE__ */ _jsxDEV(FaChevronDown, { size: 12 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 291,
									columnNumber: 60
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 289,
								columnNumber: 13
							}, this), desplegadoTal && /* @__PURE__ */ _jsxDEV("div", {
								className: "tallas-flex",
								children: tallasDisponibles.map((talla) => /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									className: `talla-chip-btn ${tallasSeleccionadas.includes(talla) ? "active" : ""}`,
									onClick: () => toggleFiltro(talla, tallasSeleccionadas, setTallasSeleccionadas),
									children: talla
								}, talla, false, {
									fileName: _jsxFileName,
									lineNumber: 296,
									columnNumber: 19
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 294,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 288,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 215,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("main", {
					className: "productos-container",
					children: productosFiltrados.length > 0 ? /* @__PURE__ */ _jsxDEV("div", {
						className: "productos-grid",
						children: productosFiltrados.map((p) => /* @__PURE__ */ _jsxDEV("div", {
							className: "producto-card",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "img-wrapper",
								children: /* @__PURE__ */ _jsxDEV("img", {
									src: p.imagen ? `${BASE_URL}${p.imagen}` : "/img/default.jpg",
									alt: p.nombreProducto,
									onError: (e) => {
										e.target.src = "/img/default.jpg";
									}
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 317,
									columnNumber: 21
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 316,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "producto-info",
								children: [
									/* @__PURE__ */ _jsxDEV("h4", { children: p.nombreProducto }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 324,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "p-talla",
										children: [
											"Color: ",
											p.color || "N/A",
											" | Gen: ",
											p.genero || "N/A"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 325,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "tallas-badges-catalogo",
										style: {
											display: "flex",
											gap: "5px",
											flexWrap: "wrap",
											margin: "8px 0"
										},
										children: p.tallas && p.tallas.length > 0 ? p.tallas.map((tItem) => {
											if (Number(tItem.stock) <= 0) return null;
											return /* @__PURE__ */ _jsxDEV("span", {
												style: {
													background: "#121212",
													color: "#ff4d4d",
													border: "1px solid rgba(229, 9, 20, 0.4)",
													padding: "2px 6px",
													fontSize: "11px",
													borderRadius: "4px",
													fontWeight: "bold"
												},
												children: [
													tItem.talla,
													": ",
													tItem.stock
												]
											}, tItem.talla, true, {
												fileName: _jsxFileName,
												lineNumber: 333,
												columnNumber: 29
											}, this);
										}) : /* @__PURE__ */ _jsxDEV("span", {
											style: {
												fontSize: "11px",
												color: "#888"
											},
											children: "Sin stock"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 339,
											columnNumber: 25
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 328,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "p-precio",
										children: [
											"$",
											(p.precioProducto || p.precio || 0).toLocaleString(),
											" COP"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 343,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										className: "btn-add-cart",
										onClick: () => abrirModalSeleccion(p),
										children: "Añadir al carrito"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 345,
										columnNumber: 21
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 323,
								columnNumber: 19
							}, this)]
						}, p.id_producto, true, {
							fileName: _jsxFileName,
							lineNumber: 315,
							columnNumber: 17
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 313,
						columnNumber: 13
					}, this) : /* @__PURE__ */ _jsxDEV("div", {
						className: "no-results-box",
						children: /* @__PURE__ */ _jsxDEV("p", {
							className: "no-results",
							children: "No se encontraron productos con estos filtros."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 354,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 353,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 311,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 213,
				columnNumber: 7
			}, this),
			productoModal && /* @__PURE__ */ _jsxDEV("div", {
				className: "modal-overlay",
				style: {
					position: "fixed",
					top: 0,
					left: 0,
					width: "100%",
					height: "100%",
					background: "rgba(0,0,0,0.8)",
					display: "flex",
					justifyContent: "center",
					alignItems: "center",
					zIndex: 1e3,
					backdropFilter: "blur(4px)"
				},
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "modal-content",
					style: {
						background: "#121212",
						padding: "30px",
						borderRadius: "16px",
						width: "420px",
						color: "#fff",
						position: "relative",
						border: "1px solid #e50914",
						boxShadow: "0 0 25px rgba(229, 9, 20, 0.4)"
					},
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setProductoModal(null),
							style: {
								position: "absolute",
								top: "15px",
								right: "15px",
								background: "transparent",
								border: "none",
								color: "#aaa",
								cursor: "pointer",
								transition: "0.2s"
							},
							onMouseEnter: (e) => e.target.style.color = "#fff",
							onMouseLeave: (e) => e.target.style.color = "#aaa",
							children: /* @__PURE__ */ _jsxDEV(FaTimes, { size: 18 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 365,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 364,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("h3", {
							style: {
								marginBottom: "8px",
								fontSize: "20px",
								color: "#fff",
								textShadow: "0 0 10px rgba(229, 9, 20, 0.5)"
							},
							children: "Seleccionar Tallas y Cantidades"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 368,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							style: {
								fontSize: "13px",
								color: "#aaa",
								marginBottom: "20px"
							},
							children: productoModal.nombreProducto
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 369,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							style: {
								display: "flex",
								flexDirection: "column",
								gap: "12px",
								maxHeight: "250px",
								overflowY: "auto",
								paddingRight: "5px",
								marginBottom: "20px"
							},
							children: productoModal.tallas && productoModal.tallas.length > 0 ? productoModal.tallas.map((tItem) => {
								const stockMax = Number(tItem.stock) || 0;
								if (stockMax <= 0) return null;
								const cantActual = cantidadesModal[tItem.talla] || 0;
								return /* @__PURE__ */ _jsxDEV("div", {
									style: {
										display: "flex",
										justifyContent: "space-between",
										alignItems: "center",
										background: "#1a1a1a",
										padding: "10px 15px",
										borderRadius: "8px",
										border: "1px solid #2a2a2a"
									},
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										style: {
											fontWeight: "bold",
											fontSize: "15px",
											color: "#fff"
										},
										children: ["Talla ", tItem.talla]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 382,
										columnNumber: 25
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										style: {
											display: "block",
											fontSize: "11px",
											color: "#888"
										},
										children: ["Stock disponible: ", stockMax]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 383,
										columnNumber: 25
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 381,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										style: {
											display: "flex",
											alignItems: "center",
											gap: "8px"
										},
										children: [
											/* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												onClick: () => {
													setCantidadesModal((prev) => ({
														...prev,
														[tItem.talla]: Math.max(0, (prev[tItem.talla] || 0) - 1)
													}));
												},
												style: {
													width: "28px",
													height: "28px",
													background: "#222",
													color: "#fff",
													border: "1px solid #444",
													borderRadius: "4px",
													cursor: "pointer",
													display: "flex",
													alignItems: "center",
													justifyContent: "center"
												},
												children: /* @__PURE__ */ _jsxDEV(FaMinus, { size: 10 }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 396,
													columnNumber: 27
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 386,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("input", {
												type: "number",
												min: "0",
												max: stockMax,
												value: cantActual,
												onChange: (e) => {
													const val = Math.max(0, Math.min(stockMax, Number(e.target.value)));
													setCantidadesModal((prev) => ({
														...prev,
														[tItem.talla]: val
													}));
												},
												style: {
													width: "45px",
													textAlign: "center",
													background: "#0a0a0a",
													border: "1px solid #444",
													color: "#fff",
													borderRadius: "4px",
													padding: "4px",
													fontSize: "14px",
													outline: "none"
												}
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 399,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												onClick: () => {
													if (cantActual < stockMax) {
														setCantidadesModal((prev) => ({
															...prev,
															[tItem.talla]: (prev[tItem.talla] || 0) + 1
														}));
													}
												},
												style: {
													width: "28px",
													height: "28px",
													background: "#222",
													color: "#fff",
													border: "1px solid #444",
													borderRadius: "4px",
													cursor: "pointer",
													display: "flex",
													alignItems: "center",
													justifyContent: "center"
												},
												children: /* @__PURE__ */ _jsxDEV(FaPlus, { size: 10 }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 423,
													columnNumber: 27
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 411,
												columnNumber: 25
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 385,
										columnNumber: 23
									}, this)]
								}, tItem.talla, true, {
									fileName: _jsxFileName,
									lineNumber: 380,
									columnNumber: 21
								}, this);
							}) : /* @__PURE__ */ _jsxDEV("p", {
								style: {
									fontSize: "13px",
									color: "#e50914",
									textAlign: "center"
								},
								children: "No hay tallas disponibles para este producto."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 430,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 371,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => {
								const seleccionadas = Object.entries(cantidadesModal).filter(([talla, cantidad]) => cantidad > 0);
								if (seleccionadas.length === 0) {
									alert("Por favor selecciona al menos una cantidad mayor a 0 en alguna talla.");
									return;
								}
								setCarrito((prev) => {
									let nuevoCarrito = [...prev];
									seleccionadas.forEach(([talla, cantidad]) => {
										const tItemEncontrado = productoModal.tallas.find((t) => t.talla === talla);
										const stockMaximoTalla = tItemEncontrado ? Number(tItemEncontrado.stock) : 999;
										const indexExistente = nuevoCarrito.findIndex((item) => item.id_producto === productoModal.id_producto && item.talla === talla);
										if (indexExistente >= 0) {
											const itemActual = nuevoCarrito[indexExistente];
											const nuevaCantidadTotal = itemActual.cantidad + cantidad;
											if (nuevaCantidadTotal > stockMaximoTalla) {
												alert(`La cantidad total para la talla ${talla} excede el stock disponible (${stockMaximoTalla})`);
												return;
											}
											nuevoCarrito[indexExistente] = {
												...itemActual,
												cantidad: nuevaCantidadTotal
											};
										} else {
											nuevoCarrito.push({
												...productoModal,
												talla,
												cantidad,
												stockMaximoTalla
											});
										}
									});
									return nuevoCarrito;
								});
								setProductoModal(null);
							},
							style: {
								width: "100%",
								padding: "12px",
								background: "#e50914",
								color: "#fff",
								border: "none",
								borderRadius: "8px",
								fontWeight: "bold",
								cursor: "pointer",
								boxShadow: "0 0 15px rgba(229, 9, 20, 0.6)",
								transition: "0.2s"
							},
							onMouseEnter: (e) => e.target.style.background = "#ff1e2b",
							onMouseLeave: (e) => e.target.style.background = "#e50914",
							children: "AÑADIR AL CARRITO"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 434,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 363,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 362,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: `cart-drawer ${mostrarCarrito ? "open" : ""}`,
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "cart-drawer-header",
						children: [/* @__PURE__ */ _jsxDEV("h3", { children: [
							"TU CARRITO (",
							carrito.reduce((acc, i) => acc + i.cantidad, 0),
							")"
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 492,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							className: "btn-close-cart",
							onClick: () => setMostrarCarrito(false),
							children: "✕"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 493,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 491,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "cart-drawer-body",
						children: carrito.length === 0 ? /* @__PURE__ */ _jsxDEV("p", {
							className: "empty-msg",
							children: "El carrito está vacío"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 497,
							columnNumber: 13
						}, this) : carrito.map((item) => /* @__PURE__ */ _jsxDEV("div", {
							className: "cart-item-pro",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "cart-item-info",
								children: [
									/* @__PURE__ */ _jsxDEV("p", {
										className: "item-name",
										children: item.nombreProducto
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 502,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										style: {
											fontSize: "12px",
											color: "#aaa",
											margin: "2px 0"
										},
										children: ["Talla: ", /* @__PURE__ */ _jsxDEV("strong", { children: item.talla }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 503,
											columnNumber: 90
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 503,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "qty-controls",
										children: [
											/* @__PURE__ */ _jsxDEV("button", {
												onClick: () => modificarCantidad(item.id_producto, item.talla, "menos"),
												children: /* @__PURE__ */ _jsxDEV(FaMinus, { size: 10 }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 505,
													columnNumber: 102
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 505,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("span", { children: item.cantidad }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 506,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("button", {
												onClick: () => modificarCantidad(item.id_producto, item.talla, "mas"),
												children: /* @__PURE__ */ _jsxDEV(FaPlus, { size: 10 }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 507,
													columnNumber: 100
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 507,
												columnNumber: 21
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 504,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "item-subtotal",
										children: ["Subtotal: $", ((item.precioProducto || item.precio || 0) * item.cantidad).toLocaleString()]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 509,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 501,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV(FaTrash, {
								className: "btn-remove",
								onClick: () => setCarrito(carrito.filter((i) => !(i.id_producto === item.id_producto && i.talla === item.talla)))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 513,
								columnNumber: 17
							}, this)]
						}, `${item.id_producto}-${item.talla}`, true, {
							fileName: _jsxFileName,
							lineNumber: 500,
							columnNumber: 15
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 495,
						columnNumber: 9
					}, this),
					carrito.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
						className: "cart-drawer-footer",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "cart-total-section",
							children: [/* @__PURE__ */ _jsxDEV("span", { children: "TOTAL A PAGAR:" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 521,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "total-amount",
								children: [
									"$",
									calcularTotal().toLocaleString(),
									" COP"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 522,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 520,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							className: "btn-checkout-pro",
							onClick: finalizarCompra,
							children: "PAGAR"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 524,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 519,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 490,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 186,
		columnNumber: 5
	}, this);
}
_s(Catalogo, "HzLYX82290EzXf70R0GE7No15N4=", false, function() {
	return [useNavigate];
});
_c = Catalogo;
export default Catalogo;
var _c;
$RefreshReg$(_c, "Catalogo");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/catalogo.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/catalogo.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/catalogo.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/catalogo.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFdBQVcsZ0JBQWdCO0FBQzNDLE9BQU8sT0FBTyxnQkFBZ0I7QUFDOUIsT0FBTztBQUNQLFNBQVMsZ0JBQWdCLFNBQVMsVUFBVSxRQUFRLFNBQVMsV0FBVyxlQUFlLGFBQWEsZUFBZTtBQUNuSCxTQUFTLG1CQUFtQjs7OztBQUU1QixTQUFTLFdBQVc7O0NBQ2xCLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLEVBQUUsQ0FBQztDQUM5QyxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxFQUFFLENBQUM7Q0FDcEQsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLEdBQUc7Q0FDNUMsTUFBTSxDQUFDLHNCQUFzQiwyQkFBMkIsU0FBUyxFQUFFLENBQUM7Q0FDcEUsTUFBTSxDQUFDLHFCQUFxQiwwQkFBMEIsU0FBUyxFQUFFLENBQUM7Q0FDbEUsTUFBTSxDQUFDLHlCQUF5Qiw4QkFBOEIsU0FBUyxFQUFFLENBQUM7Q0FDMUUsTUFBTSxDQUFDLHNCQUFzQiwyQkFBMkIsU0FBUyxFQUFFLENBQUM7Q0FDcEUsTUFBTSxDQUFDLFNBQVMsY0FBZSxTQUFTLEVBQUUsQ0FBQztDQUMzQyxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUFTLE1BQU07O0NBRzNELE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFTLEtBQUs7Q0FDeEQsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FBUyxFQUFFLENBQUM7O0NBRzFELE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFTLEtBQUs7Q0FDeEQsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQVMsS0FBSztDQUN4RCxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBUyxLQUFLO0NBQ3hELE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFTLEtBQUs7Q0FFeEQsTUFBTSxXQUFXLGFBQWE7QUFFOUIsaUJBQWdCO0FBQ2Qsa0JBQWdCO0FBQ2hCLG1CQUFpQjtJQUNoQixFQUFFLENBQUM7Q0FFTixNQUFNLGlCQUFpQixZQUFZO0FBQ2pDLE1BQUk7R0FDRixNQUFNLFdBQVcsTUFBTSxJQUFJLElBQUksc0JBQXNCO0FBQ3JELGdCQUFhLFNBQVMsS0FBSztXQUNwQixLQUFLO0FBQ1osV0FBUSxNQUFNLDZCQUE2QixJQUFJOzs7Q0FJbkQsTUFBTSxrQkFBa0IsWUFBWTtBQUNsQyxNQUFJO0dBQ0YsTUFBTSxXQUFXLE1BQU0sSUFBSSxJQUFJLGNBQWM7QUFDN0MsbUJBQWdCLFNBQVMsS0FBSztXQUN2QixLQUFLO0FBQ1osV0FBUSxNQUFNLG9DQUFvQyxJQUFJOzs7O0NBSzFELE1BQU0sdUJBQXVCLGFBQWE7QUFDeEMsbUJBQWlCLFNBQVM7QUFDMUIscUJBQW1CLEVBQUUsQ0FBQzs7Q0FHeEIsTUFBTSxxQkFBcUIsYUFBYSxPQUFPLFdBQVc7QUFDeEQsY0FBWSxTQUNWLEtBQUssS0FBSyxTQUFTO0FBQ2pCLE9BQUksS0FBSyxnQkFBZ0IsZUFBZSxLQUFLLFVBQVUsT0FBTztJQUM1RCxNQUFNLFlBQVksV0FBVyxRQUFRLEtBQUssV0FBVyxJQUFJLEtBQUssV0FBVztJQUN6RSxNQUFNLFdBQVcsS0FBSyxvQkFBb0I7QUFFMUMsUUFBSSxZQUFZLFVBQVU7QUFDeEIsV0FBTSx5QkFBeUIsU0FBUyxzQ0FBc0MsUUFBUTtBQUN0RixZQUFPOztBQUdULFdBQU87S0FBRSxHQUFHO0tBQU0sVUFBVSxLQUFLLElBQUksR0FBRyxVQUFVO0tBQUU7O0FBRXRELFVBQU87SUFDUCxDQUNIOztDQUdILE1BQU0sc0JBQXNCO0FBQzFCLFNBQU8sUUFBUSxRQUFRLEtBQUssTUFBTSxPQUFRLEVBQUUsa0JBQWtCLEVBQUUsVUFBVSxLQUFLLEVBQUUsVUFBVyxFQUFFOztDQUdoRyxNQUFNLGtCQUFrQixZQUFZO0FBQ2xDLE1BQUksUUFBUSxXQUFXLEVBQUcsUUFBTyxNQUFNLHdCQUF3QjtFQUUvRCxNQUFNLG9CQUFvQixhQUFhLFFBQVEsYUFBYSxJQUFJLGFBQWEsUUFBUSxhQUFhO0FBRWxHLE1BQUksQ0FBQyxtQkFBbUI7QUFDdEIsU0FBTSwrQ0FBK0M7QUFDckQsWUFBUyxTQUFTO0FBQ2xCOztBQUdGLE1BQUk7R0FDRixNQUFNLGtCQUFrQjtJQUN0QixZQUFZLENBQUMsTUFBTSxrQkFBa0IsR0FBRyxPQUFPLGtCQUFrQixHQUFHO0lBQ3BFLE9BQU8sZUFBZTtJQUN0QixXQUFXLFFBQVEsS0FBSSxVQUFTO0tBQzlCLGFBQWEsS0FBSztLQUNsQixVQUFVLEtBQUs7S0FDZixnQkFBZ0IsS0FBSyxrQkFBa0IsS0FBSztLQUM1QyxPQUFPLEtBQUs7S0FDYixFQUFFO0lBQ0o7R0FFRCxNQUFNLFdBQVcsTUFBTSxJQUFJLEtBQUssK0JBQStCLGdCQUFnQjtBQUUvRSxPQUFJLFNBQVMsV0FBVyxPQUFPLFNBQVMsV0FBVyxLQUFLO0FBQ3RELFVBQU0sa0NBQWtDO0FBQ3hDLGVBQVcsRUFBRSxDQUFDO0FBQ2Qsc0JBQWtCLE1BQU07QUFDeEIsb0JBQWdCO0FBQ2hCLGFBQVMsb0JBQW9COztXQUV4QixPQUFPO0FBQ2QsV0FBUSxNQUFNLHFCQUFxQixNQUFNO0FBQ3pDLFNBQU0sTUFBTSxVQUFVLE1BQU0sV0FBVyxNQUFNLFVBQVUsTUFBTSxTQUFTLDhCQUE4Qjs7O0NBSXhHLE1BQU0sbUJBQW1CLFVBQ3ZCLE9BQU8sYUFBYSxDQUFDLFVBQVUsTUFBTSxDQUFDLFFBQVEsb0JBQW9CLEdBQUcsQ0FBQyxNQUFNLElBQUk7O0NBR2xGLElBQUkscUJBQXFCLFVBQVUsUUFBUSxNQUN6QyxnQkFBZ0IsRUFBRSxlQUFlLENBQUMsU0FBUyxnQkFBZ0IsU0FBUyxDQUFDLENBQ3RFO0FBRUQsS0FBSSxxQkFBcUIsU0FBUyxHQUFHO0FBQ25DLHVCQUFxQixtQkFBbUIsUUFBUSxNQUM5QyxxQkFBcUIsTUFBTSxNQUFNLGdCQUFnQixFQUFFLEtBQUssZ0JBQWdCLEVBQUUsT0FBTyxDQUFDLENBQ25GOztBQUdILEtBQUksd0JBQXdCLFNBQVMsR0FBRztBQUN0Qyx1QkFBcUIsbUJBQW1CLFFBQVEsTUFDOUMsd0JBQXdCLE1BQU0sTUFBTSxnQkFBZ0IsRUFBRSxLQUFLLGdCQUFnQixFQUFFLFVBQVUsQ0FBQyxDQUN6Rjs7QUFHSCxLQUFJLG9CQUFvQixTQUFTLEdBQUc7QUFDbEMsdUJBQXFCLG1CQUFtQixRQUFRLE1BQU07QUFDcEQsT0FBSSxDQUFDLEVBQUUsT0FBUSxRQUFPO0FBQ3RCLFVBQU8sb0JBQW9CLE1BQU0sTUFBTTtJQUNyQyxNQUFNLGFBQWEsRUFBRSxPQUFPLE1BQUssU0FBUSxLQUFLLE1BQU0sYUFBYSxLQUFLLEVBQUUsYUFBYSxDQUFDO0FBQ3RGLFdBQU8sY0FBYyxPQUFPLFdBQVcsTUFBTSxHQUFHO0tBQ2hEO0lBQ0Y7O0FBR0osS0FBSSxxQkFBcUIsU0FBUyxHQUFHO0FBQ25DLHVCQUFxQixtQkFBbUIsUUFBUSxNQUM5QyxxQkFBcUIsTUFBTSxRQUFRLGdCQUFnQixJQUFJLEtBQUssZ0JBQWdCLEVBQUUsTUFBTSxDQUFDLENBQ3RGOztDQUdILE1BQU0sdUJBQXVCLFFBQVE7RUFDbkMsTUFBTSxTQUFTLElBQUksS0FBSztBQUN4QixNQUFJLFNBQVEsU0FBUTtBQUNsQixPQUFJLE1BQU07SUFDUixJQUFJLFNBQVMsS0FBSyxNQUFNO0FBQ3hCLGFBQVMsT0FBTyxPQUFPLEVBQUUsQ0FBQyxhQUFhLEdBQUcsT0FBTyxNQUFNLEVBQUUsQ0FBQyxhQUFhO0FBQ3ZFLFdBQU8sSUFBSSxPQUFPOztJQUVwQjtBQUNGLFNBQU8sTUFBTSxLQUFLLE9BQU8sQ0FBQyxNQUFNOztDQUdsQyxNQUFNLGNBQWMsYUFBYSxTQUFTLElBQ3RDLGFBQWEsS0FBSSxNQUFLLEVBQUUsT0FBTyxHQUMvQixVQUFVLEtBQUksTUFBSyxFQUFFLFVBQVU7Q0FFbkMsTUFBTSx3QkFBd0Isb0JBQW9CLFlBQVk7Q0FDOUQsTUFBTSxxQkFBcUIsb0JBQW9CLFVBQVUsS0FBSSxNQUFLLEVBQUUsT0FBTyxDQUFDO0NBQzVFLE1BQU0scUJBQXFCLG9CQUFvQixVQUFVLEtBQUksTUFBSyxFQUFFLE1BQU0sQ0FBQztDQUMzRSxNQUFNLG9CQUFvQjtFQUFDO0VBQUs7RUFBSztFQUFLO0VBQU07RUFBTTtDQUV0RCxNQUFNLGdCQUFnQixPQUFPLE9BQU8sYUFBYTtBQUMvQyxNQUFJLE1BQU0sU0FBUyxNQUFNLEVBQUU7QUFDekIsWUFBUyxNQUFNLFFBQVEsTUFBTSxNQUFNLE1BQU0sQ0FBQztTQUNyQztBQUNMLFlBQVMsQ0FBQyxHQUFHLE9BQU8sTUFBTSxDQUFDOzs7QUFJL0IsUUFDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxlQUFnQjs7OztlQUNwQyx3QkFBQyxTQUFEO01BQ0UsTUFBSztNQUNMLGFBQVk7TUFDWixPQUFPO01BQ1AsV0FBVyxNQUFNLFlBQVksRUFBRSxPQUFPLE1BQU07TUFDNUM7Ozs7Y0FDRTs7Ozs7Y0FFTix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsVUFBRDtNQUFRLFdBQVU7TUFBYSxlQUFlLFNBQVMsb0JBQW9CO2dCQUEzRTtPQUNFLHdCQUFDLFdBQUQsRUFBVyxNQUFNLElBQU07Ozs7OztPQUFDLHdCQUFDLFFBQUQsWUFBTSxlQUFrQjs7Ozs7T0FDekM7Ozs7O2VBQ1Qsd0JBQUMsT0FBRDtNQUFLLFdBQVU7TUFBZSxlQUFlLGtCQUFrQixDQUFDLGVBQWU7Z0JBQS9FLENBQ0Usd0JBQUMsZ0JBQUQsRUFBZ0IsTUFBTSxJQUFNOzs7O2dCQUMzQixRQUFRLFNBQVMsS0FDaEIsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQ2IsUUFBUSxRQUFRLEtBQUssTUFBTSxNQUFNLEVBQUUsVUFBVSxFQUFFO09BQzNDOzs7O2VBRUw7Ozs7O2NBQ0Y7Ozs7O2FBQ0Y7Ozs7OztHQUVOLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FFRSx3QkFBQyxTQUFEO0tBQU8sV0FBVTtlQUFqQjtNQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLE1BQUQsWUFBSSx1QkFBd0I7Ozs7O09BQ3hCOzs7OztNQUVOLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7UUFBbUIsZUFBZSxpQkFBaUIsQ0FBQyxjQUFjO2tCQUFqRixDQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFnQjtTQUFjOzs7O2tCQUMzQyxnQkFBZ0Isd0JBQUMsYUFBRCxFQUFhLE1BQU0sSUFBTTs7OzttQkFBRyx3QkFBQyxlQUFELEVBQWUsTUFBTSxJQUFNOzs7O2lCQUNwRTs7Ozs7aUJBQ0wsaUJBQ0Msd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ1osc0JBQXNCLEtBQUssUUFDMUIsd0JBQUMsU0FBRDtTQUFpQixXQUFXLHlCQUF5Qix3QkFBd0IsU0FBUyxJQUFJLEdBQUcsV0FBVzttQkFBeEc7VUFDRSx3QkFBQyxTQUFEO1dBQ0UsTUFBSztXQUNMLFNBQVMsd0JBQXdCLFNBQVMsSUFBSTtXQUM5QyxnQkFBZ0IsYUFBYSxLQUFLLHlCQUF5QiwyQkFBMkI7V0FDdEY7Ozs7O1VBQ0Ysd0JBQUMsUUFBRCxFQUFNLFdBQVUsbUJBQXlCOzs7OztVQUN6Qyx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBaUI7V0FBVzs7Ozs7VUFDdEM7V0FSSTs7OztnQkFRSixDQUNSO1FBQ0U7Ozs7Z0JBRUo7Ozs7OztNQUVOLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7UUFBbUIsZUFBZSxpQkFBaUIsQ0FBQyxjQUFjO2tCQUFqRixDQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFnQjtTQUFXOzs7O2tCQUN4QyxnQkFBZ0Isd0JBQUMsYUFBRCxFQUFhLE1BQU0sSUFBTTs7OzttQkFBRyx3QkFBQyxlQUFELEVBQWUsTUFBTSxJQUFNOzs7O2lCQUNwRTs7Ozs7aUJBQ0wsaUJBQ0Msd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ1osbUJBQW1CLEtBQUssTUFDdkIsd0JBQUMsU0FBRDtTQUFlLFdBQVcseUJBQXlCLHFCQUFxQixTQUFTLEVBQUUsR0FBRyxXQUFXO21CQUFqRztVQUNFLHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0wsU0FBUyxxQkFBcUIsU0FBUyxFQUFFO1dBQ3pDLGdCQUFnQixhQUFhLEdBQUcsc0JBQXNCLHdCQUF3QjtXQUM5RTs7Ozs7VUFDRix3QkFBQyxRQUFELEVBQU0sV0FBVSxtQkFBeUI7Ozs7O1VBQ3pDLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFpQjtXQUFTOzs7OztVQUNwQztXQVJJOzs7O2dCQVFKLENBQ1I7UUFDRTs7OztnQkFFSjs7Ozs7O01BRUwsbUJBQW1CLFNBQVMsS0FDM0Isd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtRQUFtQixlQUFlLGlCQUFpQixDQUFDLGNBQWM7a0JBQWpGLENBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQWdCO1NBQVU7Ozs7a0JBQ3ZDLGdCQUFnQix3QkFBQyxhQUFELEVBQWEsTUFBTSxJQUFNOzs7O21CQUFHLHdCQUFDLGVBQUQsRUFBZSxNQUFNLElBQU07Ozs7aUJBQ3BFOzs7OztpQkFDTCxpQkFDQyx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDWixtQkFBbUIsS0FBSyxVQUN2Qix3QkFBQyxTQUFEO1NBQW1CLFdBQVcseUJBQXlCLHFCQUFxQixTQUFTLE1BQU0sR0FBRyxXQUFXO21CQUF6RztVQUNFLHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0wsU0FBUyxxQkFBcUIsU0FBUyxNQUFNO1dBQzdDLGdCQUFnQixhQUFhLE9BQU8sc0JBQXNCLHdCQUF3QjtXQUNsRjs7Ozs7VUFDRix3QkFBQyxRQUFELEVBQU0sV0FBVSxtQkFBeUI7Ozs7O1VBQ3pDLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFpQjtXQUFhOzs7OztVQUN4QztXQVJJOzs7O2dCQVFKLENBQ1I7UUFDRTs7OztnQkFFSjs7Ozs7O01BR1Isd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtRQUFtQixlQUFlLGlCQUFpQixDQUFDLGNBQWM7a0JBQWpGLENBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQWdCO1NBQVc7Ozs7a0JBQ3hDLGdCQUFnQix3QkFBQyxhQUFELEVBQWEsTUFBTSxJQUFNOzs7O21CQUFHLHdCQUFDLGVBQUQsRUFBZSxNQUFNLElBQU07Ozs7aUJBQ3BFOzs7OztpQkFDTCxpQkFDQyx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDWixrQkFBa0IsS0FBSyxVQUN0Qix3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUVMLFdBQVcsa0JBQWtCLG9CQUFvQixTQUFTLE1BQU0sR0FBRyxXQUFXO1NBQzlFLGVBQWUsYUFBYSxPQUFPLHFCQUFxQix1QkFBdUI7bUJBRTlFO1NBQ00sRUFMRjs7OztnQkFLRSxDQUNUO1FBQ0U7Ozs7Z0JBRUo7Ozs7OztNQUNBOzs7OztjQUdSLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQ2IsbUJBQW1CLFNBQVMsSUFDM0Isd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ1osbUJBQW1CLEtBQUssTUFDdkIsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDYix3QkFBQyxPQUFEO1NBQ0UsS0FBSyxFQUFFLFNBQVMsR0FBRyxXQUFXLEVBQUUsV0FBVztTQUMzQyxLQUFLLEVBQUU7U0FDUCxVQUFVLE1BQU07QUFBRSxZQUFFLE9BQU8sTUFBTTs7U0FDakM7Ozs7O1FBQ0U7Ozs7aUJBQ04sd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxNQUFELFlBQUssRUFBRSxnQkFBb0I7Ozs7O1NBQzNCLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUFiO1dBQXVCO1dBQVEsRUFBRSxTQUFTO1dBQU07V0FBUyxFQUFFLFVBQVU7V0FBVTs7Ozs7O1NBRy9FLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO1VBQXlCLE9BQU87V0FBRSxTQUFTO1dBQVEsS0FBSztXQUFPLFVBQVU7V0FBUSxRQUFRO1dBQVM7b0JBQzlHLEVBQUUsVUFBVSxFQUFFLE9BQU8sU0FBUyxJQUM3QixFQUFFLE9BQU8sS0FBSyxVQUFVO0FBQ3RCLGVBQUksT0FBTyxNQUFNLE1BQU0sSUFBSSxFQUFHLFFBQU87QUFDckMsa0JBQ0Usd0JBQUMsUUFBRDtZQUF3QixPQUFPO2FBQUUsWUFBWTthQUFXLE9BQU87YUFBVyxRQUFRO2FBQW1DLFNBQVM7YUFBVyxVQUFVO2FBQVEsY0FBYzthQUFPLFlBQVk7YUFBUTtzQkFBcE07YUFDRyxNQUFNO2FBQU07YUFBRyxNQUFNO2FBQ2pCO2NBRkksTUFBTTs7OzttQkFFVjtZQUVULEdBRUYsd0JBQUMsUUFBRDtXQUFNLE9BQU87WUFBRSxVQUFVO1lBQVEsT0FBTztZQUFRO3FCQUFFO1dBQWdCOzs7OztVQUVoRTs7Ozs7U0FFTix3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBYjtXQUF3QjtZQUFHLEVBQUUsa0JBQWtCLEVBQUUsVUFBVSxHQUFHLGdCQUFnQjtXQUFDO1dBQVE7Ozs7OztTQUV2Rix3QkFBQyxVQUFEO1VBQVEsV0FBVTtVQUFlLGVBQWUsb0JBQW9CLEVBQUU7b0JBQUU7VUFFL0Q7Ozs7O1NBQ0w7Ozs7O2dCQUNGO1NBbEM4QixFQUFFOzs7O2NBa0NoQyxDQUNOO01BQ0U7Ozs7Z0JBRU4sd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQWE7T0FBa0Q7Ozs7O01BQ3hFOzs7OztLQUVIOzs7O2FBQ0g7Ozs7OztHQUdMLGlCQUNDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO0lBQWdCLE9BQU87S0FBRSxVQUFVO0tBQVMsS0FBSztLQUFHLE1BQU07S0FBRyxPQUFPO0tBQVEsUUFBUTtLQUFRLFlBQVk7S0FBbUIsU0FBUztLQUFRLGdCQUFnQjtLQUFVLFlBQVk7S0FBVSxRQUFRO0tBQU0sZ0JBQWdCO0tBQWE7Y0FDcFAsd0JBQUMsT0FBRDtLQUFLLFdBQVU7S0FBZ0IsT0FBTztNQUFFLFlBQVk7TUFBVyxTQUFTO01BQVEsY0FBYztNQUFRLE9BQU87TUFBUyxPQUFPO01BQVEsVUFBVTtNQUFZLFFBQVE7TUFBcUIsV0FBVztNQUFrQztlQUFyTztNQUNFLHdCQUFDLFVBQUQ7T0FBUSxlQUFlLGlCQUFpQixLQUFLO09BQUUsT0FBTztRQUFFLFVBQVU7UUFBWSxLQUFLO1FBQVEsT0FBTztRQUFRLFlBQVk7UUFBZSxRQUFRO1FBQVEsT0FBTztRQUFRLFFBQVE7UUFBVyxZQUFZO1FBQVE7T0FBRSxlQUFlLE1BQU0sRUFBRSxPQUFPLE1BQU0sUUFBUTtPQUFRLGVBQWUsTUFBTSxFQUFFLE9BQU8sTUFBTSxRQUFRO2lCQUMzUyx3QkFBQyxTQUFELEVBQVMsTUFBTSxJQUFNOzs7OztPQUNkOzs7OztNQUVULHdCQUFDLE1BQUQ7T0FBSSxPQUFPO1FBQUUsY0FBYztRQUFPLFVBQVU7UUFBUSxPQUFPO1FBQVEsWUFBWTtRQUFrQztpQkFBRTtPQUFvQzs7Ozs7TUFDdkosd0JBQUMsS0FBRDtPQUFHLE9BQU87UUFBRSxVQUFVO1FBQVEsT0FBTztRQUFRLGNBQWM7UUFBUTtpQkFBRyxjQUFjO09BQW1COzs7OztNQUV2Ryx3QkFBQyxPQUFEO09BQUssT0FBTztRQUFFLFNBQVM7UUFBUSxlQUFlO1FBQVUsS0FBSztRQUFRLFdBQVc7UUFBUyxXQUFXO1FBQVEsY0FBYztRQUFPLGNBQWM7UUFBUTtpQkFDcEosY0FBYyxVQUFVLGNBQWMsT0FBTyxTQUFTLElBQ3JELGNBQWMsT0FBTyxLQUFLLFVBQVU7UUFDbEMsTUFBTSxXQUFXLE9BQU8sTUFBTSxNQUFNLElBQUk7QUFDeEMsWUFBSSxZQUFZLEVBQUcsUUFBTztRQUUxQixNQUFNLGFBQWEsZ0JBQWdCLE1BQU0sVUFBVTtBQUVuRCxlQUNFLHdCQUFDLE9BQUQ7U0FBdUIsT0FBTztVQUFFLFNBQVM7VUFBUSxnQkFBZ0I7VUFBaUIsWUFBWTtVQUFVLFlBQVk7VUFBVyxTQUFTO1VBQWEsY0FBYztVQUFPLFFBQVE7VUFBcUI7bUJBQXZNLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7VUFBTSxPQUFPO1dBQUUsWUFBWTtXQUFRLFVBQVU7V0FBUSxPQUFPO1dBQVE7b0JBQXBFLENBQXNFLFVBQU8sTUFBTSxNQUFhOzs7OzttQkFDaEcsd0JBQUMsUUFBRDtVQUFNLE9BQU87V0FBRSxTQUFTO1dBQVMsVUFBVTtXQUFRLE9BQU87V0FBUTtvQkFBbEUsQ0FBb0Usc0JBQW1CLFNBQWdCOzs7OztrQkFDbkc7Ozs7bUJBQ04sd0JBQUMsT0FBRDtVQUFLLE9BQU87V0FBRSxTQUFTO1dBQVEsWUFBWTtXQUFVLEtBQUs7V0FBTztvQkFBakU7V0FDRSx3QkFBQyxVQUFEO1lBQ0UsTUFBSztZQUNMLGVBQWU7QUFDYixpQ0FBbUIsVUFBUztjQUMxQixHQUFHO2VBQ0YsTUFBTSxRQUFRLEtBQUssSUFBSSxJQUFJLEtBQUssTUFBTSxVQUFVLEtBQUssRUFBRTtjQUN6RCxFQUFFOztZQUVMLE9BQU87YUFBRSxPQUFPO2FBQVEsUUFBUTthQUFRLFlBQVk7YUFBUSxPQUFPO2FBQVEsUUFBUTthQUFrQixjQUFjO2FBQU8sUUFBUTthQUFXLFNBQVM7YUFBUSxZQUFZO2FBQVUsZ0JBQWdCO2FBQVU7c0JBRTlNLHdCQUFDLFNBQUQsRUFBUyxNQUFNLElBQU07Ozs7O1lBQ2Q7Ozs7O1dBRVQsd0JBQUMsU0FBRDtZQUNFLE1BQUs7WUFDTCxLQUFJO1lBQ0osS0FBSztZQUNMLE9BQU87WUFDUCxXQUFXLE1BQU07YUFDZixNQUFNLE1BQU0sS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLFVBQVUsT0FBTyxFQUFFLE9BQU8sTUFBTSxDQUFDLENBQUM7QUFDbkUsaUNBQW1CLFVBQVM7Y0FBRSxHQUFHO2VBQU8sTUFBTSxRQUFRO2NBQUssRUFBRTs7WUFFL0QsT0FBTzthQUFFLE9BQU87YUFBUSxXQUFXO2FBQVUsWUFBWTthQUFXLFFBQVE7YUFBa0IsT0FBTzthQUFRLGNBQWM7YUFBTyxTQUFTO2FBQU8sVUFBVTthQUFRLFNBQVM7YUFBUTtZQUNyTDs7Ozs7V0FFRix3QkFBQyxVQUFEO1lBQ0UsTUFBSztZQUNMLGVBQWU7QUFDYixpQkFBSSxhQUFhLFVBQVU7QUFDekIsa0NBQW1CLFVBQVM7ZUFDMUIsR0FBRztnQkFDRixNQUFNLFNBQVMsS0FBSyxNQUFNLFVBQVUsS0FBSztlQUMzQyxFQUFFOzs7WUFHUCxPQUFPO2FBQUUsT0FBTzthQUFRLFFBQVE7YUFBUSxZQUFZO2FBQVEsT0FBTzthQUFRLFFBQVE7YUFBa0IsY0FBYzthQUFPLFFBQVE7YUFBVyxTQUFTO2FBQVEsWUFBWTthQUFVLGdCQUFnQjthQUFVO3NCQUU5TSx3QkFBQyxRQUFELEVBQVEsTUFBTSxJQUFNOzs7OztZQUNiOzs7OztXQUNMOzs7OztrQkFDRjtXQTlDSSxNQUFNOzs7O2dCQThDVjtTQUVSLEdBRUYsd0JBQUMsS0FBRDtRQUFHLE9BQU87U0FBRSxVQUFVO1NBQVEsT0FBTztTQUFXLFdBQVc7U0FBVTtrQkFBRTtRQUFpRDs7Ozs7T0FFdEg7Ozs7O01BRU4sd0JBQUMsVUFBRDtPQUNFLGVBQWU7UUFDYixNQUFNLGdCQUFnQixPQUFPLFFBQVEsZ0JBQWdCLENBQUMsUUFBUSxDQUFDLE9BQU8sY0FBYyxXQUFXLEVBQUU7QUFFakcsWUFBSSxjQUFjLFdBQVcsR0FBRztBQUM5QixlQUFNLHdFQUF3RTtBQUM5RTs7QUFHRixvQkFBWSxTQUFTO1NBQ25CLElBQUksZUFBZSxDQUFDLEdBQUcsS0FBSztBQUU1Qix1QkFBYyxTQUFTLENBQUMsT0FBTyxjQUFjO1VBQzNDLE1BQU0sa0JBQWtCLGNBQWMsT0FBTyxNQUFLLE1BQUssRUFBRSxVQUFVLE1BQU07VUFDekUsTUFBTSxtQkFBbUIsa0JBQWtCLE9BQU8sZ0JBQWdCLE1BQU0sR0FBRztVQUUzRSxNQUFNLGlCQUFpQixhQUFhLFdBQ2pDLFNBQVMsS0FBSyxnQkFBZ0IsY0FBYyxlQUFlLEtBQUssVUFBVSxNQUM1RTtBQUVELGNBQUksa0JBQWtCLEdBQUc7V0FDdkIsTUFBTSxhQUFhLGFBQWE7V0FDaEMsTUFBTSxxQkFBcUIsV0FBVyxXQUFXO0FBRWpELGVBQUkscUJBQXFCLGtCQUFrQjtBQUN6QyxrQkFBTSxtQ0FBbUMsTUFBTSwrQkFBK0IsaUJBQWlCLEdBQUc7QUFDbEc7O0FBR0Ysd0JBQWEsa0JBQWtCO1lBQUUsR0FBRztZQUFZLFVBQVU7WUFBb0I7aUJBQ3pFO0FBQ0wsd0JBQWEsS0FBSztZQUNoQixHQUFHO1lBQ0k7WUFDRztZQUNRO1lBQ25CLENBQUM7O1dBRUo7QUFFRixnQkFBTztVQUNQO0FBRUYseUJBQWlCLEtBQUs7O09BRXhCLE9BQU87UUFBRSxPQUFPO1FBQVEsU0FBUztRQUFRLFlBQVk7UUFBVyxPQUFPO1FBQVEsUUFBUTtRQUFRLGNBQWM7UUFBTyxZQUFZO1FBQVEsUUFBUTtRQUFXLFdBQVc7UUFBa0MsWUFBWTtRQUFRO09BQzVOLGVBQWUsTUFBTSxFQUFFLE9BQU8sTUFBTSxhQUFhO09BQ2pELGVBQWUsTUFBTSxFQUFFLE9BQU8sTUFBTSxhQUFhO2lCQUNsRDtPQUVROzs7OztNQUNMOzs7Ozs7SUFDRjs7Ozs7R0FJUix3QkFBQyxPQUFEO0lBQUssV0FBVyxlQUFlLGlCQUFpQixTQUFTO2NBQXpEO0tBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxNQUFEO09BQUk7T0FBYSxRQUFRLFFBQVEsS0FBSyxNQUFNLE1BQU0sRUFBRSxVQUFVLEVBQUU7T0FBQztPQUFNOzs7O2dCQUN2RSx3QkFBQyxVQUFEO09BQVEsV0FBVTtPQUFpQixlQUFlLGtCQUFrQixNQUFNO2lCQUFFO09BQVU7Ozs7ZUFDbEY7Ozs7OztLQUNOLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNaLFFBQVEsV0FBVyxJQUNsQix3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBWTtPQUF5Qjs7OztpQkFFbEQsUUFBUSxLQUFJLFNBQ1Ysd0JBQUMsT0FBRDtPQUErQyxXQUFVO2lCQUF6RCxDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQWEsS0FBSztVQUFtQjs7Ozs7U0FDbEQsd0JBQUMsS0FBRDtVQUFHLE9BQU87V0FBRSxVQUFVO1dBQVEsT0FBTztXQUFRLFFBQVE7V0FBUztvQkFBOUQsQ0FBZ0UsV0FBTyx3QkFBQyxVQUFELFlBQVMsS0FBSyxPQUFlOzs7O21CQUFJOzs7Ozs7U0FDeEcsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWY7V0FDRSx3QkFBQyxVQUFEO1lBQVEsZUFBZSxrQkFBa0IsS0FBSyxhQUFhLEtBQUssT0FBTyxRQUFRO3NCQUFFLHdCQUFDLFNBQUQsRUFBUyxNQUFNLElBQUs7Ozs7O1lBQVM7Ozs7O1dBQzlHLHdCQUFDLFFBQUQsWUFBTyxLQUFLLFVBQWdCOzs7OztXQUM1Qix3QkFBQyxVQUFEO1lBQVEsZUFBZSxrQkFBa0IsS0FBSyxhQUFhLEtBQUssT0FBTyxNQUFNO3NCQUFFLHdCQUFDLFFBQUQsRUFBUSxNQUFNLElBQUs7Ozs7O1lBQVM7Ozs7O1dBQ3ZHOzs7Ozs7U0FDTix3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaEIsQ0FBZ0MsaUJBQ2hCLEtBQUssa0JBQWtCLEtBQUssVUFBVSxLQUFLLEtBQUssVUFBVSxnQkFBZ0IsQ0FDbkY7Ozs7OztTQUNIOzs7OztpQkFDTix3QkFBQyxTQUFEO1FBQVMsV0FBVTtRQUFhLGVBQWUsV0FBVyxRQUFRLFFBQU8sTUFBSyxFQUFFLEVBQUUsZ0JBQWdCLEtBQUssZUFBZSxFQUFFLFVBQVUsS0FBSyxPQUFPLENBQUM7UUFBSTs7OztnQkFDL0k7U0FkSSxHQUFHLEtBQUssWUFBWSxHQUFHLEtBQUs7Ozs7Y0FjaEMsQ0FDTjtNQUVBOzs7OztLQUNMLFFBQVEsU0FBUyxLQUNoQix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRCxZQUFNLGtCQUFxQjs7OztpQkFDM0Isd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWhCO1NBQStCO1NBQUUsZUFBZSxDQUFDLGdCQUFnQjtTQUFDO1NBQVc7Ozs7O2dCQUN6RTs7Ozs7Z0JBQ04sd0JBQUMsVUFBRDtPQUFRLFdBQVU7T0FBbUIsU0FBUztpQkFBaUI7T0FBYzs7OztlQUN6RTs7Ozs7O0tBRUo7Ozs7OztHQUNGOzs7Ozs7Ozs7RUFFVDs7QUFFRCxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImNhdGFsb2dvLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgYXBpLCB7IEJBU0VfVVJMIH0gZnJvbSBcIi4vYXBpXCI7IFxyXG5pbXBvcnQgXCIuL2NhdGFsb2dvLmNzc1wiO1xyXG5pbXBvcnQgeyBGYVNob3BwaW5nQ2FydCwgRmFUcmFzaCwgRmFTZWFyY2gsIEZhUGx1cywgRmFNaW51cywgRmFSZWNlaXB0LCBGYUNoZXZyb25Eb3duLCBGYUNoZXZyb25VcCwgRmFUaW1lcyB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcblxyXG5mdW5jdGlvbiBDYXRhbG9nbygpIHtcclxuICBjb25zdCBbcHJvZHVjdG9zLCBzZXRQcm9kdWN0b3NdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtjYXRlZ29yaWFzREIsIHNldENhdGVnb3JpYXNEQl0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2J1c3F1ZWRhLCBzZXRCdXNxdWVkYV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZ2VuZXJvc1NlbGVjY2lvbmFkb3MsIHNldEdlbmVyb3NTZWxlY2Npb25hZG9zXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbdGFsbGFzU2VsZWNjaW9uYWRhcywgc2V0VGFsbGFzU2VsZWNjaW9uYWRhc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2NhdGVnb3JpYXNTZWxlY2Npb25hZGFzLCBzZXRDYXRlZ29yaWFzU2VsZWNjaW9uYWRhc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2NvbG9yZXNTZWxlY2Npb25hZG9zLCBzZXRDb2xvcmVzU2VsZWNjaW9uYWRvc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2NhcnJpdG8sIHNldENhcnJpdG9dICA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbbW9zdHJhckNhcnJpdG8sIHNldE1vc3RyYXJDYXJyaXRvXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBcclxuICAvLyBFc3RhZG9zIHBhcmEgZWwgTW9kYWwgZGUgU2VsZWNjacOzbiBNw7psdGlwbGUgZGUgVGFsbGFzXHJcbiAgY29uc3QgW3Byb2R1Y3RvTW9kYWwsIHNldFByb2R1Y3RvTW9kYWxdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2NhbnRpZGFkZXNNb2RhbCwgc2V0Q2FudGlkYWRlc01vZGFsXSA9IHVzZVN0YXRlKHt9KTtcclxuXHJcbiAgLy8gRXN0YWRvcyBwYXJhIGNvbnRyb2xhciBsb3MgbWVuw7pzIGRlc3BsZWdhYmxlcyBkZSBsb3MgZmlsdHJvc1xyXG4gIGNvbnN0IFtkZXNwbGVnYWRvQ2F0LCBzZXREZXNwbGVnYWRvQ2F0XSA9IHVzZVN0YXRlKHRydWUpO1xyXG4gIGNvbnN0IFtkZXNwbGVnYWRvR2VuLCBzZXREZXNwbGVnYWRvR2VuXSA9IHVzZVN0YXRlKHRydWUpO1xyXG4gIGNvbnN0IFtkZXNwbGVnYWRvQ29sLCBzZXREZXNwbGVnYWRvQ29sXSA9IHVzZVN0YXRlKHRydWUpO1xyXG4gIGNvbnN0IFtkZXNwbGVnYWRvVGFsLCBzZXREZXNwbGVnYWRvVGFsXSA9IHVzZVN0YXRlKHRydWUpO1xyXG5cclxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBmZXRjaFByb2R1Y3RvcygpO1xyXG4gICAgZmV0Y2hDYXRlZ29yaWFzKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBmZXRjaFByb2R1Y3RvcyA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9wcm9kdWN0b3MvY2F0YWxvZ29cIik7XHJcbiAgICAgIHNldFByb2R1Y3RvcyhyZXNwb25zZS5kYXRhKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgYWwgdHJhZXIgcHJvZHVjdG9zOlwiLCBlcnIpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZldGNoQ2F0ZWdvcmlhcyA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9jYXRlZ29yaWFzXCIpO1xyXG4gICAgICBzZXRDYXRlZ29yaWFzREIocmVzcG9uc2UuZGF0YSk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGFsIHRyYWVyIGNhdGVnb3LDrWFzIGRlIEJEOlwiLCBlcnIpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vIEFicmUgZWwgbW9kYWwgZGUgbcO6bHRpcGxlcyB0YWxsYXMgbGltcGlhbmRvIGxhcyBzZWxlY2Npb25lcyBwcmV2aWFzXHJcbiAgY29uc3QgYWJyaXJNb2RhbFNlbGVjY2lvbiA9IChwcm9kdWN0bykgPT4ge1xyXG4gICAgc2V0UHJvZHVjdG9Nb2RhbChwcm9kdWN0byk7XHJcbiAgICBzZXRDYW50aWRhZGVzTW9kYWwoe30pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IG1vZGlmaWNhckNhbnRpZGFkID0gKGlkX3Byb2R1Y3RvLCB0YWxsYSwgYWNjaW9uKSA9PiB7XHJcbiAgICBzZXRDYXJyaXRvKChwcmV2KSA9PlxyXG4gICAgICBwcmV2Lm1hcCgoaXRlbSkgPT4ge1xyXG4gICAgICAgIGlmIChpdGVtLmlkX3Byb2R1Y3RvID09PSBpZF9wcm9kdWN0byAmJiBpdGVtLnRhbGxhID09PSB0YWxsYSkge1xyXG4gICAgICAgICAgY29uc3QgbnVldmFDYW50ID0gYWNjaW9uID09PSBcIm1hc1wiID8gaXRlbS5jYW50aWRhZCArIDEgOiBpdGVtLmNhbnRpZGFkIC0gMTtcclxuICAgICAgICAgIGNvbnN0IHN0b2NrTWF4ID0gaXRlbS5zdG9ja01heGltb1RhbGxhIHx8IDk5OTtcclxuXHJcbiAgICAgICAgICBpZiAobnVldmFDYW50ID4gc3RvY2tNYXgpIHtcclxuICAgICAgICAgICAgYWxlcnQoYExvIHNlbnRpbW9zLCBzb2xvIGhheSAke3N0b2NrTWF4fSB1bmlkYWRlcyBkaXNwb25pYmxlcyBwYXJhIGxhIHRhbGxhICR7dGFsbGF9YCk7XHJcbiAgICAgICAgICAgIHJldHVybiBpdGVtO1xyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICAgIHJldHVybiB7IC4uLml0ZW0sIGNhbnRpZGFkOiBNYXRoLm1heCgxLCBudWV2YUNhbnQpIH07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBpdGVtO1xyXG4gICAgICB9KVxyXG4gICAgKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBjYWxjdWxhclRvdGFsID0gKCkgPT4ge1xyXG4gICAgcmV0dXJuIGNhcnJpdG8ucmVkdWNlKChhY2MsIHApID0+IGFjYyArICgocC5wcmVjaW9Qcm9kdWN0byB8fCBwLnByZWNpbyB8fCAwKSAqIHAuY2FudGlkYWQpLCAwKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBmaW5hbGl6YXJDb21wcmEgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoY2Fycml0by5sZW5ndGggPT09IDApIHJldHVybiBhbGVydChcIkVsIGNhcnJpdG8gZXN0w6EgdmFjw61vXCIpO1xyXG5cclxuICAgIGNvbnN0IGlkVXN1YXJpb0xvZ3VlYWRvID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJpZF91c3VhcmlvXCIpIHx8IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXN1YXJpb19pZFwiKTtcclxuXHJcbiAgICBpZiAoIWlkVXN1YXJpb0xvZ3VlYWRvKSB7XHJcbiAgICAgIGFsZXJ0KFwiRGViZXMgaW5pY2lhciBzZXNpw7NuIHBhcmEgcmVhbGl6YXIgbGEgY29tcHJhXCIpO1xyXG4gICAgICBuYXZpZ2F0ZShcIi9sb2dpblwiKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IGRhdG9zUGFyYUVudmlhciA9IHsgXHJcbiAgICAgICAgaWRfdXN1YXJpbzogIWlzTmFOKGlkVXN1YXJpb0xvZ3VlYWRvKSA/IE51bWJlcihpZFVzdWFyaW9Mb2d1ZWFkbykgOiBpZFVzdWFyaW9Mb2d1ZWFkbyxcclxuICAgICAgICB0b3RhbDogY2FsY3VsYXJUb3RhbCgpLFxyXG4gICAgICAgIHByb2R1Y3RvczogY2Fycml0by5tYXAoaXRlbSA9PiAoe1xyXG4gICAgICAgICAgaWRfcHJvZHVjdG86IGl0ZW0uaWRfcHJvZHVjdG8sXHJcbiAgICAgICAgICBjYW50aWRhZDogaXRlbS5jYW50aWRhZCxcclxuICAgICAgICAgIHByZWNpb1Byb2R1Y3RvOiBpdGVtLnByZWNpb1Byb2R1Y3RvIHx8IGl0ZW0ucHJlY2lvLFxyXG4gICAgICAgICAgdGFsbGE6IGl0ZW0udGFsbGFcclxuICAgICAgICB9KSlcclxuICAgICAgfTtcclxuXHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLnBvc3QoXCIvcHJvZHVjdG9zL2ZpbmFsaXphci1jb21wcmFcIiwgZGF0b3NQYXJhRW52aWFyKTtcclxuXHJcbiAgICAgIGlmIChyZXNwb25zZS5zdGF0dXMgPT09IDIwMCB8fCByZXNwb25zZS5zdGF0dXMgPT09IDIwMSkge1xyXG4gICAgICAgIGFsZXJ0KFwiwqFDb21wcmEgZmluYWxpemFkYSBjb24gw6l4aXRvISDinKhcIik7XHJcbiAgICAgICAgc2V0Q2Fycml0byhbXSk7XHJcbiAgICAgICAgc2V0TW9zdHJhckNhcnJpdG8oZmFsc2UpO1xyXG4gICAgICAgIGZldGNoUHJvZHVjdG9zKCk7IFxyXG4gICAgICAgIG5hdmlnYXRlKFwiL2hvbWUvbWlzLXBlZGlkb3NcIik7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBlbiBlbCBwYWdvOlwiLCBlcnJvcik7XHJcbiAgICAgIGFsZXJ0KGVycm9yLnJlc3BvbnNlPy5kYXRhPy5NZXNzYWdlIHx8IGVycm9yLnJlc3BvbnNlPy5kYXRhPy5lcnJvciB8fCBcIkVycm9yIGFsIHByb2Nlc2FyIGxhIGNvbXByYVwiKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBub3JtYWxpemFyVGV4dG8gPSAodGV4dG8pID0+XHJcbiAgICB0ZXh0bz8udG9Mb3dlckNhc2UoKS5ub3JtYWxpemUoXCJORkRcIikucmVwbGFjZSgvW1xcdTAzMDAtXFx1MDM2Zl0vZywgXCJcIikudHJpbSgpIHx8IFwiXCI7XHJcblxyXG4gIC8vIEZpbHRyYWRvIGdlbmVyYWwgYWRhcHRhZG8gYWwgYXJyYXkgZGUgdGFsbGFzXHJcbiAgbGV0IHByb2R1Y3Rvc0ZpbHRyYWRvcyA9IHByb2R1Y3Rvcy5maWx0ZXIoKHApID0+XHJcbiAgICBub3JtYWxpemFyVGV4dG8ocC5ub21icmVQcm9kdWN0bykuaW5jbHVkZXMobm9ybWFsaXphclRleHRvKGJ1c3F1ZWRhKSlcclxuICApO1xyXG5cclxuICBpZiAoZ2VuZXJvc1NlbGVjY2lvbmFkb3MubGVuZ3RoID4gMCkge1xyXG4gICAgcHJvZHVjdG9zRmlsdHJhZG9zID0gcHJvZHVjdG9zRmlsdHJhZG9zLmZpbHRlcigocCkgPT5cclxuICAgICAgZ2VuZXJvc1NlbGVjY2lvbmFkb3Muc29tZSgoZykgPT4gbm9ybWFsaXphclRleHRvKGcpID09PSBub3JtYWxpemFyVGV4dG8ocC5nZW5lcm8pKVxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIGlmIChjYXRlZ29yaWFzU2VsZWNjaW9uYWRhcy5sZW5ndGggPiAwKSB7XHJcbiAgICBwcm9kdWN0b3NGaWx0cmFkb3MgPSBwcm9kdWN0b3NGaWx0cmFkb3MuZmlsdGVyKChwKSA9PlxyXG4gICAgICBjYXRlZ29yaWFzU2VsZWNjaW9uYWRhcy5zb21lKChjKSA9PiBub3JtYWxpemFyVGV4dG8oYykgPT09IG5vcm1hbGl6YXJUZXh0byhwLmNhdGVnb3JpYSkpXHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgaWYgKHRhbGxhc1NlbGVjY2lvbmFkYXMubGVuZ3RoID4gMCkge1xyXG4gICAgcHJvZHVjdG9zRmlsdHJhZG9zID0gcHJvZHVjdG9zRmlsdHJhZG9zLmZpbHRlcigocCkgPT4ge1xyXG4gICAgICBpZiAoIXAudGFsbGFzKSByZXR1cm4gZmFsc2U7XHJcbiAgICAgIHJldHVybiB0YWxsYXNTZWxlY2Npb25hZGFzLnNvbWUoKHQpID0+IHtcclxuICAgICAgICBjb25zdCBlbmNvbnRyYWRhID0gcC50YWxsYXMuZmluZChpdGVtID0+IGl0ZW0udGFsbGEudG9VcHBlckNhc2UoKSA9PT0gdC50b1VwcGVyQ2FzZSgpKTtcclxuICAgICAgICByZXR1cm4gZW5jb250cmFkYSAmJiBOdW1iZXIoZW5jb250cmFkYS5zdG9jaykgPiAwO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgaWYgKGNvbG9yZXNTZWxlY2Npb25hZG9zLmxlbmd0aCA+IDApIHtcclxuICAgIHByb2R1Y3Rvc0ZpbHRyYWRvcyA9IHByb2R1Y3Rvc0ZpbHRyYWRvcy5maWx0ZXIoKHApID0+XHJcbiAgICAgIGNvbG9yZXNTZWxlY2Npb25hZG9zLnNvbWUoKGNvbCkgPT4gbm9ybWFsaXphclRleHRvKGNvbCkgPT09IG5vcm1hbGl6YXJUZXh0byhwLmNvbG9yKSlcclxuICAgICk7XHJcbiAgfVxyXG5cclxuICBjb25zdCBsaW1waWFyWUNhcGl0YWxpemFyID0gKGFycikgPT4ge1xyXG4gICAgY29uc3QgdW5pY29zID0gbmV3IFNldCgpO1xyXG4gICAgYXJyLmZvckVhY2goaXRlbSA9PiB7XHJcbiAgICAgIGlmIChpdGVtKSB7XHJcbiAgICAgICAgbGV0IGxpbXBpbyA9IGl0ZW0udHJpbSgpO1xyXG4gICAgICAgIGxpbXBpbyA9IGxpbXBpby5jaGFyQXQoMCkudG9VcHBlckNhc2UoKSArIGxpbXBpby5zbGljZSgxKS50b0xvd2VyQ2FzZSgpO1xyXG4gICAgICAgIHVuaWNvcy5hZGQobGltcGlvKTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgICByZXR1cm4gQXJyYXkuZnJvbSh1bmljb3MpLnNvcnQoKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBsaXN0YUNhdFJhdyA9IGNhdGVnb3JpYXNEQi5sZW5ndGggPiAwIFxyXG4gICAgPyBjYXRlZ29yaWFzREIubWFwKGMgPT4gYy5ub21icmUpIFxyXG4gICAgOiBwcm9kdWN0b3MubWFwKHAgPT4gcC5jYXRlZ29yaWEpO1xyXG5cclxuICBjb25zdCBjYXRlZ29yaWFzRGlzcG9uaWJsZXMgPSBsaW1waWFyWUNhcGl0YWxpemFyKGxpc3RhQ2F0UmF3KTtcclxuICBjb25zdCBnZW5lcm9zRGlzcG9uaWJsZXMgPSBsaW1waWFyWUNhcGl0YWxpemFyKHByb2R1Y3Rvcy5tYXAocCA9PiBwLmdlbmVybykpO1xyXG4gIGNvbnN0IGNvbG9yZXNEaXNwb25pYmxlcyA9IGxpbXBpYXJZQ2FwaXRhbGl6YXIocHJvZHVjdG9zLm1hcChwID0+IHAuY29sb3IpKTtcclxuICBjb25zdCB0YWxsYXNEaXNwb25pYmxlcyA9IFtcIlNcIiwgXCJNXCIsIFwiTFwiLCBcIlhMXCIsIFwiWFhMXCJdO1xyXG5cclxuICBjb25zdCB0b2dnbGVGaWx0cm8gPSAodmFsb3IsIGxpc3RhLCBzZXRMaXN0YSkgPT4ge1xyXG4gICAgaWYgKGxpc3RhLmluY2x1ZGVzKHZhbG9yKSkge1xyXG4gICAgICBzZXRMaXN0YShsaXN0YS5maWx0ZXIoKGkpID0+IGkgIT09IHZhbG9yKSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRMaXN0YShbLi4ubGlzdGEsIHZhbG9yXSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiY2F0YWxvZ28tcGFnZVwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhdGFsb2dvLXRvb2xzXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZWFyY2gtYmFyXCI+XHJcbiAgICAgICAgICA8RmFTZWFyY2ggY2xhc3NOYW1lPVwic2VhcmNoLWljb25cIiAvPlxyXG4gICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCLCv1F1w6kgZXN0w6FzIGJ1c2NhbmRvIGhveT9cIlxyXG4gICAgICAgICAgICB2YWx1ZT17YnVzcXVlZGF9XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0QnVzcXVlZGEoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoZWFkZXItYWN0aW9uc1wiPlxyXG4gICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4tb3JkZXJzXCIgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoXCIvaG9tZS9taXMtcGVkaWRvc1wiKX0+XHJcbiAgICAgICAgICAgIDxGYVJlY2VpcHQgc2l6ZT17MTh9IC8+IDxzcGFuPk1pcyBQZWRpZG9zPC9zcGFuPlxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcnQtdHJpZ2dlclwiIG9uQ2xpY2s9eygpID0+IHNldE1vc3RyYXJDYXJyaXRvKCFtb3N0cmFyQ2Fycml0byl9PlxyXG4gICAgICAgICAgICA8RmFTaG9wcGluZ0NhcnQgc2l6ZT17MjJ9IC8+XHJcbiAgICAgICAgICAgIHtjYXJyaXRvLmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNhcnQtYmFkZ2VcIj5cclxuICAgICAgICAgICAgICAgIHtjYXJyaXRvLnJlZHVjZSgoYWNjLCBwKSA9PiBhY2MgKyBwLmNhbnRpZGFkLCAwKX1cclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhdGFsb2dvLWxheW91dFwiPlxyXG4gICAgICAgIHsvKiBTSURFQkFSIERFIEZJTFRST1MgKi99XHJcbiAgICAgICAgPGFzaWRlIGNsYXNzTmFtZT1cImNhdGFsb2dvLXNpZGViYXJcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2lkZWJhci1oZWFkZXItZmlsdGVyXCI+XHJcbiAgICAgICAgICAgIDxoMz5GaWx0cm9zIGRlIELDunNxdWVkYTwvaDM+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpbHRlci1zZWN0aW9uXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWNjb3JkaW9uLWhlYWRlclwiIG9uQ2xpY2s9eygpID0+IHNldERlc3BsZWdhZG9DYXQoIWRlc3BsZWdhZG9DYXQpfT5cclxuICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwic2lkZWJhci10aXRsZVwiPkNhdGVnb3LDrWE8L2g0PlxyXG4gICAgICAgICAgICAgIHtkZXNwbGVnYWRvQ2F0ID8gPEZhQ2hldnJvblVwIHNpemU9ezEyfSAvPiA6IDxGYUNoZXZyb25Eb3duIHNpemU9ezEyfSAvPn1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIHtkZXNwbGVnYWRvQ2F0ICYmIChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpbHRlci1vcHRpb25zLWxpc3RcIj5cclxuICAgICAgICAgICAgICAgIHtjYXRlZ29yaWFzRGlzcG9uaWJsZXMubWFwKChjYXQpID0+IChcclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGtleT17Y2F0fSBjbGFzc05hbWU9e2BjdXN0b20tY2hlY2tib3gtbGFiZWwgJHtjYXRlZ29yaWFzU2VsZWNjaW9uYWRhcy5pbmNsdWRlcyhjYXQpID8gJ2FjdGl2ZScgOiAnJ31gfT5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtjYXRlZ29yaWFzU2VsZWNjaW9uYWRhcy5pbmNsdWRlcyhjYXQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eygpID0+IHRvZ2dsZUZpbHRybyhjYXQsIGNhdGVnb3JpYXNTZWxlY2Npb25hZGFzLCBzZXRDYXRlZ29yaWFzU2VsZWNjaW9uYWRhcyl9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjaGVja2JveC1jdXN0b21cIj48L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY2hlY2tib3gtdGV4dFwiPntjYXR9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpbHRlci1zZWN0aW9uXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWNjb3JkaW9uLWhlYWRlclwiIG9uQ2xpY2s9eygpID0+IHNldERlc3BsZWdhZG9HZW4oIWRlc3BsZWdhZG9HZW4pfT5cclxuICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwic2lkZWJhci10aXRsZVwiPkfDqW5lcm88L2g0PlxyXG4gICAgICAgICAgICAgIHtkZXNwbGVnYWRvR2VuID8gPEZhQ2hldnJvblVwIHNpemU9ezEyfSAvPiA6IDxGYUNoZXZyb25Eb3duIHNpemU9ezEyfSAvPn1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIHtkZXNwbGVnYWRvR2VuICYmIChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpbHRlci1vcHRpb25zLWxpc3RcIj5cclxuICAgICAgICAgICAgICAgIHtnZW5lcm9zRGlzcG9uaWJsZXMubWFwKChnKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBrZXk9e2d9IGNsYXNzTmFtZT17YGN1c3RvbS1jaGVja2JveC1sYWJlbCAke2dlbmVyb3NTZWxlY2Npb25hZG9zLmluY2x1ZGVzKGcpID8gJ2FjdGl2ZScgOiAnJ31gfT5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtnZW5lcm9zU2VsZWNjaW9uYWRvcy5pbmNsdWRlcyhnKX1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoKSA9PiB0b2dnbGVGaWx0cm8oZywgZ2VuZXJvc1NlbGVjY2lvbmFkb3MsIHNldEdlbmVyb3NTZWxlY2Npb25hZG9zKX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNoZWNrYm94LWN1c3RvbVwiPjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjaGVja2JveC10ZXh0XCI+e2d9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7Y29sb3Jlc0Rpc3BvbmlibGVzLmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpbHRlci1zZWN0aW9uXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhY2NvcmRpb24taGVhZGVyXCIgb25DbGljaz17KCkgPT4gc2V0RGVzcGxlZ2Fkb0NvbCghZGVzcGxlZ2Fkb0NvbCl9PlxyXG4gICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInNpZGViYXItdGl0bGVcIj5Db2xvcjwvaDQ+XHJcbiAgICAgICAgICAgICAgICB7ZGVzcGxlZ2Fkb0NvbCA/IDxGYUNoZXZyb25VcCBzaXplPXsxMn0gLz4gOiA8RmFDaGV2cm9uRG93biBzaXplPXsxMn0gLz59XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAge2Rlc3BsZWdhZG9Db2wgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaWx0ZXItb3B0aW9ucy1saXN0XCI+XHJcbiAgICAgICAgICAgICAgICAgIHtjb2xvcmVzRGlzcG9uaWJsZXMubWFwKChjb2xvcikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBrZXk9e2NvbG9yfSBjbGFzc05hbWU9e2BjdXN0b20tY2hlY2tib3gtbGFiZWwgJHtjb2xvcmVzU2VsZWNjaW9uYWRvcy5pbmNsdWRlcyhjb2xvcikgPyAnYWN0aXZlJyA6ICcnfWB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2NvbG9yZXNTZWxlY2Npb25hZG9zLmluY2x1ZGVzKGNvbG9yKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eygpID0+IHRvZ2dsZUZpbHRybyhjb2xvciwgY29sb3Jlc1NlbGVjY2lvbmFkb3MsIHNldENvbG9yZXNTZWxlY2Npb25hZG9zKX1cclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjaGVja2JveC1jdXN0b21cIj48L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjaGVja2JveC10ZXh0XCI+e2NvbG9yfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpbHRlci1zZWN0aW9uXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWNjb3JkaW9uLWhlYWRlclwiIG9uQ2xpY2s9eygpID0+IHNldERlc3BsZWdhZG9UYWwoIWRlc3BsZWdhZG9UYWwpfT5cclxuICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwic2lkZWJhci10aXRsZVwiPlRhbGxhczwvaDQ+XHJcbiAgICAgICAgICAgICAge2Rlc3BsZWdhZG9UYWwgPyA8RmFDaGV2cm9uVXAgc2l6ZT17MTJ9IC8+IDogPEZhQ2hldnJvbkRvd24gc2l6ZT17MTJ9IC8+fVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAge2Rlc3BsZWdhZG9UYWwgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGFsbGFzLWZsZXhcIj5cclxuICAgICAgICAgICAgICAgIHt0YWxsYXNEaXNwb25pYmxlcy5tYXAoKHRhbGxhKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICBrZXk9e3RhbGxhfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHRhbGxhLWNoaXAtYnRuICR7dGFsbGFzU2VsZWNjaW9uYWRhcy5pbmNsdWRlcyh0YWxsYSkgPyBcImFjdGl2ZVwiIDogXCJcIn1gfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHRvZ2dsZUZpbHRybyh0YWxsYSwgdGFsbGFzU2VsZWNjaW9uYWRhcywgc2V0VGFsbGFzU2VsZWNjaW9uYWRhcyl9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7dGFsbGF9XHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2FzaWRlPlxyXG5cclxuICAgICAgICB7LyogTElTVEFETyBERSBQUk9EVUNUT1MgKi99XHJcbiAgICAgICAgPG1haW4gY2xhc3NOYW1lPVwicHJvZHVjdG9zLWNvbnRhaW5lclwiPlxyXG4gICAgICAgICAge3Byb2R1Y3Rvc0ZpbHRyYWRvcy5sZW5ndGggPiAwID8gKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2R1Y3Rvcy1ncmlkXCI+XHJcbiAgICAgICAgICAgICAge3Byb2R1Y3Rvc0ZpbHRyYWRvcy5tYXAoKHApID0+IChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZHVjdG8tY2FyZFwiIGtleT17cC5pZF9wcm9kdWN0b30+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW1nLXdyYXBwZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8aW1nIFxyXG4gICAgICAgICAgICAgICAgICAgICAgc3JjPXtwLmltYWdlbiA/IGAke0JBU0VfVVJMfSR7cC5pbWFnZW59YCA6IFwiL2ltZy9kZWZhdWx0LmpwZ1wifSBcclxuICAgICAgICAgICAgICAgICAgICAgIGFsdD17cC5ub21icmVQcm9kdWN0b30gXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkVycm9yPXsoZSkgPT4geyBlLnRhcmdldC5zcmMgPSBcIi9pbWcvZGVmYXVsdC5qcGdcIjsgfX0gXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZHVjdG8taW5mb1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxoND57cC5ub21icmVQcm9kdWN0b308L2g0PlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInAtdGFsbGFcIj5Db2xvcjoge3AuY29sb3IgfHwgXCJOL0FcIn0gfCBHZW46IHtwLmdlbmVybyB8fCBcIk4vQVwifTwvcD5cclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICB7LyogVmlzdWFsaXphY2nDs24gY29ycmVjdGEgZGUgdGFsbGFzIGRlc2RlIGVsIGFycmF5ICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGFsbGFzLWJhZGdlcy1jYXRhbG9nb1wiIHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywgZ2FwOiAnNXB4JywgZmxleFdyYXA6ICd3cmFwJywgbWFyZ2luOiAnOHB4IDAnIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAge3AudGFsbGFzICYmIHAudGFsbGFzLmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHAudGFsbGFzLm1hcCgodEl0ZW0pID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoTnVtYmVyKHRJdGVtLnN0b2NrKSA8PSAwKSByZXR1cm4gbnVsbDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4ga2V5PXt0SXRlbS50YWxsYX0gc3R5bGU9e3sgYmFja2dyb3VuZDogJyMxMjEyMTInLCBjb2xvcjogJyNmZjRkNGQnLCBib3JkZXI6ICcxcHggc29saWQgcmdiYSgyMjksIDksIDIwLCAwLjQpJywgcGFkZGluZzogJzJweCA2cHgnLCBmb250U2l6ZTogJzExcHgnLCBib3JkZXJSYWRpdXM6ICc0cHgnLCBmb250V2VpZ2h0OiAnYm9sZCcgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0SXRlbS50YWxsYX06IHt0SXRlbS5zdG9ja31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFNpemU6ICcxMXB4JywgY29sb3I6ICcjODg4JyB9fT5TaW4gc3RvY2s8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJwLXByZWNpb1wiPiR7KHAucHJlY2lvUHJvZHVjdG8gfHwgcC5wcmVjaW8gfHwgMCkudG9Mb2NhbGVTdHJpbmcoKX0gQ09QPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuLWFkZC1jYXJ0XCIgb25DbGljaz17KCkgPT4gYWJyaXJNb2RhbFNlbGVjY2lvbihwKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBBw7FhZGlyIGFsIGNhcnJpdG9cclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm5vLXJlc3VsdHMtYm94XCI+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibm8tcmVzdWx0c1wiPk5vIHNlIGVuY29udHJhcm9uIHByb2R1Y3RvcyBjb24gZXN0b3MgZmlsdHJvcy48L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L21haW4+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIE1PREFMIFBBUkEgU0VMRUNDSU9OQVIgTcOaTFRJUExFUyBUQUxMQVMgWSBDQU5USURBREVTICovfVxyXG4gICAgICB7cHJvZHVjdG9Nb2RhbCAmJiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtb2RhbC1vdmVybGF5XCIgc3R5bGU9e3sgcG9zaXRpb246ICdmaXhlZCcsIHRvcDogMCwgbGVmdDogMCwgd2lkdGg6ICcxMDAlJywgaGVpZ2h0OiAnMTAwJScsIGJhY2tncm91bmQ6ICdyZ2JhKDAsMCwwLDAuOCknLCBkaXNwbGF5OiAnZmxleCcsIGp1c3RpZnlDb250ZW50OiAnY2VudGVyJywgYWxpZ25JdGVtczogJ2NlbnRlcicsIHpJbmRleDogMTAwMCwgYmFja2Ryb3BGaWx0ZXI6ICdibHVyKDRweCknIH19PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtb2RhbC1jb250ZW50XCIgc3R5bGU9e3sgYmFja2dyb3VuZDogJyMxMjEyMTInLCBwYWRkaW5nOiAnMzBweCcsIGJvcmRlclJhZGl1czogJzE2cHgnLCB3aWR0aDogJzQyMHB4JywgY29sb3I6ICcjZmZmJywgcG9zaXRpb246ICdyZWxhdGl2ZScsIGJvcmRlcjogJzFweCBzb2xpZCAjZTUwOTE0JywgYm94U2hhZG93OiAnMCAwIDI1cHggcmdiYSgyMjksIDksIDIwLCAwLjQpJyB9fT5cclxuICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRQcm9kdWN0b01vZGFsKG51bGwpfSBzdHlsZT17eyBwb3NpdGlvbjogJ2Fic29sdXRlJywgdG9wOiAnMTVweCcsIHJpZ2h0OiAnMTVweCcsIGJhY2tncm91bmQ6ICd0cmFuc3BhcmVudCcsIGJvcmRlcjogJ25vbmUnLCBjb2xvcjogJyNhYWEnLCBjdXJzb3I6ICdwb2ludGVyJywgdHJhbnNpdGlvbjogJzAuMnMnIH19IG9uTW91c2VFbnRlcj17KGUpID0+IGUudGFyZ2V0LnN0eWxlLmNvbG9yID0gJyNmZmYnfSBvbk1vdXNlTGVhdmU9eyhlKSA9PiBlLnRhcmdldC5zdHlsZS5jb2xvciA9ICcjYWFhJ30+XHJcbiAgICAgICAgICAgICAgPEZhVGltZXMgc2l6ZT17MTh9IC8+XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgPGgzIHN0eWxlPXt7IG1hcmdpbkJvdHRvbTogJzhweCcsIGZvbnRTaXplOiAnMjBweCcsIGNvbG9yOiAnI2ZmZicsIHRleHRTaGFkb3c6ICcwIDAgMTBweCByZ2JhKDIyOSwgOSwgMjAsIDAuNSknIH19PlNlbGVjY2lvbmFyIFRhbGxhcyB5IENhbnRpZGFkZXM8L2gzPlxyXG4gICAgICAgICAgICA8cCBzdHlsZT17eyBmb250U2l6ZTogJzEzcHgnLCBjb2xvcjogJyNhYWEnLCBtYXJnaW5Cb3R0b206ICcyMHB4JyB9fT57cHJvZHVjdG9Nb2RhbC5ub21icmVQcm9kdWN0b308L3A+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywgZmxleERpcmVjdGlvbjogJ2NvbHVtbicsIGdhcDogJzEycHgnLCBtYXhIZWlnaHQ6ICcyNTBweCcsIG92ZXJmbG93WTogJ2F1dG8nLCBwYWRkaW5nUmlnaHQ6ICc1cHgnLCBtYXJnaW5Cb3R0b206ICcyMHB4JyB9fT5cclxuICAgICAgICAgICAgICB7cHJvZHVjdG9Nb2RhbC50YWxsYXMgJiYgcHJvZHVjdG9Nb2RhbC50YWxsYXMubGVuZ3RoID4gMCA/IChcclxuICAgICAgICAgICAgICAgIHByb2R1Y3RvTW9kYWwudGFsbGFzLm1hcCgodEl0ZW0pID0+IHtcclxuICAgICAgICAgICAgICAgICAgY29uc3Qgc3RvY2tNYXggPSBOdW1iZXIodEl0ZW0uc3RvY2spIHx8IDA7XHJcbiAgICAgICAgICAgICAgICAgIGlmIChzdG9ja01heCA8PSAwKSByZXR1cm4gbnVsbDtcclxuXHJcbiAgICAgICAgICAgICAgICAgIGNvbnN0IGNhbnRBY3R1YWwgPSBjYW50aWRhZGVzTW9kYWxbdEl0ZW0udGFsbGFdIHx8IDA7XHJcblxyXG4gICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXt0SXRlbS50YWxsYX0gc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBqdXN0aWZ5Q29udGVudDogJ3NwYWNlLWJldHdlZW4nLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywgYmFja2dyb3VuZDogJyMxYTFhMWEnLCBwYWRkaW5nOiAnMTBweCAxNXB4JywgYm9yZGVyUmFkaXVzOiAnOHB4JywgYm9yZGVyOiAnMXB4IHNvbGlkICMyYTJhMmEnIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFdlaWdodDogJ2JvbGQnLCBmb250U2l6ZTogJzE1cHgnLCBjb2xvcjogJyNmZmYnIH19PlRhbGxhIHt0SXRlbS50YWxsYX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGRpc3BsYXk6ICdibG9jaycsIGZvbnRTaXplOiAnMTFweCcsIGNvbG9yOiAnIzg4OCcgfX0+U3RvY2sgZGlzcG9uaWJsZToge3N0b2NrTWF4fTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBnYXA6ICc4cHgnIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldENhbnRpZGFkZXNNb2RhbChwcmV2ID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFt0SXRlbS50YWxsYV06IE1hdGgubWF4KDAsIChwcmV2W3RJdGVtLnRhbGxhXSB8fCAwKSAtIDEpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogJzI4cHgnLCBoZWlnaHQ6ICcyOHB4JywgYmFja2dyb3VuZDogJyMyMjInLCBjb2xvcjogJyNmZmYnLCBib3JkZXI6ICcxcHggc29saWQgIzQ0NCcsIGJvcmRlclJhZGl1czogJzRweCcsIGN1cnNvcjogJ3BvaW50ZXInLCBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcicgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxGYU1pbnVzIHNpemU9ezEwfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbWluPVwiMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4PXtzdG9ja01heH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y2FudEFjdHVhbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHZhbCA9IE1hdGgubWF4KDAsIE1hdGgubWluKHN0b2NrTWF4LCBOdW1iZXIoZS50YXJnZXQudmFsdWUpKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRDYW50aWRhZGVzTW9kYWwocHJldiA9PiAoeyAuLi5wcmV2LCBbdEl0ZW0udGFsbGFdOiB2YWwgfSkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6ICc0NXB4JywgdGV4dEFsaWduOiAnY2VudGVyJywgYmFja2dyb3VuZDogJyMwYTBhMGEnLCBib3JkZXI6ICcxcHggc29saWQgIzQ0NCcsIGNvbG9yOiAnI2ZmZicsIGJvcmRlclJhZGl1czogJzRweCcsIHBhZGRpbmc6ICc0cHgnLCBmb250U2l6ZTogJzE0cHgnLCBvdXRsaW5lOiAnbm9uZScgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGNhbnRBY3R1YWwgPCBzdG9ja01heCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRDYW50aWRhZGVzTW9kYWwocHJldiA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW3RJdGVtLnRhbGxhXTogKHByZXZbdEl0ZW0udGFsbGFdIHx8IDApICsgMVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogJzI4cHgnLCBoZWlnaHQ6ICcyOHB4JywgYmFja2dyb3VuZDogJyMyMjInLCBjb2xvcjogJyNmZmYnLCBib3JkZXI6ICcxcHggc29saWQgIzQ0NCcsIGJvcmRlclJhZGl1czogJzRweCcsIGN1cnNvcjogJ3BvaW50ZXInLCBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcicgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxGYVBsdXMgc2l6ZT17MTB9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICA8cCBzdHlsZT17eyBmb250U2l6ZTogJzEzcHgnLCBjb2xvcjogJyNlNTA5MTQnLCB0ZXh0QWxpZ246ICdjZW50ZXInIH19Pk5vIGhheSB0YWxsYXMgZGlzcG9uaWJsZXMgcGFyYSBlc3RlIHByb2R1Y3RvLjwvcD5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxidXR0b24gXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc3Qgc2VsZWNjaW9uYWRhcyA9IE9iamVjdC5lbnRyaWVzKGNhbnRpZGFkZXNNb2RhbCkuZmlsdGVyKChbdGFsbGEsIGNhbnRpZGFkXSkgPT4gY2FudGlkYWQgPiAwKTtcclxuXHJcbiAgICAgICAgICAgICAgICBpZiAoc2VsZWNjaW9uYWRhcy5sZW5ndGggPT09IDApIHtcclxuICAgICAgICAgICAgICAgICAgYWxlcnQoXCJQb3IgZmF2b3Igc2VsZWNjaW9uYSBhbCBtZW5vcyB1bmEgY2FudGlkYWQgbWF5b3IgYSAwIGVuIGFsZ3VuYSB0YWxsYS5cIik7XHJcbiAgICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICBzZXRDYXJyaXRvKChwcmV2KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGxldCBudWV2b0NhcnJpdG8gPSBbLi4ucHJldl07XHJcblxyXG4gICAgICAgICAgICAgICAgICBzZWxlY2Npb25hZGFzLmZvckVhY2goKFt0YWxsYSwgY2FudGlkYWRdKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgdEl0ZW1FbmNvbnRyYWRvID0gcHJvZHVjdG9Nb2RhbC50YWxsYXMuZmluZCh0ID0+IHQudGFsbGEgPT09IHRhbGxhKTtcclxuICAgICAgICAgICAgICAgICAgICBjb25zdCBzdG9ja01heGltb1RhbGxhID0gdEl0ZW1FbmNvbnRyYWRvID8gTnVtYmVyKHRJdGVtRW5jb250cmFkby5zdG9jaykgOiA5OTk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGluZGV4RXhpc3RlbnRlID0gbnVldm9DYXJyaXRvLmZpbmRJbmRleChcclxuICAgICAgICAgICAgICAgICAgICAgIChpdGVtKSA9PiBpdGVtLmlkX3Byb2R1Y3RvID09PSBwcm9kdWN0b01vZGFsLmlkX3Byb2R1Y3RvICYmIGl0ZW0udGFsbGEgPT09IHRhbGxhXHJcbiAgICAgICAgICAgICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGluZGV4RXhpc3RlbnRlID49IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGl0ZW1BY3R1YWwgPSBudWV2b0NhcnJpdG9baW5kZXhFeGlzdGVudGVdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgY29uc3QgbnVldmFDYW50aWRhZFRvdGFsID0gaXRlbUFjdHVhbC5jYW50aWRhZCArIGNhbnRpZGFkO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIGlmIChudWV2YUNhbnRpZGFkVG90YWwgPiBzdG9ja01heGltb1RhbGxhKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFsZXJ0KGBMYSBjYW50aWRhZCB0b3RhbCBwYXJhIGxhIHRhbGxhICR7dGFsbGF9IGV4Y2VkZSBlbCBzdG9jayBkaXNwb25pYmxlICgke3N0b2NrTWF4aW1vVGFsbGF9KWApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgbnVldm9DYXJyaXRvW2luZGV4RXhpc3RlbnRlXSA9IHsgLi4uaXRlbUFjdHVhbCwgY2FudGlkYWQ6IG51ZXZhQ2FudGlkYWRUb3RhbCB9O1xyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBudWV2b0NhcnJpdG8ucHVzaCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnByb2R1Y3RvTW9kYWwsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRhbGxhOiB0YWxsYSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2FudGlkYWQ6IGNhbnRpZGFkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdG9ja01heGltb1RhbGxhOiBzdG9ja01heGltb1RhbGxhXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgICAgICAgcmV0dXJuIG51ZXZvQ2Fycml0bztcclxuICAgICAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgICAgIHNldFByb2R1Y3RvTW9kYWwobnVsbCk7XHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogJzEwMCUnLCBwYWRkaW5nOiAnMTJweCcsIGJhY2tncm91bmQ6ICcjZTUwOTE0JywgY29sb3I6ICcjZmZmJywgYm9yZGVyOiAnbm9uZScsIGJvcmRlclJhZGl1czogJzhweCcsIGZvbnRXZWlnaHQ6ICdib2xkJywgY3Vyc29yOiAncG9pbnRlcicsIGJveFNoYWRvdzogJzAgMCAxNXB4IHJnYmEoMjI5LCA5LCAyMCwgMC42KScsIHRyYW5zaXRpb246ICcwLjJzJyB9fVxyXG4gICAgICAgICAgICAgIG9uTW91c2VFbnRlcj17KGUpID0+IGUudGFyZ2V0LnN0eWxlLmJhY2tncm91bmQgPSAnI2ZmMWUyYid9XHJcbiAgICAgICAgICAgICAgb25Nb3VzZUxlYXZlPXsoZSkgPT4gZS50YXJnZXQuc3R5bGUuYmFja2dyb3VuZCA9ICcjZTUwOTE0J31cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIEHDkUFESVIgQUwgQ0FSUklUT1xyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG5cclxuICAgICAgey8qIENBUlJJVE8gRFJBV0VSICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17YGNhcnQtZHJhd2VyICR7bW9zdHJhckNhcnJpdG8gPyBcIm9wZW5cIiA6IFwiXCJ9YH0+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJ0LWRyYXdlci1oZWFkZXJcIj5cclxuICAgICAgICAgIDxoMz5UVSBDQVJSSVRPICh7Y2Fycml0by5yZWR1Y2UoKGFjYywgaSkgPT4gYWNjICsgaS5jYW50aWRhZCwgMCl9KTwvaDM+XHJcbiAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0bi1jbG9zZS1jYXJ0XCIgb25DbGljaz17KCkgPT4gc2V0TW9zdHJhckNhcnJpdG8oZmFsc2UpfT7inJU8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcnQtZHJhd2VyLWJvZHlcIj5cclxuICAgICAgICAgIHtjYXJyaXRvLmxlbmd0aCA9PT0gMCA/IChcclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZW1wdHktbXNnXCI+RWwgY2Fycml0byBlc3TDoSB2YWPDrW88L3A+XHJcbiAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICBjYXJyaXRvLm1hcChpdGVtID0+IChcclxuICAgICAgICAgICAgICA8ZGl2IGtleT17YCR7aXRlbS5pZF9wcm9kdWN0b30tJHtpdGVtLnRhbGxhfWB9IGNsYXNzTmFtZT1cImNhcnQtaXRlbS1wcm9cIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FydC1pdGVtLWluZm9cIj5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiaXRlbS1uYW1lXCI+e2l0ZW0ubm9tYnJlUHJvZHVjdG99PC9wPlxyXG4gICAgICAgICAgICAgICAgICA8cCBzdHlsZT17eyBmb250U2l6ZTogJzEycHgnLCBjb2xvcjogJyNhYWEnLCBtYXJnaW46ICcycHggMCcgfX0+VGFsbGE6IDxzdHJvbmc+e2l0ZW0udGFsbGF9PC9zdHJvbmc+PC9wPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInF0eS1jb250cm9sc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gbW9kaWZpY2FyQ2FudGlkYWQoaXRlbS5pZF9wcm9kdWN0bywgaXRlbS50YWxsYSwgXCJtZW5vc1wiKX0+PEZhTWludXMgc2l6ZT17MTB9Lz48L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj57aXRlbS5jYW50aWRhZH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBtb2RpZmljYXJDYW50aWRhZChpdGVtLmlkX3Byb2R1Y3RvLCBpdGVtLnRhbGxhLCBcIm1hc1wiKX0+PEZhUGx1cyBzaXplPXsxMH0vPjwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaXRlbS1zdWJ0b3RhbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFN1YnRvdGFsOiAkeygoaXRlbS5wcmVjaW9Qcm9kdWN0byB8fCBpdGVtLnByZWNpbyB8fCAwKSAqIGl0ZW0uY2FudGlkYWQpLnRvTG9jYWxlU3RyaW5nKCl9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPEZhVHJhc2ggY2xhc3NOYW1lPVwiYnRuLXJlbW92ZVwiIG9uQ2xpY2s9eygpID0+IHNldENhcnJpdG8oY2Fycml0by5maWx0ZXIoaSA9PiAhKGkuaWRfcHJvZHVjdG8gPT09IGl0ZW0uaWRfcHJvZHVjdG8gJiYgaS50YWxsYSA9PT0gaXRlbS50YWxsYSkpKX0gLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKSlcclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAge2NhcnJpdG8ubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcnQtZHJhd2VyLWZvb3RlclwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcnQtdG90YWwtc2VjdGlvblwiPlxyXG4gICAgICAgICAgICAgIDxzcGFuPlRPVEFMIEEgUEFHQVI6PC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRvdGFsLWFtb3VudFwiPiR7Y2FsY3VsYXJUb3RhbCgpLnRvTG9jYWxlU3RyaW5nKCl9IENPUDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuLWNoZWNrb3V0LXByb1wiIG9uQ2xpY2s9e2ZpbmFsaXphckNvbXByYX0+UEFHQVI8L2J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQ2F0YWxvZ287Il19