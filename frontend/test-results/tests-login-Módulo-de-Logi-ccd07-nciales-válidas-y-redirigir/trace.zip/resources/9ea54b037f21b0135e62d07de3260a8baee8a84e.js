import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/app.jsx");import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=66677652"; const React = __vite__cjsImport0_react;
import { BrowserRouter, Routes, Route, Navigate } from "/node_modules/.vite/deps/react-router-dom.js?v=66677652";
import Catalogo from "/src/catalogo.jsx";
import Inventario from "/src/inventario.jsx";
import Login from "/src/login.jsx";
import Home from "/src/home.jsx";
import Usuarios from "/src/usuarios.jsx";
import Bienvenida from "/src/bienvenida.jsx";
import Registro from "/src/registro.jsx";
import Recuperar from "/src/recuperar.jsx";
import Perfil from "/src/perfil.jsx";
import MisPedidos from "/src/MisPedidos.jsx";
import ReporteVentas from "/src/ReporteVentas.jsx";
import Proveedores from "/src/proveedores.jsx";
import Landing from "/src/landing.jsx";
var _jsxFileName = "C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/app.jsx";
import __vite__cjsImport15_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=66677652"; const _jsxDEV = __vite__cjsImport15_react_jsxDevRuntime["jsxDEV"];
const RutaAdmin = ({ children }) => {
	const rol = localStorage.getItem("rol");
	return rol === "admin" ? children : /* @__PURE__ */ _jsxDEV(Navigate, { to: "/home/catalogo" }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 19,
		columnNumber: 39
	}, this);
};
_c = RutaAdmin;
function App() {
	return /* @__PURE__ */ _jsxDEV(BrowserRouter, { children: /* @__PURE__ */ _jsxDEV(Routes, { children: [
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/",
			element: /* @__PURE__ */ _jsxDEV(Landing, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 27,
				columnNumber: 34
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 27,
			columnNumber: 9
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/login",
			element: /* @__PURE__ */ _jsxDEV(Login, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 28,
				columnNumber: 39
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 28,
			columnNumber: 9
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/registro",
			element: /* @__PURE__ */ _jsxDEV(Registro, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 29,
				columnNumber: 42
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 29,
			columnNumber: 9
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/recuperar",
			element: /* @__PURE__ */ _jsxDEV(Recuperar, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 30,
				columnNumber: 43
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 30,
			columnNumber: 9
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/home",
			element: /* @__PURE__ */ _jsxDEV(Home, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 33,
				columnNumber: 38
			}, this),
			children: [
				/* @__PURE__ */ _jsxDEV(Route, {
					index: true,
					element: /* @__PURE__ */ _jsxDEV(Bienvenida, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 34,
						columnNumber: 33
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 34,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "perfil",
					element: /* @__PURE__ */ _jsxDEV(Perfil, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 35,
						columnNumber: 41
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 35,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "catalogo",
					element: /* @__PURE__ */ _jsxDEV(Catalogo, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 36,
						columnNumber: 43
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 36,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "mis-pedidos",
					element: /* @__PURE__ */ _jsxDEV(MisPedidos, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 37,
						columnNumber: 46
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 37,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "usuarios",
					element: /* @__PURE__ */ _jsxDEV(RutaAdmin, { children: /* @__PURE__ */ _jsxDEV(Usuarios, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 40,
						columnNumber: 23
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 40,
						columnNumber: 12
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 39,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "inventario",
					element: /* @__PURE__ */ _jsxDEV(RutaAdmin, { children: /* @__PURE__ */ _jsxDEV(Inventario, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 44,
						columnNumber: 24
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 44,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 43,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "reporte-ventas",
					element: /* @__PURE__ */ _jsxDEV(RutaAdmin, { children: /* @__PURE__ */ _jsxDEV(ReporteVentas, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 47,
						columnNumber: 24
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 47,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 46,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "proveedores",
					element: /* @__PURE__ */ _jsxDEV(RutaAdmin, { children: /* @__PURE__ */ _jsxDEV(Proveedores, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 50,
						columnNumber: 24
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 50,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 49,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 33,
			columnNumber: 9
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "*",
			element: /* @__PURE__ */ _jsxDEV(Navigate, { to: "/" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 55,
				columnNumber: 34
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 55,
			columnNumber: 9
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 25,
		columnNumber: 7
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 24,
		columnNumber: 5
	}, this);
}
_c2 = App;
export default App;
var _c, _c2;
$RefreshReg$(_c, "RutaAdmin");
$RefreshReg$(_c2, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/app.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/app.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/app.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/app.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsZUFBZSxRQUFRLE9BQU8sZ0JBQWdCO0FBQ3ZELE9BQU8sY0FBYztBQUNyQixPQUFPLGdCQUFnQjtBQUN2QixPQUFPLFdBQVc7QUFDbEIsT0FBTyxVQUFVO0FBQ2pCLE9BQU8sY0FBYztBQUNyQixPQUFPLGdCQUFnQjtBQUN2QixPQUFPLGNBQWM7QUFDckIsT0FBTyxlQUFlO0FBQ3RCLE9BQU8sWUFBWTtBQUNuQixPQUFPLGdCQUFnQjtBQUN2QixPQUFPLG1CQUFtQjtBQUMxQixPQUFPLGlCQUFpQjtBQUN4QixPQUFPLGFBQWE7OztBQUVwQixNQUFNLGFBQWEsRUFBRSxlQUFlO0NBQ2xDLE1BQU0sTUFBTSxhQUFhLFFBQVEsTUFBTTtBQUN2QyxRQUFPLFFBQVEsVUFBVSxXQUFXLHdCQUFDLFVBQUQsRUFBVSxJQUFHLGtCQUFtQjs7Ozs7OztBQUd0RSxTQUFTLE1BQU07QUFDYixRQUNFLHdCQUFDLGVBQUQsWUFDRSx3QkFBQyxRQUFEO0VBRUUsd0JBQUMsT0FBRDtHQUFPLE1BQUs7R0FBSSxTQUFTLHdCQUFDLFNBQUQsRUFBVzs7Ozs7R0FBSTs7Ozs7RUFDeEMsd0JBQUMsT0FBRDtHQUFPLE1BQUs7R0FBUyxTQUFTLHdCQUFDLE9BQUQsRUFBUzs7Ozs7R0FBSTs7Ozs7RUFDM0Msd0JBQUMsT0FBRDtHQUFPLE1BQUs7R0FBWSxTQUFTLHdCQUFDLFVBQUQsRUFBWTs7Ozs7R0FBSTs7Ozs7RUFDakQsd0JBQUMsT0FBRDtHQUFPLE1BQUs7R0FBYSxTQUFTLHdCQUFDLFdBQUQsRUFBYTs7Ozs7R0FBSTs7Ozs7RUFHbkQsd0JBQUMsT0FBRDtHQUFPLE1BQUs7R0FBUSxTQUFTLHdCQUFDLE1BQUQsRUFBUTs7Ozs7YUFBckM7SUFDRSx3QkFBQyxPQUFEO0tBQU87S0FBTSxTQUFTLHdCQUFDLFlBQUQsRUFBYzs7Ozs7S0FBSTs7Ozs7SUFDeEMsd0JBQUMsT0FBRDtLQUFPLE1BQUs7S0FBUyxTQUFTLHdCQUFDLFFBQUQsRUFBVTs7Ozs7S0FBSTs7Ozs7SUFDNUMsd0JBQUMsT0FBRDtLQUFPLE1BQUs7S0FBVyxTQUFTLHdCQUFDLFVBQUQsRUFBWTs7Ozs7S0FBSTs7Ozs7SUFDaEQsd0JBQUMsT0FBRDtLQUFPLE1BQUs7S0FBYyxTQUFTLHdCQUFDLFlBQUQsRUFBYzs7Ozs7S0FBSTs7Ozs7SUFFckQsd0JBQUMsT0FBRDtLQUFPLE1BQUs7S0FBVyxTQUN0Qix3QkFBQyxXQUFELFlBQVcsd0JBQUMsVUFBRCxFQUFZOzs7O2VBQVk7Ozs7O0tBQzlCOzs7OztJQUVOLHdCQUFDLE9BQUQ7S0FBTyxNQUFLO0tBQWEsU0FDdkIsd0JBQUMsV0FBRCxZQUFXLHdCQUFDLFlBQUQsRUFBYzs7OztlQUFZOzs7OztLQUNuQzs7Ozs7SUFDSix3QkFBQyxPQUFEO0tBQU8sTUFBSztLQUFpQixTQUMzQix3QkFBQyxXQUFELFlBQVcsd0JBQUMsZUFBRCxFQUFpQjs7OztlQUFZOzs7OztLQUN0Qzs7Ozs7SUFDSix3QkFBQyxPQUFEO0tBQU8sTUFBSztLQUFjLFNBQ3hCLHdCQUFDLFdBQUQsWUFBVyx3QkFBQyxhQUFELEVBQWU7Ozs7ZUFBWTs7Ozs7S0FDcEM7Ozs7O0lBQ0U7Ozs7OztFQUdSLHdCQUFDLE9BQUQ7R0FBTyxNQUFLO0dBQUksU0FBUyx3QkFBQyxVQUFELEVBQVUsSUFBRyxLQUFNOzs7OztHQUFJOzs7OztFQUN6Qzs7OztXQUNLOzs7Ozs7O0FBSXBCLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiYXBwLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IEJyb3dzZXJSb3V0ZXIsIFJvdXRlcywgUm91dGUsIE5hdmlnYXRlIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IENhdGFsb2dvIGZyb20gXCIuL2NhdGFsb2dvXCI7IFxyXG5pbXBvcnQgSW52ZW50YXJpbyBmcm9tIFwiLi9pbnZlbnRhcmlvXCI7IFxyXG5pbXBvcnQgTG9naW4gZnJvbSAnLi9sb2dpbic7XHJcbmltcG9ydCBIb21lIGZyb20gJy4vaG9tZSc7XHJcbmltcG9ydCBVc3VhcmlvcyBmcm9tICcuL3VzdWFyaW9zJztcclxuaW1wb3J0IEJpZW52ZW5pZGEgZnJvbSAnLi9iaWVudmVuaWRhJztcclxuaW1wb3J0IFJlZ2lzdHJvIGZyb20gJy4vcmVnaXN0cm8nOyBcclxuaW1wb3J0IFJlY3VwZXJhciBmcm9tICcuL3JlY3VwZXJhcic7XHJcbmltcG9ydCBQZXJmaWwgZnJvbSAnLi9wZXJmaWwnOyBcclxuaW1wb3J0IE1pc1BlZGlkb3MgZnJvbSBcIi4vTWlzUGVkaWRvc1wiO1xyXG5pbXBvcnQgUmVwb3J0ZVZlbnRhcyBmcm9tIFwiLi9SZXBvcnRlVmVudGFzXCI7XHJcbmltcG9ydCBQcm92ZWVkb3JlcyBmcm9tICcuL3Byb3ZlZWRvcmVzJztcclxuaW1wb3J0IExhbmRpbmcgZnJvbSAnLi9sYW5kaW5nJztcclxuXHJcbmNvbnN0IFJ1dGFBZG1pbiA9ICh7IGNoaWxkcmVuIH0pID0+IHtcclxuICBjb25zdCByb2wgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgncm9sJyk7XHJcbiAgcmV0dXJuIHJvbCA9PT0gJ2FkbWluJyA/IGNoaWxkcmVuIDogPE5hdmlnYXRlIHRvPVwiL2hvbWUvY2F0YWxvZ29cIiAvPjtcclxufTtcclxuXHJcbmZ1bmN0aW9uIEFwcCgpIHtcclxuICByZXR1cm4gKFxyXG4gICAgPEJyb3dzZXJSb3V0ZXI+XHJcbiAgICAgIDxSb3V0ZXM+XHJcbiAgICAgICAgey8qIDEuIFJ1dGFzIFDDumJsaWNhcyAqL31cclxuICAgICAgICA8Um91dGUgcGF0aD1cIi9cIiBlbGVtZW50PXs8TGFuZGluZyAvPn0gLz5cclxuICAgICAgICA8Um91dGUgcGF0aD1cIi9sb2dpblwiIGVsZW1lbnQ9ezxMb2dpbiAvPn0gLz5cclxuICAgICAgICA8Um91dGUgcGF0aD1cIi9yZWdpc3Ryb1wiIGVsZW1lbnQ9ezxSZWdpc3RybyAvPn0gLz5cclxuICAgICAgICA8Um91dGUgcGF0aD1cIi9yZWN1cGVyYXJcIiBlbGVtZW50PXs8UmVjdXBlcmFyIC8+fSAvPlxyXG4gICAgICAgIFxyXG4gICAgICAgIHsvKiAyLiBFc3RydWN0dXJhIGRlIEhvbWUgY29uIFJ1dGFzIEhpamFzICovfVxyXG4gICAgICAgIDxSb3V0ZSBwYXRoPVwiL2hvbWVcIiBlbGVtZW50PXs8SG9tZSAvPn0+XHJcbiAgICAgICAgICA8Um91dGUgaW5kZXggZWxlbWVudD17PEJpZW52ZW5pZGEgLz59IC8+IFxyXG4gICAgICAgICAgPFJvdXRlIHBhdGg9XCJwZXJmaWxcIiBlbGVtZW50PXs8UGVyZmlsIC8+fSAvPlxyXG4gICAgICAgICAgPFJvdXRlIHBhdGg9XCJjYXRhbG9nb1wiIGVsZW1lbnQ9ezxDYXRhbG9nbyAvPn0gLz5cclxuICAgICAgICAgIDxSb3V0ZSBwYXRoPVwibWlzLXBlZGlkb3NcIiBlbGVtZW50PXs8TWlzUGVkaWRvcyAvPn0gLz5cclxuXHJcbiAgICAgICAgICA8Um91dGUgcGF0aD1cInVzdWFyaW9zXCIgZWxlbWVudD17XHJcbiAgICAgICAgICAgPFJ1dGFBZG1pbj48VXN1YXJpb3MgLz48L1J1dGFBZG1pbj5cclxuICAgICAgICAgICAgfSAvPlxyXG5cclxuICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiaW52ZW50YXJpb1wiIGVsZW1lbnQ9e1xyXG4gICAgICAgICAgICA8UnV0YUFkbWluPjxJbnZlbnRhcmlvIC8+PC9SdXRhQWRtaW4+XHJcbiAgICAgICAgICB9IC8+XHJcbiAgICAgICAgICA8Um91dGUgcGF0aD1cInJlcG9ydGUtdmVudGFzXCIgZWxlbWVudD17XHJcbiAgICAgICAgICAgIDxSdXRhQWRtaW4+PFJlcG9ydGVWZW50YXMgLz48L1J1dGFBZG1pbj5cclxuICAgICAgICAgIH0gLz5cclxuICAgICAgICAgIDxSb3V0ZSBwYXRoPVwicHJvdmVlZG9yZXNcIiBlbGVtZW50PXtcclxuICAgICAgICAgICAgPFJ1dGFBZG1pbj48UHJvdmVlZG9yZXMgLz48L1J1dGFBZG1pbj5cclxuICAgICAgICAgIH0gLz5cclxuICAgICAgICA8L1JvdXRlPlxyXG5cclxuICAgICAgICB7LyogMy4gUmVkaXJlY2Npw7NuIHBvciBkZWZlY3RvICovfVxyXG4gICAgICAgIDxSb3V0ZSBwYXRoPVwiKlwiIGVsZW1lbnQ9ezxOYXZpZ2F0ZSB0bz1cIi9cIiAvPn0gLz5cclxuICAgICAgPC9Sb3V0ZXM+XHJcbiAgICA8L0Jyb3dzZXJSb3V0ZXI+XHJcbiAgKTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQXBwOyJdfQ==