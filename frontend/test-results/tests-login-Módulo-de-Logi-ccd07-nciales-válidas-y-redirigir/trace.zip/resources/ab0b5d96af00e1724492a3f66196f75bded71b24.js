import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/perfil.jsx");import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=66677652"; const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];
import api from "/src/api.js";
import { jwtDecode } from "/node_modules/.vite/deps/jwt-decode.js?v=66677652";
import "/src/Perfil.css";
var _jsxFileName = "C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/perfil.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=66677652"; const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
const Perfil = () => {
	_s();
	const [nombre, setNombre] = useState("");
	const [password, setPassword] = useState("");
	const [email, setEmail] = useState("");
	const [cargando, setCargando] = useState(false);
	const [telefono, setTelefono] = useState("");
	const [direccion, setDireccion] = useState("");
	useEffect(() => {
		const token = localStorage.getItem("token");
		if (token) {
			try {
				const decoded = jwtDecode(token);
				const userEmail = decoded.email;
				setEmail(userEmail);
				api.get(`/auth/perfil/${userEmail}`).then((res) => {
					setNombre(res.data.nombre || "");
					setTelefono(res.data.telefono || "");
					setDireccion(res.data.direccion || "");
				}).catch((err) => console.error("Error al obtener datos:", err));
			} catch (error) {
				console.error("Error al decodificar token:", error);
			}
		}
	}, []);
	const handleUpdate = async (e) => {
		e.preventDefault();
		setCargando(true);
		try {
			const response = await api.put("/auth/perfil/actualizar", {
				nombre,
				password,
				email,
				telefono,
				direccion
			});
			if (response.data.Status === "Exito") {
				if (response.data.Token) {
					localStorage.setItem("token", response.data.Token);
				}
				alert("✨ ¡Perfil actualizado con éxito! ✨");
				window.location.href = "/home";
			}
		} catch (err) {
			console.error(err);
			alert("❌ Error al actualizar: Verifica la conexión con el servidor");
		} finally {
			setCargando(false);
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "perfil-full-screen",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "perfil-glass-card",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "perfil-avatar",
					children: nombre ? nombre.charAt(0).toUpperCase() : "U"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 65,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("h2", {
					className: "perfil-main-title",
					children: "Configuración de Perfil"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 68,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "perfil-user-email",
					children: email
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 69,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("form", {
					onSubmit: handleUpdate,
					className: "perfil-modern-form",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "modern-input-group",
							children: [/* @__PURE__ */ _jsxDEV("label", { children: "Nombre de Usuario" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 73,
								columnNumber: 25
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: nombre,
								onChange: (e) => setNombre(e.target.value),
								placeholder: "Escribe tu nombre",
								required: true
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 74,
								columnNumber: 25
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 72,
							columnNumber: 21
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "modern-input-group",
							children: [
								/* @__PURE__ */ _jsxDEV("label", { children: "Nueva Contraseña" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 84,
									columnNumber: 25
								}, this),
								/* @__PURE__ */ _jsxDEV("input", {
									type: "password",
									value: password,
									onChange: (e) => setPassword(e.target.value),
									placeholder: "Dejar en blanco para no cambiar"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 85,
									columnNumber: 25
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "input-hint",
									children: "Solo si deseas cambiarla"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 91,
									columnNumber: 25
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 83,
							columnNumber: 21
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "modern-input-group",
							children: [/* @__PURE__ */ _jsxDEV("label", { children: "Correo Electrónico" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 95,
								columnNumber: 25
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "email",
								value: email,
								onChange: (e) => setEmail(e.target.value),
								placeholder: "Escribe tu email",
								required: true
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 96,
								columnNumber: 25
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 94,
							columnNumber: 21
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "modern-input-group",
							children: [/* @__PURE__ */ _jsxDEV("label", { children: "Teléfono" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 106,
								columnNumber: 25
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: telefono,
								onChange: (e) => setTelefono(e.target.value),
								placeholder: "Escribe tu teléfono"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 107,
								columnNumber: 25
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 105,
							columnNumber: 21
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "modern-input-group",
							children: [/* @__PURE__ */ _jsxDEV("label", { children: "Dirección" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 116,
								columnNumber: 25
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: direccion,
								onChange: (e) => setDireccion(e.target.value),
								placeholder: "Escribe tu dirección"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 117,
								columnNumber: 25
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 115,
							columnNumber: 21
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							type: "submit",
							className: "btn-perfil-submit",
							disabled: cargando,
							children: cargando ? "GUARDANDO..." : "GUARDAR CAMBIOS"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 125,
							columnNumber: 21
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 71,
					columnNumber: 17
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 64,
			columnNumber: 13
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 63,
		columnNumber: 9
	}, this);
};
_s(Perfil, "PIeUpUASoLPkQF/e9WuWTDMCQKg=");
_c = Perfil;
export default Perfil;
var _c;
$RefreshReg$(_c, "Perfil");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/perfil.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/perfil.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/perfil.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/perfil.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQWlCO0FBQzNDLE9BQU8sU0FBUztBQUNoQixTQUFTLGlCQUFpQjtBQUMxQixPQUFPOzs7O0FBRVAsTUFBTSxlQUFlOztDQUNqQixNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsR0FBRztDQUN4QyxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsR0FBRztDQUM1QyxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsR0FBRztDQUN0QyxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsTUFBTTtDQUMvQyxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsR0FBRztDQUM1QyxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxHQUFHO0FBRTlDLGlCQUFnQjtFQUNaLE1BQU0sUUFBUSxhQUFhLFFBQVEsUUFBUTtBQUMzQyxNQUFJLE9BQU87QUFDUCxPQUFJO0lBQ0EsTUFBTSxVQUFVLFVBQVUsTUFBTTtJQUNoQyxNQUFNLFlBQVksUUFBUTtBQUMxQixhQUFTLFVBQVU7QUFFbkIsUUFBSSxJQUFJLGdCQUFnQixZQUFZLENBQy9CLE1BQUssUUFBTztBQUNULGVBQVUsSUFBSSxLQUFLLFVBQVUsR0FBRztBQUNoQyxpQkFBWSxJQUFJLEtBQUssWUFBWSxHQUFHO0FBQ3BDLGtCQUFhLElBQUksS0FBSyxhQUFhLEdBQUc7TUFDeEMsQ0FDRCxPQUFNLFFBQU8sUUFBUSxNQUFNLDJCQUEyQixJQUFJLENBQUM7WUFDM0QsT0FBTztBQUNaLFlBQVEsTUFBTSwrQkFBK0IsTUFBTTs7O0lBRzVELEVBQUUsQ0FBQztDQUVOLE1BQU0sZUFBZSxPQUFPLE1BQU07QUFDOUIsSUFBRSxnQkFBZ0I7QUFDbEIsY0FBWSxLQUFLO0FBQ2pCLE1BQUk7R0FDQSxNQUFNLFdBQVcsTUFBTSxJQUFJLElBQUksMkJBQTJCO0lBQzlDO0lBQ0U7SUFDSDtJQUNHO0lBQ0M7SUFDZCxDQUFDO0FBRUYsT0FBSSxTQUFTLEtBQUssV0FBVyxTQUFTO0FBQ2xDLFFBQUksU0FBUyxLQUFLLE9BQU87QUFDckIsa0JBQWEsUUFBUSxTQUFTLFNBQVMsS0FBSyxNQUFNOztBQUV0RCxVQUFNLHFDQUFxQztBQUMzQyxXQUFPLFNBQVMsT0FBTzs7V0FFdEIsS0FBSztBQUNWLFdBQVEsTUFBTSxJQUFJO0FBQ2xCLFNBQU0sOERBQThEO1lBQzlEO0FBQ04sZUFBWSxNQUFNOzs7QUFJMUIsUUFDSSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUNYLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFDSSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNWLFNBQVMsT0FBTyxPQUFPLEVBQUUsQ0FBQyxhQUFhLEdBQUc7S0FDekM7Ozs7O0lBQ04sd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBb0I7S0FBNEI7Ozs7O0lBQzlELHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQXFCO0tBQVU7Ozs7O0lBRTVDLHdCQUFDLFFBQUQ7S0FBTSxVQUFVO0tBQWMsV0FBVTtlQUF4QztNQUNJLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0ksd0JBQUMsU0FBRCxZQUFPLHFCQUF5Qjs7OztpQkFDaEMsd0JBQUMsU0FBRDtRQUNJLE1BQUs7UUFDTCxPQUFPO1FBQ1AsV0FBVSxNQUFLLFVBQVUsRUFBRSxPQUFPLE1BQU07UUFDeEMsYUFBWTtRQUNaO1FBQ0Y7Ozs7Z0JBQ0E7Ozs7OztNQUVOLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0ksd0JBQUMsU0FBRCxZQUFPLG9CQUF3Qjs7Ozs7UUFDL0Isd0JBQUMsU0FBRDtTQUNJLE1BQUs7U0FDTCxPQUFPO1NBQ1AsV0FBVSxNQUFLLFlBQVksRUFBRSxPQUFPLE1BQU07U0FDMUMsYUFBWTtTQUNkOzs7OztRQUNGLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFhO1NBQStCOzs7OztRQUMxRDs7Ozs7O01BRU4sd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDSSx3QkFBQyxTQUFELFlBQU8sc0JBQTBCOzs7O2lCQUNqQyx3QkFBQyxTQUFEO1FBQ0ksTUFBSztRQUNMLE9BQU87UUFDUCxXQUFVLE1BQUssU0FBUyxFQUFFLE9BQU8sTUFBTTtRQUN2QyxhQUFZO1FBQ1o7UUFDRjs7OztnQkFDQTs7Ozs7O01BRU4sd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDSSx3QkFBQyxTQUFELFlBQU8sWUFBZ0I7Ozs7aUJBQ3ZCLHdCQUFDLFNBQUQ7UUFDSSxNQUFLO1FBQ0wsT0FBTztRQUNQLFdBQVUsTUFBSyxZQUFZLEVBQUUsT0FBTyxNQUFNO1FBQzFDLGFBQVk7UUFDZDs7OztnQkFDQTs7Ozs7O01BRU4sd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDSSx3QkFBQyxTQUFELFlBQU8sYUFBaUI7Ozs7aUJBQ3hCLHdCQUFDLFNBQUQ7UUFDSSxNQUFLO1FBQ0wsT0FBTztRQUNQLFdBQVUsTUFBSyxhQUFhLEVBQUUsT0FBTyxNQUFNO1FBQzNDLGFBQVk7UUFDZDs7OztnQkFDQTs7Ozs7O01BRU4sd0JBQUMsVUFBRDtPQUFRLE1BQUs7T0FBUyxXQUFVO09BQW9CLFVBQVU7aUJBQ3pELFdBQVcsaUJBQWlCO09BQ3hCOzs7OztNQUNOOzs7Ozs7SUFDTDs7Ozs7O0VBQ0o7Ozs7Ozs7O0FBSWQsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJwZXJmaWwuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgYXBpIGZyb20gJy4vYXBpJzsgXHJcbmltcG9ydCB7IGp3dERlY29kZSB9IGZyb20gXCJqd3QtZGVjb2RlXCI7XHJcbmltcG9ydCAnLi9QZXJmaWwuY3NzJztcclxuXHJcbmNvbnN0IFBlcmZpbCA9ICgpID0+IHtcclxuICAgIGNvbnN0IFtub21icmUsIHNldE5vbWJyZV0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgICBjb25zdCBbcGFzc3dvcmQsIHNldFBhc3N3b3JkXSA9IHVzZVN0YXRlKCcnKTtcclxuICAgIGNvbnN0IFtlbWFpbCwgc2V0RW1haWxdID0gdXNlU3RhdGUoJycpO1xyXG4gICAgY29uc3QgW2NhcmdhbmRvLCBzZXRDYXJnYW5kb10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgICBjb25zdCBbdGVsZWZvbm8sIHNldFRlbGVmb25vXSA9IHVzZVN0YXRlKCcnKTtcclxuICAgIGNvbnN0IFtkaXJlY2Npb24sIHNldERpcmVjY2lvbl0gPSB1c2VTdGF0ZSgnJyk7XHJcblxyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBjb25zdCB0b2tlbiA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKCd0b2tlbicpO1xyXG4gICAgICAgIGlmICh0b2tlbikge1xyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgZGVjb2RlZCA9IGp3dERlY29kZSh0b2tlbik7XHJcbiAgICAgICAgICAgICAgICBjb25zdCB1c2VyRW1haWwgPSBkZWNvZGVkLmVtYWlsO1xyXG4gICAgICAgICAgICAgICAgc2V0RW1haWwodXNlckVtYWlsKTtcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgYXBpLmdldChgL2F1dGgvcGVyZmlsLyR7dXNlckVtYWlsfWApXHJcbiAgICAgICAgICAgICAgICAgICAgLnRoZW4ocmVzID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0Tm9tYnJlKHJlcy5kYXRhLm5vbWJyZSB8fCAnJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFRlbGVmb25vKHJlcy5kYXRhLnRlbGVmb25vIHx8ICcnKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0RGlyZWNjaW9uKHJlcy5kYXRhLmRpcmVjY2lvbiB8fCAnJyk7ICAgICBcclxuICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIC5jYXRjaChlcnIgPT4gY29uc29sZS5lcnJvcihcIkVycm9yIGFsIG9idGVuZXIgZGF0b3M6XCIsIGVycikpO1xyXG4gICAgICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGFsIGRlY29kaWZpY2FyIHRva2VuOlwiLCBlcnJvcik7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9LCBbXSk7XHJcblxyXG4gICAgY29uc3QgaGFuZGxlVXBkYXRlID0gYXN5bmMgKGUpID0+IHtcclxuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgc2V0Q2FyZ2FuZG8odHJ1ZSk7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkucHV0KCcvYXV0aC9wZXJmaWwvYWN0dWFsaXphcicsIHsgXHJcbiAgICAgICAgICAgICAgICBub21icmU6IG5vbWJyZSwgXHJcbiAgICAgICAgICAgICAgICBwYXNzd29yZDogcGFzc3dvcmQsIFxyXG4gICAgICAgICAgICAgICAgZW1haWw6IGVtYWlsLFxyXG4gICAgICAgICAgICAgICAgdGVsZWZvbm86IHRlbGVmb25vLFxyXG4gICAgICAgICAgICAgICAgZGlyZWNjaW9uOiBkaXJlY2Npb25cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuZGF0YS5TdGF0dXMgPT09IFwiRXhpdG9cIikge1xyXG4gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGEuVG9rZW4pIHtcclxuICAgICAgICAgICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgndG9rZW4nLCByZXNwb25zZS5kYXRhLlRva2VuKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGFsZXJ0KFwi4pyoIMKhUGVyZmlsIGFjdHVhbGl6YWRvIGNvbiDDqXhpdG8hIOKcqFwiKTtcclxuICAgICAgICAgICAgICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gJy9ob21lJzsgXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgICAgY29uc29sZS5lcnJvcihlcnIpO1xyXG4gICAgICAgICAgICBhbGVydChcIuKdjCBFcnJvciBhbCBhY3R1YWxpemFyOiBWZXJpZmljYSBsYSBjb25leGnDs24gY29uIGVsIHNlcnZpZG9yXCIpO1xyXG4gICAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgICAgIHNldENhcmdhbmRvKGZhbHNlKTtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwZXJmaWwtZnVsbC1zY3JlZW5cIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwZXJmaWwtZ2xhc3MtY2FyZFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwZXJmaWwtYXZhdGFyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge25vbWJyZSA/IG5vbWJyZS5jaGFyQXQoMCkudG9VcHBlckNhc2UoKSA6ICdVJ31cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInBlcmZpbC1tYWluLXRpdGxlXCI+Q29uZmlndXJhY2nDs24gZGUgUGVyZmlsPC9oMj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInBlcmZpbC11c2VyLWVtYWlsXCI+e2VtYWlsfTwvcD5cclxuXHJcbiAgICAgICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlVXBkYXRlfSBjbGFzc05hbWU9XCJwZXJmaWwtbW9kZXJuLWZvcm1cIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1vZGVybi1pbnB1dC1ncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWw+Tm9tYnJlIGRlIFVzdWFyaW88L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e25vbWJyZX0gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXROb21icmUoZS50YXJnZXQudmFsdWUpfSBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRXNjcmliZSB0dSBub21icmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWQgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibW9kZXJuLWlucHV0LWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbD5OdWV2YSBDb250cmFzZcOxYTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJwYXNzd29yZFwiIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3Bhc3N3b3JkfSBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldFBhc3N3b3JkKGUudGFyZ2V0LnZhbHVlKX0gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkRlamFyIGVuIGJsYW5jbyBwYXJhIG5vIGNhbWJpYXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbnB1dC1oaW50XCI+U29sbyBzaSBkZXNlYXMgY2FtYmlhcmxhPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1vZGVybi1pbnB1dC1ncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWw+Q29ycmVvIEVsZWN0csOzbmljbzwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJlbWFpbFwiIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2VtYWlsfSBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldEVtYWlsKGUudGFyZ2V0LnZhbHVlKX0gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVzY3JpYmUgdHUgZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWQgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibW9kZXJuLWlucHV0LWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbD5UZWzDqWZvbm88L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3RlbGVmb25vfSBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldFRlbGVmb25vKGUudGFyZ2V0LnZhbHVlKX0gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVzY3JpYmUgdHUgdGVsw6lmb25vXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtb2Rlcm4taW5wdXQtZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsPkRpcmVjY2nDs248L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2RpcmVjY2lvbn0gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXREaXJlY2Npb24oZS50YXJnZXQudmFsdWUpfSBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRXNjcmliZSB0dSBkaXJlY2Npw7NuXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCIgY2xhc3NOYW1lPVwiYnRuLXBlcmZpbC1zdWJtaXRcIiBkaXNhYmxlZD17Y2FyZ2FuZG99PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7Y2FyZ2FuZG8gPyAnR1VBUkRBTkRPLi4uJyA6ICdHVUFSREFSIENBTUJJT1MnfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBQZXJmaWw7Il19