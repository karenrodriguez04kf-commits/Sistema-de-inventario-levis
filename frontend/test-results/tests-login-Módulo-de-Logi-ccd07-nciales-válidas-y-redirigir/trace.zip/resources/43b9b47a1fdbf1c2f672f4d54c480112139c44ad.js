import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/usuarios.jsx");import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=66677652"; const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];
import api from "/src/api.js";
import "/src/usuarios.css";
var _jsxFileName = "C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/usuarios.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=66677652"; const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
const Usuarios = () => {
	_s();
	const [usuarios, setUsuarios] = useState([]);
	const [nombre, setNombre] = useState("");
	const [email, setEmail] = useState("");
	const [password, setPassword] = useState("");
	const [rol, setRol] = useState("cliente");
	const [telefono, setTelefono] = useState("");
	const [direccion, setDireccion] = useState("");
	const [editandoId, setEditandoId] = useState(null);
	useEffect(() => {
		cargarUsuarios();
	}, []);
	const cargarUsuarios = async () => {
		try {
			const res = await api.get("/usuarios");
			setUsuarios(res.data);
		} catch (err) {
			console.error("Error al cargar usuarios:", err);
		}
	};
	const handleSubmit = async (e) => {
		e.preventDefault();
		if (!nombre.trim()) return alert("El nombre es obligatorio");
		if (!email.trim()) return alert("El email es obligatorio");
		// Si estamos creando uno nuevo, exigimos contraseña
		if (!editandoId && !password.trim()) {
			return alert("La contraseña es obligatoria para nuevos usuarios");
		}
		const datosUsuario = {
			nombre,
			email,
			...password && { password },
			rol,
			telefono,
			direccion
		};
		try {
			if (editandoId) {
				await api.put(`/usuarios/${editandoId}`, datosUsuario);
				setEditandoId(null);
				alert("Usuario actualizado exitosamente ✨");
			} else {
				await api.post("/usuarios", datosUsuario);
				alert("Usuario registrado exitosamente ✅");
			}
			// Limpiar formulario completo
			setNombre("");
			setEmail("");
			setPassword("");
			setRol("cliente");
			setTelefono("");
			setDireccion("");
			cargarUsuarios();
		} catch (err) {
			console.error("Error en la operación:", err);
			alert("Error: revisa los datos o si el email ya existe");
		}
	};
	const iniciarEdicion = (usuario) => {
		setEditandoId(usuario.id_usuario);
		setNombre(usuario.nombre);
		setEmail(usuario.email);
		setPassword("");
		setRol(usuario.rol || "cliente");
		setTelefono(usuario.telefono || "");
		setDireccion(usuario.direccion || "");
	};
	const eliminarUsuario = async (id) => {
		if (window.confirm("¿Mano, seguro que quieres borrar este usuario del sistema?")) {
			try {
				await api.delete(`/usuarios/${id}`);
				cargarUsuarios();
			} catch (err) {
				console.error("Error al eliminar:", err);
				alert("No se pudo eliminar el usuario");
			}
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "clientes-page",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "clientes-header",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "logo-levis",
					children: "LEVI'S"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 96,
					columnNumber: 17
				}, this), /* @__PURE__ */ _jsxDEV("div", { children: /* @__PURE__ */ _jsxDEV("span", { children: "GESTIÓN DE USUARIOS Y ADMINISTRADORES" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 97,
					columnNumber: 22
				}, this) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 97,
					columnNumber: 17
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 95,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("h2", {
				className: "seccion-titulo",
				children: "Administración General de Cuentas"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 100,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("form", {
				onSubmit: handleSubmit,
				className: "clientes-form",
				children: [
					/* @__PURE__ */ _jsxDEV("input", {
						type: "text",
						placeholder: "NOMBRE",
						value: nombre,
						onChange: (e) => setNombre(e.target.value),
						required: true
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 103,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						type: "email",
						placeholder: "EMAIL",
						value: email,
						onChange: (e) => setEmail(e.target.value),
						required: true
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 104,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						type: "password",
						placeholder: editandoId ? "NUEVA CONTRASEÑA (Opcional)" : "CONTRASEÑA",
						value: password,
						onChange: (e) => setPassword(e.target.value),
						...!editandoId && { required: true }
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 107,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV("select", {
						value: rol,
						onChange: (e) => setRol(e.target.value),
						required: true,
						className: "select-rol",
						children: [/* @__PURE__ */ _jsxDEV("option", {
							value: "cliente",
							children: "Cliente"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 117,
							columnNumber: 21
						}, this), /* @__PURE__ */ _jsxDEV("option", {
							value: "admin",
							children: "Administrador"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 118,
							columnNumber: 21
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 116,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						type: "text",
						placeholder: "TELÉFONO",
						value: telefono,
						onChange: (e) => setTelefono(e.target.value)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 121,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						type: "text",
						placeholder: "DIRECCIÓN",
						value: direccion,
						onChange: (e) => setDireccion(e.target.value)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 122,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						type: "submit",
						className: `btn-submit ${editandoId ? "btn-editar" : "btn-agregar"}`,
						children: editandoId ? "GUARDAR CAMBIOS" : "+ AGREGAR USUARIO"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 124,
						columnNumber: 17
					}, this),
					editandoId && /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: () => {
							setEditandoId(null);
							setNombre("");
							setEmail("");
							setPassword("");
							setRol("cliente");
							setTelefono("");
							setDireccion("");
						},
						className: "btn-cancelar",
						children: "Cancelar"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 129,
						columnNumber: 21
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 102,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "tabla-container",
				children: /* @__PURE__ */ _jsxDEV("table", {
					className: "tabla-clientes",
					children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", { children: [
						/* @__PURE__ */ _jsxDEV("th", { children: "ID" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 151,
							columnNumber: 29
						}, this),
						/* @__PURE__ */ _jsxDEV("th", { children: "NOMBRE" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 152,
							columnNumber: 29
						}, this),
						/* @__PURE__ */ _jsxDEV("th", { children: "EMAIL" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 153,
							columnNumber: 29
						}, this),
						/* @__PURE__ */ _jsxDEV("th", { children: "ROL" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 154,
							columnNumber: 29
						}, this),
						/* @__PURE__ */ _jsxDEV("th", { children: "TELÉFONO" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 155,
							columnNumber: 29
						}, this),
						/* @__PURE__ */ _jsxDEV("th", { children: "DIRECCIÓN" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 156,
							columnNumber: 29
						}, this),
						/* @__PURE__ */ _jsxDEV("th", { children: "ACCIONES" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 157,
							columnNumber: 29
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 150,
						columnNumber: 25
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 149,
						columnNumber: 21
					}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: usuarios.map((usuario) => /* @__PURE__ */ _jsxDEV("tr", { children: [
						/* @__PURE__ */ _jsxDEV("td", { children: ["#", usuario.id_usuario] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 163,
							columnNumber: 33
						}, this),
						/* @__PURE__ */ _jsxDEV("td", {
							className: "bold",
							children: usuario.nombre
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 164,
							columnNumber: 33
						}, this),
						/* @__PURE__ */ _jsxDEV("td", { children: usuario.email }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 165,
							columnNumber: 33
						}, this),
						/* @__PURE__ */ _jsxDEV("td", { children: /* @__PURE__ */ _jsxDEV("span", {
							className: `badge-rol ${usuario.rol === "admin" ? "badge-admin" : "badge-cliente"}`,
							children: usuario.rol.toUpperCase()
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 167,
							columnNumber: 37
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 166,
							columnNumber: 33
						}, this),
						/* @__PURE__ */ _jsxDEV("td", { children: usuario.telefono || "N/A" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 171,
							columnNumber: 33
						}, this),
						/* @__PURE__ */ _jsxDEV("td", { children: usuario.direccion || "N/A" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 172,
							columnNumber: 33
						}, this),
						/* @__PURE__ */ _jsxDEV("td", { children: [/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => iniciarEdicion(usuario),
							className: "btn-tabla btn-edit",
							children: "Editar"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 174,
							columnNumber: 37
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => eliminarUsuario(usuario.id_usuario),
							className: "btn-tabla btn-delete",
							children: "Eliminar"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 175,
							columnNumber: 37
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 173,
							columnNumber: 33
						}, this)
					] }, usuario.id_usuario, true, {
						fileName: _jsxFileName,
						lineNumber: 162,
						columnNumber: 29
					}, this)) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 160,
						columnNumber: 21
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 148,
					columnNumber: 17
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 147,
				columnNumber: 13
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 94,
		columnNumber: 9
	}, this);
};
_s(Usuarios, "irYnsuV6mR3QyYCXZEwU4YFxI/U=");
_c = Usuarios;
export default Usuarios;
var _c;
$RefreshReg$(_c, "Usuarios");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/usuarios.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/usuarios.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/usuarios.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/usuarios.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQWlCO0FBQzNDLE9BQU8sU0FBUztBQUNoQixPQUFPOzs7O0FBRVAsTUFBTSxpQkFBaUI7O0NBQ25CLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxFQUFFLENBQUM7Q0FDNUMsTUFBTSxDQUFDLFFBQVEsYUFBYSxTQUFTLEdBQUc7Q0FDeEMsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEdBQUc7Q0FDdEMsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLEdBQUc7Q0FDNUMsTUFBTSxDQUFDLEtBQUssVUFBVSxTQUFTLFVBQVU7Q0FDekMsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLEdBQUc7Q0FDNUMsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsR0FBRztDQUM5QyxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxLQUFLO0FBRWxELGlCQUFnQjtBQUNaLGtCQUFnQjtJQUNqQixFQUFFLENBQUM7Q0FFTixNQUFNLGlCQUFpQixZQUFZO0FBQy9CLE1BQUk7R0FDQSxNQUFNLE1BQU0sTUFBTSxJQUFJLElBQUksWUFBWTtBQUN0QyxlQUFZLElBQUksS0FBSztXQUNoQixLQUFLO0FBQ1YsV0FBUSxNQUFNLDZCQUE2QixJQUFJOzs7Q0FJdkQsTUFBTSxlQUFlLE9BQU8sTUFBTTtBQUM5QixJQUFFLGdCQUFnQjtBQUNsQixNQUFJLENBQUMsT0FBTyxNQUFNLENBQUUsUUFBTyxNQUFNLDJCQUEyQjtBQUM1RCxNQUFJLENBQUMsTUFBTSxNQUFNLENBQUUsUUFBTyxNQUFNLDBCQUEwQjs7QUFHMUQsTUFBSSxDQUFDLGNBQWMsQ0FBQyxTQUFTLE1BQU0sRUFBRTtBQUNqQyxVQUFPLE1BQU0sb0RBQW9EOztFQUdyRSxNQUFNLGVBQWU7R0FDakI7R0FDQTtHQUNBLEdBQUksWUFBWSxFQUFFLFVBQVU7R0FDNUI7R0FDQTtHQUNBO0dBQ0g7QUFFRCxNQUFJO0FBQ0EsT0FBSSxZQUFZO0FBQ1osVUFBTSxJQUFJLElBQUksYUFBYSxjQUFjLGFBQWE7QUFDdEQsa0JBQWMsS0FBSztBQUNuQixVQUFNLHFDQUFxQztVQUN4QztBQUNILFVBQU0sSUFBSSxLQUFLLGFBQWEsYUFBYTtBQUN6QyxVQUFNLG9DQUFvQzs7O0FBSTlDLGFBQVUsR0FBRztBQUNiLFlBQVMsR0FBRztBQUNaLGVBQVksR0FBRztBQUNmLFVBQU8sVUFBVTtBQUNqQixlQUFZLEdBQUc7QUFDZixnQkFBYSxHQUFHO0FBQ2hCLG1CQUFnQjtXQUNYLEtBQUs7QUFDVixXQUFRLE1BQU0sMEJBQTBCLElBQUk7QUFDNUMsU0FBTSxrREFBa0Q7OztDQUloRSxNQUFNLGtCQUFrQixZQUFZO0FBQ2hDLGdCQUFjLFFBQVEsV0FBVztBQUNqQyxZQUFVLFFBQVEsT0FBTztBQUN6QixXQUFTLFFBQVEsTUFBTTtBQUN2QixjQUFZLEdBQUc7QUFDZixTQUFPLFFBQVEsT0FBTyxVQUFVO0FBQ2hDLGNBQVksUUFBUSxZQUFZLEdBQUc7QUFDbkMsZUFBYSxRQUFRLGFBQWEsR0FBRzs7Q0FHekMsTUFBTSxrQkFBa0IsT0FBTyxPQUFPO0FBQ2xDLE1BQUksT0FBTyxRQUFRLDZEQUE2RCxFQUFFO0FBQzlFLE9BQUk7QUFDQSxVQUFNLElBQUksT0FBTyxhQUFhLEtBQUs7QUFDbkMsb0JBQWdCO1lBQ1gsS0FBSztBQUNWLFlBQVEsTUFBTSxzQkFBc0IsSUFBSTtBQUN4QyxVQUFNLGlDQUFpQzs7OztBQUtuRCxRQUNJLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FDSSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0ksd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBYTtLQUFZOzs7O2NBQ3hDLHdCQUFDLE9BQUQsWUFBSyx3QkFBQyxRQUFELFlBQU0seUNBQTRDOzs7O2NBQU07Ozs7YUFDM0Q7Ozs7OztHQUVOLHdCQUFDLE1BQUQ7SUFBSSxXQUFVO2NBQWlCO0lBQXNDOzs7OztHQUVyRSx3QkFBQyxRQUFEO0lBQU0sVUFBVTtJQUFjLFdBQVU7Y0FBeEM7S0FDSSx3QkFBQyxTQUFEO01BQU8sTUFBSztNQUFPLGFBQVk7TUFBUyxPQUFPO01BQVEsV0FBVSxNQUFLLFVBQVUsRUFBRSxPQUFPLE1BQU07TUFBRTtNQUFXOzs7OztLQUM1Ryx3QkFBQyxTQUFEO01BQU8sTUFBSztNQUFRLGFBQVk7TUFBUSxPQUFPO01BQU8sV0FBVSxNQUFLLFNBQVMsRUFBRSxPQUFPLE1BQU07TUFBRTtNQUFXOzs7OztLQUcxRyx3QkFBQyxTQUFEO01BQ0ksTUFBSztNQUNMLGFBQWEsYUFBYSxnQ0FBZ0M7TUFDMUQsT0FBTztNQUNQLFdBQVUsTUFBSyxZQUFZLEVBQUUsT0FBTyxNQUFNO01BQzFDLEdBQUssQ0FBQyxjQUFjLEVBQUUsVUFBVSxNQUFNO01BQ3hDOzs7OztLQUdGLHdCQUFDLFVBQUQ7TUFBUSxPQUFPO01BQUssV0FBVSxNQUFLLE9BQU8sRUFBRSxPQUFPLE1BQU07TUFBRTtNQUFTLFdBQVU7Z0JBQTlFLENBQ0ksd0JBQUMsVUFBRDtPQUFRLE9BQU07aUJBQVU7T0FBZ0I7Ozs7Z0JBQ3hDLHdCQUFDLFVBQUQ7T0FBUSxPQUFNO2lCQUFRO09BQXNCOzs7O2VBQ3ZDOzs7Ozs7S0FFVCx3QkFBQyxTQUFEO01BQU8sTUFBSztNQUFPLGFBQVk7TUFBVyxPQUFPO01BQVUsV0FBVSxNQUFLLFlBQVksRUFBRSxPQUFPLE1BQU07TUFBSTs7Ozs7S0FDekcsd0JBQUMsU0FBRDtNQUFPLE1BQUs7TUFBTyxhQUFZO01BQVksT0FBTztNQUFXLFdBQVUsTUFBSyxhQUFhLEVBQUUsT0FBTyxNQUFNO01BQUk7Ozs7O0tBRTVHLHdCQUFDLFVBQUQ7TUFBUSxNQUFLO01BQVMsV0FBVyxjQUFjLGFBQWEsZUFBZTtnQkFDdEUsYUFBYSxvQkFBb0I7TUFDN0I7Ozs7O0tBRVIsY0FDRyx3QkFBQyxVQUFEO01BQ0ksTUFBSztNQUNMLGVBQWU7QUFDWCxxQkFBYyxLQUFLO0FBQ25CLGlCQUFVLEdBQUc7QUFDYixnQkFBUyxHQUFHO0FBQ1osbUJBQVksR0FBRztBQUNmLGNBQU8sVUFBVTtBQUNqQixtQkFBWSxHQUFHO0FBQ2Ysb0JBQWEsR0FBRzs7TUFFcEIsV0FBVTtnQkFDYjtNQUVROzs7OztLQUVWOzs7Ozs7R0FFUCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNYLHdCQUFDLFNBQUQ7S0FBTyxXQUFVO2VBQWpCLENBQ0ksd0JBQUMsU0FBRCxZQUNJLHdCQUFDLE1BQUQ7TUFDSSx3QkFBQyxNQUFELFlBQUksTUFBTzs7Ozs7TUFDWCx3QkFBQyxNQUFELFlBQUksVUFBVzs7Ozs7TUFDZix3QkFBQyxNQUFELFlBQUksU0FBVTs7Ozs7TUFDZCx3QkFBQyxNQUFELFlBQUksT0FBUTs7Ozs7TUFDWix3QkFBQyxNQUFELFlBQUksWUFBYTs7Ozs7TUFDakIsd0JBQUMsTUFBRCxZQUFJLGFBQWM7Ozs7O01BQ2xCLHdCQUFDLE1BQUQsWUFBSSxZQUFhOzs7OztNQUNoQjs7OztlQUNEOzs7O2VBQ1Isd0JBQUMsU0FBRCxZQUNLLFNBQVMsS0FBSSxZQUNWLHdCQUFDLE1BQUQ7TUFDSSx3QkFBQyxNQUFELGFBQUksS0FBRSxRQUFRLFdBQWdCOzs7OztNQUM5Qix3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBUSxRQUFRO09BQVk7Ozs7O01BQzFDLHdCQUFDLE1BQUQsWUFBSyxRQUFRLE9BQVc7Ozs7O01BQ3hCLHdCQUFDLE1BQUQsWUFDSSx3QkFBQyxRQUFEO09BQU0sV0FBVyxhQUFhLFFBQVEsUUFBUSxVQUFVLGdCQUFnQjtpQkFDbkUsUUFBUSxJQUFJLGFBQWE7T0FDdkI7Ozs7Z0JBQ047Ozs7O01BQ0wsd0JBQUMsTUFBRCxZQUFLLFFBQVEsWUFBWSxPQUFXOzs7OztNQUNwQyx3QkFBQyxNQUFELFlBQUssUUFBUSxhQUFhLE9BQVc7Ozs7O01BQ3JDLHdCQUFDLE1BQUQsYUFDSSx3QkFBQyxVQUFEO09BQVEsZUFBZSxlQUFlLFFBQVE7T0FBRSxXQUFVO2lCQUFxQjtPQUFlOzs7O2dCQUM5Rix3QkFBQyxVQUFEO09BQVEsZUFBZSxnQkFBZ0IsUUFBUSxXQUFXO09BQUUsV0FBVTtpQkFBdUI7T0FBaUI7Ozs7ZUFDN0c7Ozs7O01BQ0osSUFmSSxRQUFROzs7O2FBZVosQ0FDUCxFQUNFOzs7O2NBQ0o7Ozs7OztJQUNOOzs7OztHQUNKOzs7Ozs7Ozs7QUFJZCxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbInVzdWFyaW9zLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IGFwaSBmcm9tICcuL2FwaSc7IC8vIFR1IGluc3RhbmNpYSBjb25maWd1cmFkYSBkZSBheGlvc1xyXG5pbXBvcnQgJy4vdXN1YXJpb3MuY3NzJzsgLy8gUHVlZGVzIG1hbnRlbmVyIG8gcmVub21icmFyIHR1IGFyY2hpdm8gQ1NTXHJcblxyXG5jb25zdCBVc3VhcmlvcyA9ICgpID0+IHtcclxuICAgIGNvbnN0IFt1c3Vhcmlvcywgc2V0VXN1YXJpb3NdID0gdXNlU3RhdGUoW10pO1xyXG4gICAgY29uc3QgW25vbWJyZSwgc2V0Tm9tYnJlXSA9IHVzZVN0YXRlKCcnKTtcclxuICAgIGNvbnN0IFtlbWFpbCwgc2V0RW1haWxdID0gdXNlU3RhdGUoJycpO1xyXG4gICAgY29uc3QgW3Bhc3N3b3JkLCBzZXRQYXNzd29yZF0gPSB1c2VTdGF0ZSgnJyk7IC8vIE5lY2VzYXJpbyBwYXJhIGNyZWFyIG51ZXZvcyB1c3Vhcmlvc1xyXG4gICAgY29uc3QgW3JvbCwgc2V0Um9sXSA9IHVzZVN0YXRlKCdjbGllbnRlJyk7IC8vIFBvciBkZWZlY3RvIHNlIGNyZWEgY29tbyBjbGllbnRlXHJcbiAgICBjb25zdCBbdGVsZWZvbm8sIHNldFRlbGVmb25vXSA9IHVzZVN0YXRlKCcnKTtcclxuICAgIGNvbnN0IFtkaXJlY2Npb24sIHNldERpcmVjY2lvbl0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgICBjb25zdCBbZWRpdGFuZG9JZCwgc2V0RWRpdGFuZG9JZF0gPSB1c2VTdGF0ZShudWxsKTtcclxuXHJcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgICAgIGNhcmdhclVzdWFyaW9zKCk7XHJcbiAgICB9LCBbXSk7XHJcblxyXG4gICAgY29uc3QgY2FyZ2FyVXN1YXJpb3MgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldCgnL3VzdWFyaW9zJyk7XHJcbiAgICAgICAgICAgIHNldFVzdWFyaW9zKHJlcy5kYXRhKTtcclxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGFsIGNhcmdhciB1c3VhcmlvczpcIiwgZXJyKTtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgIGlmICghbm9tYnJlLnRyaW0oKSkgcmV0dXJuIGFsZXJ0KFwiRWwgbm9tYnJlIGVzIG9ibGlnYXRvcmlvXCIpO1xyXG4gICAgICAgIGlmICghZW1haWwudHJpbSgpKSByZXR1cm4gYWxlcnQoXCJFbCBlbWFpbCBlcyBvYmxpZ2F0b3Jpb1wiKTtcclxuICAgICAgICBcclxuICAgICAgICAvLyBTaSBlc3RhbW9zIGNyZWFuZG8gdW5vIG51ZXZvLCBleGlnaW1vcyBjb250cmFzZcOxYVxyXG4gICAgICAgIGlmICghZWRpdGFuZG9JZCAmJiAhcGFzc3dvcmQudHJpbSgpKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBhbGVydChcIkxhIGNvbnRyYXNlw7FhIGVzIG9ibGlnYXRvcmlhIHBhcmEgbnVldm9zIHVzdWFyaW9zXCIpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgZGF0b3NVc3VhcmlvID0geyBcclxuICAgICAgICAgICAgbm9tYnJlLCBcclxuICAgICAgICAgICAgZW1haWwsIFxyXG4gICAgICAgICAgICAuLi4ocGFzc3dvcmQgJiYgeyBwYXNzd29yZCB9KSwgLy8gU29sbyBlbnbDrWEgcGFzc3dvcmQgc2kgc2UgZXNjcmliacOzIGFsZ29cclxuICAgICAgICAgICAgcm9sLCBcclxuICAgICAgICAgICAgdGVsZWZvbm8sIFxyXG4gICAgICAgICAgICBkaXJlY2Npb24gXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgaWYgKGVkaXRhbmRvSWQpIHtcclxuICAgICAgICAgICAgICAgIGF3YWl0IGFwaS5wdXQoYC91c3Vhcmlvcy8ke2VkaXRhbmRvSWR9YCwgZGF0b3NVc3VhcmlvKTtcclxuICAgICAgICAgICAgICAgIHNldEVkaXRhbmRvSWQobnVsbCk7XHJcbiAgICAgICAgICAgICAgICBhbGVydChcIlVzdWFyaW8gYWN0dWFsaXphZG8gZXhpdG9zYW1lbnRlIOKcqFwiKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGF3YWl0IGFwaS5wb3N0KCcvdXN1YXJpb3MnLCBkYXRvc1VzdWFyaW8pO1xyXG4gICAgICAgICAgICAgICAgYWxlcnQoXCJVc3VhcmlvIHJlZ2lzdHJhZG8gZXhpdG9zYW1lbnRlIOKchVwiKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgLy8gTGltcGlhciBmb3JtdWxhcmlvIGNvbXBsZXRvXHJcbiAgICAgICAgICAgIHNldE5vbWJyZSgnJyk7IFxyXG4gICAgICAgICAgICBzZXRFbWFpbCgnJyk7IFxyXG4gICAgICAgICAgICBzZXRQYXNzd29yZCgnJyk7XHJcbiAgICAgICAgICAgIHNldFJvbCgnY2xpZW50ZScpO1xyXG4gICAgICAgICAgICBzZXRUZWxlZm9ubygnJyk7IFxyXG4gICAgICAgICAgICBzZXREaXJlY2Npb24oJycpO1xyXG4gICAgICAgICAgICBjYXJnYXJVc3VhcmlvcygpO1xyXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZW4gbGEgb3BlcmFjacOzbjpcIiwgZXJyKTtcclxuICAgICAgICAgICAgYWxlcnQoXCJFcnJvcjogcmV2aXNhIGxvcyBkYXRvcyBvIHNpIGVsIGVtYWlsIHlhIGV4aXN0ZVwiKTtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGluaWNpYXJFZGljaW9uID0gKHVzdWFyaW8pID0+IHtcclxuICAgICAgICBzZXRFZGl0YW5kb0lkKHVzdWFyaW8uaWRfdXN1YXJpbyk7XHJcbiAgICAgICAgc2V0Tm9tYnJlKHVzdWFyaW8ubm9tYnJlKTtcclxuICAgICAgICBzZXRFbWFpbCh1c3VhcmlvLmVtYWlsKTtcclxuICAgICAgICBzZXRQYXNzd29yZCgnJyk7IC8vIERlamFtb3MgbGEgY29udHJhc2XDsWEgdmFjw61hIHBvciBzZWd1cmlkYWQgYWwgZWRpdGFyXHJcbiAgICAgICAgc2V0Um9sKHVzdWFyaW8ucm9sIHx8ICdjbGllbnRlJyk7XHJcbiAgICAgICAgc2V0VGVsZWZvbm8odXN1YXJpby50ZWxlZm9ubyB8fCAnJyk7XHJcbiAgICAgICAgc2V0RGlyZWNjaW9uKHVzdWFyaW8uZGlyZWNjaW9uIHx8ICcnKTtcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgZWxpbWluYXJVc3VhcmlvID0gYXN5bmMgKGlkKSA9PiB7XHJcbiAgICAgICAgaWYgKHdpbmRvdy5jb25maXJtKFwiwr9NYW5vLCBzZWd1cm8gcXVlIHF1aWVyZXMgYm9ycmFyIGVzdGUgdXN1YXJpbyBkZWwgc2lzdGVtYT9cIikpIHtcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIGF3YWl0IGFwaS5kZWxldGUoYC91c3Vhcmlvcy8ke2lkfWApO1xyXG4gICAgICAgICAgICAgICAgY2FyZ2FyVXN1YXJpb3MoKTtcclxuICAgICAgICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgYWwgZWxpbWluYXI6XCIsIGVycik7XHJcbiAgICAgICAgICAgICAgICBhbGVydChcIk5vIHNlIHB1ZG8gZWxpbWluYXIgZWwgdXN1YXJpb1wiKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNsaWVudGVzLXBhZ2VcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjbGllbnRlcy1oZWFkZXJcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibG9nby1sZXZpc1wiPkxFVkknUzwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdj48c3Bhbj5HRVNUScOTTiBERSBVU1VBUklPUyBZIEFETUlOSVNUUkFET1JFUzwvc3Bhbj48L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwic2VjY2lvbi10aXR1bG9cIj5BZG1pbmlzdHJhY2nDs24gR2VuZXJhbCBkZSBDdWVudGFzPC9oMj5cclxuXHJcbiAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IGNsYXNzTmFtZT1cImNsaWVudGVzLWZvcm1cIj5cclxuICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIHBsYWNlaG9sZGVyPVwiTk9NQlJFXCIgdmFsdWU9e25vbWJyZX0gb25DaGFuZ2U9e2UgPT4gc2V0Tm9tYnJlKGUudGFyZ2V0LnZhbHVlKX0gcmVxdWlyZWQgLz5cclxuICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiZW1haWxcIiBwbGFjZWhvbGRlcj1cIkVNQUlMXCIgdmFsdWU9e2VtYWlsfSBvbkNoYW5nZT17ZSA9PiBzZXRFbWFpbChlLnRhcmdldC52YWx1ZSl9IHJlcXVpcmVkIC8+XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIHsvKiBDYW1wbyBkZSBjb250cmFzZcOxYSAob3BjaW9uYWwgYWwgZWRpdGFyLCByZXF1ZXJpZG8gYWwgY3JlYXIpICovfVxyXG4gICAgICAgICAgICAgICAgPGlucHV0IFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJwYXNzd29yZFwiIFxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPXtlZGl0YW5kb0lkID8gXCJOVUVWQSBDT05UUkFTRcORQSAoT3BjaW9uYWwpXCIgOiBcIkNPTlRSQVNFw5FBXCJ9IFxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwYXNzd29yZH0gXHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0UGFzc3dvcmQoZS50YXJnZXQudmFsdWUpfSBcclxuICAgICAgICAgICAgICAgICAgICB7Li4uKCFlZGl0YW5kb0lkICYmIHsgcmVxdWlyZWQ6IHRydWUgfSl9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBTZWxlY3RvciBjbGF2ZSBwYXJhIGNhbWJpYXIgZGUgcm9sIGVudHJlIGNsaWVudGUgeSBhZG1pbiAqL31cclxuICAgICAgICAgICAgICAgIDxzZWxlY3QgdmFsdWU9e3JvbH0gb25DaGFuZ2U9e2UgPT4gc2V0Um9sKGUudGFyZ2V0LnZhbHVlKX0gcmVxdWlyZWQgY2xhc3NOYW1lPVwic2VsZWN0LXJvbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJjbGllbnRlXCI+Q2xpZW50ZTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJhZG1pblwiPkFkbWluaXN0cmFkb3I8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG5cclxuICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIHBsYWNlaG9sZGVyPVwiVEVMw4lGT05PXCIgdmFsdWU9e3RlbGVmb25vfSBvbkNoYW5nZT17ZSA9PiBzZXRUZWxlZm9ubyhlLnRhcmdldC52YWx1ZSl9IC8+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBwbGFjZWhvbGRlcj1cIkRJUkVDQ0nDk05cIiB2YWx1ZT17ZGlyZWNjaW9ufSBvbkNoYW5nZT17ZSA9PiBzZXREaXJlY2Npb24oZS50YXJnZXQudmFsdWUpfSAvPlxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBjbGFzc05hbWU9e2BidG4tc3VibWl0ICR7ZWRpdGFuZG9JZCA/ICdidG4tZWRpdGFyJyA6ICdidG4tYWdyZWdhcid9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAge2VkaXRhbmRvSWQgPyAnR1VBUkRBUiBDQU1CSU9TJyA6ICcrIEFHUkVHQVIgVVNVQVJJTyd9XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAge2VkaXRhbmRvSWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIiBcclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4geyBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEVkaXRhbmRvSWQobnVsbCk7IFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0Tm9tYnJlKCcnKTsgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRFbWFpbCgnJyk7IFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0UGFzc3dvcmQoJycpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0Um9sKCdjbGllbnRlJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRUZWxlZm9ubygnJyk7IFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0RGlyZWNjaW9uKCcnKTsgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH19IFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJidG4tY2FuY2VsYXJcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQ2FuY2VsYXJcclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZm9ybT5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGFibGEtY29udGFpbmVyXCI+XHJcbiAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidGFibGEtY2xpZW50ZXNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8dGhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aD5JRDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGg+Tk9NQlJFPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aD5FTUFJTDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGg+Uk9MPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aD5URUzDiUZPTk88L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoPkRJUkVDQ0nDk048L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoPkFDQ0lPTkVTPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0Ym9keT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3VzdWFyaW9zLm1hcCh1c3VhcmlvID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e3VzdWFyaW8uaWRfdXN1YXJpb30+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkPiN7dXN1YXJpby5pZF91c3VhcmlvfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cImJvbGRcIj57dXN1YXJpby5ub21icmV9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQ+e3VzdWFyaW8uZW1haWx9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YGJhZGdlLXJvbCAke3VzdWFyaW8ucm9sID09PSAnYWRtaW4nID8gJ2JhZGdlLWFkbWluJyA6ICdiYWRnZS1jbGllbnRlJ31gfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt1c3VhcmlvLnJvbC50b1VwcGVyQ2FzZSgpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQ+e3VzdWFyaW8udGVsZWZvbm8gfHwgJ04vQSd9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQ+e3VzdWFyaW8uZGlyZWNjaW9uIHx8ICdOL0EnfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IGluaWNpYXJFZGljaW9uKHVzdWFyaW8pfSBjbGFzc05hbWU9XCJidG4tdGFibGEgYnRuLWVkaXRcIj5FZGl0YXI8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBlbGltaW5hclVzdWFyaW8odXN1YXJpby5pZF91c3VhcmlvKX0gY2xhc3NOYW1lPVwiYnRuLXRhYmxhIGJ0bi1kZWxldGVcIj5FbGltaW5hcjwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgICAgICAgICAgPC90YWJsZT5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgVXN1YXJpb3M7Il19