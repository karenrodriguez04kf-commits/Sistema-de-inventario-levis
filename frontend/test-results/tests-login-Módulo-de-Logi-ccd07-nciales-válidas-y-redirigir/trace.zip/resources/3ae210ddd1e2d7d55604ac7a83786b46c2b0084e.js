import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/MisPedidos.jsx");import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=66677652"; const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];
import api, { BASE_URL } from "/src/api.js";
import { jwtDecode } from "/node_modules/.vite/deps/jwt-decode.js?v=66677652";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=66677652";
import { FaShoppingBag, FaCalendarAlt, FaArrowLeft, FaReceipt, FaBoxOpen } from "/node_modules/.vite/deps/react-icons_fa.js?v=66677652";
import "/src/MisPedidos.css";
var _jsxFileName = "C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/MisPedidos.jsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=66677652"; const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
const MisPedidos = () => {
	_s();
	const [pedidosAgrupados, setPedidosAgrupados] = useState({});
	const [loading, setLoading] = useState(true);
	const navigate = useNavigate();
	useEffect(() => {
		const fetchPedidos = async () => {
			const token = localStorage.getItem("token");
			if (!token) {
				navigate("/login");
				return;
			}
			try {
				const decoded = jwtDecode(token);
				const id_usuario = decoded.id_usuario || decoded.id;
				const response = await api.get(`/productos/mis-pedidos/${id_usuario}`);
				const agrupados = response.data.reduce((acc, item) => {
					if (!acc[item.id_venta]) {
						acc[item.id_venta] = {
							id: item.id_venta,
							fecha: item.fecha,
							totalPedido: item.total,
							productos: []
						};
					}
					acc[item.id_venta].productos.push(item);
					return acc;
				}, {});
				setPedidosAgrupados(agrupados);
			} catch (error) {
				console.error("Error al cargar pedidos:", error);
			} finally {
				setLoading(false);
			}
		};
		fetchPedidos();
	}, [navigate]);
	if (loading) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "catalogo-page neon-loader-container",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "neon-loader-text",
				children: "CONSULTANDO HISTORIAL..."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 53,
				columnNumber: 17
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 52,
			columnNumber: 13
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "catalogo-page pedidos-page-wrapper",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "history-header-neon",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "header-title-box",
				children: [/* @__PURE__ */ _jsxDEV("h2", { children: ["Mis Compras Realizadas ", /* @__PURE__ */ _jsxDEV(FaShoppingBag, { className: "icon-pulse" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 62,
					columnNumber: 48
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 62,
					columnNumber: 21
				}, this), /* @__PURE__ */ _jsxDEV("p", { children: "Historial interactivo y seguimiento de tus pedidos en tiempo real." }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 63,
					columnNumber: 21
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 61,
				columnNumber: 17
			}, this), /* @__PURE__ */ _jsxDEV("button", {
				onClick: () => navigate("/home/catalogo"),
				className: "btn-return-neon",
				children: [/* @__PURE__ */ _jsxDEV(FaArrowLeft, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 66,
					columnNumber: 21
				}, this), " Volver a la Tienda"]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 65,
				columnNumber: 17
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 60,
			columnNumber: 13
		}, this), Object.keys(pedidosAgrupados).length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
			className: "empty-history-neon",
			children: [
				/* @__PURE__ */ _jsxDEV(FaReceipt, {
					size: 50,
					className: "empty-icon-glow"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 72,
					columnNumber: 21
				}, this),
				/* @__PURE__ */ _jsxDEV("p", { children: "No tienes pedidos registrados aún." }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 73,
					columnNumber: 21
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					onClick: () => navigate("/home/catalogo"),
					className: "btn-explore-neon",
					children: "Explorar Catálogo"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 74,
					columnNumber: 21
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 71,
			columnNumber: 17
		}, this) : /* @__PURE__ */ _jsxDEV("div", {
			className: "pedidos-grid-neon",
			children: Object.values(pedidosAgrupados).sort((a, b) => b.id - a.id).map((pedido) => /* @__PURE__ */ _jsxDEV("div", {
				className: "pedido-card-neon",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "card-neon-top",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "order-tag",
							children: ["PEDIDO #", pedido.id]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 83,
							columnNumber: 33
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "order-date-tag",
							children: [
								/* @__PURE__ */ _jsxDEV(FaCalendarAlt, {}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 85,
									columnNumber: 37
								}, this),
								" ",
								new Date(pedido.fecha).toLocaleDateString()
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 84,
							columnNumber: 33
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 82,
						columnNumber: 29
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "card-neon-body",
						children: pedido.productos.map((prod, idx) => /* @__PURE__ */ _jsxDEV("div", {
							className: "product-row-neon",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "img-container-neon",
									children: /* @__PURE__ */ _jsxDEV("img", {
										src: prod.imagen ? `${BASE_URL}${prod.imagen}` : "/img/default.jpg",
										alt: prod.nombreProducto,
										onError: (e) => {
											e.target.src = "/img/default.jpg";
										}
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 93,
										columnNumber: 45
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 92,
									columnNumber: 41
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "product-info-neon",
									children: [/* @__PURE__ */ _jsxDEV("h4", { children: prod.nombreProducto }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 100,
										columnNumber: 45
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "prod-qty-price",
										children: [
											"Cant: ",
											prod.cantidad,
											" × $",
											Number(prod.precioUnitario).toLocaleString()
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 101,
										columnNumber: 45
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 99,
									columnNumber: 41
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "product-subtotal-neon",
									children: ["$", Number(prod.cantidad * prod.precioUnitario).toLocaleString()]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 103,
									columnNumber: 41
								}, this)
							]
						}, idx, true, {
							fileName: _jsxFileName,
							lineNumber: 91,
							columnNumber: 37
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 89,
						columnNumber: 29
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "card-neon-footer",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "status-neon-pill",
							children: [/* @__PURE__ */ _jsxDEV("span", { className: "dot-pulse" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 112,
								columnNumber: 37
							}, this), " ESTADO: ENTREGADO"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 111,
							columnNumber: 33
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "total-neon-box",
							children: ["TOTAL: ", /* @__PURE__ */ _jsxDEV("span", { children: [
								"$",
								Number(pedido.totalPedido).toLocaleString(),
								" COP"
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 115,
								columnNumber: 44
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 114,
							columnNumber: 33
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 110,
						columnNumber: 29
					}, this)
				]
			}, pedido.id, true, {
				fileName: _jsxFileName,
				lineNumber: 81,
				columnNumber: 25
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 79,
			columnNumber: 17
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 59,
		columnNumber: 9
	}, this);
};
_s(MisPedidos, "JOVmrbBRmTPlfOIDxvzB8YQTn1A=", false, function() {
	return [useNavigate];
});
_c = MisPedidos;
export default MisPedidos;
var _c;
$RefreshReg$(_c, "MisPedidos");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/MisPedidos.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/MisPedidos.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/MisPedidos.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/MisPedidos.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQWlCO0FBQzNDLE9BQU8sT0FBTyxnQkFBZ0I7QUFDOUIsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxlQUFlLGVBQWUsYUFBYSxXQUFXLGlCQUFpQjtBQUNoRixPQUFPOzs7O0FBRVAsTUFBTSxtQkFBbUI7O0NBQ3JCLE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLFNBQVMsRUFBRSxDQUFDO0NBQzVELE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxLQUFLO0NBQzVDLE1BQU0sV0FBVyxhQUFhO0FBRTlCLGlCQUFnQjtFQUNaLE1BQU0sZUFBZSxZQUFZO0dBQzdCLE1BQU0sUUFBUSxhQUFhLFFBQVEsUUFBUTtBQUMzQyxPQUFJLENBQUMsT0FBTztBQUNSLGFBQVMsU0FBUztBQUNsQjs7QUFHSixPQUFJO0lBQ0EsTUFBTSxVQUFVLFVBQVUsTUFBTTtJQUNoQyxNQUFNLGFBQWEsUUFBUSxjQUFjLFFBQVE7SUFDakQsTUFBTSxXQUFXLE1BQU0sSUFBSSxJQUFJLDBCQUEwQixhQUFhO0lBRXRFLE1BQU0sWUFBWSxTQUFTLEtBQUssUUFBUSxLQUFLLFNBQVM7QUFDbEQsU0FBSSxDQUFDLElBQUksS0FBSyxXQUFXO0FBQ3JCLFVBQUksS0FBSyxZQUFZO09BQ2pCLElBQUksS0FBSztPQUNULE9BQU8sS0FBSztPQUNaLGFBQWEsS0FBSztPQUNsQixXQUFXLEVBQUU7T0FDaEI7O0FBRUwsU0FBSSxLQUFLLFVBQVUsVUFBVSxLQUFLLEtBQUs7QUFDdkMsWUFBTztPQUNSLEVBQUUsQ0FBQztBQUVOLHdCQUFvQixVQUFVO1lBQ3pCLE9BQU87QUFDWixZQUFRLE1BQU0sNEJBQTRCLE1BQU07YUFDMUM7QUFDTixlQUFXLE1BQU07OztBQUl6QixnQkFBYztJQUNmLENBQUMsU0FBUyxDQUFDO0FBRWQsS0FBSSxTQUFTO0FBQ1QsU0FDSSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUNYLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQW1CO0lBQThCOzs7OztHQUM5RDs7Ozs7O0FBSWQsUUFDSSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBQ0ksd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNJLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDSSx3QkFBQyxNQUFELGFBQUksMkJBQXVCLHdCQUFDLGVBQUQsRUFBZSxXQUFVLGNBQWU7Ozs7YUFBSzs7OztjQUN4RSx3QkFBQyxLQUFELFlBQUcsc0VBQXNFOzs7O2FBQ3ZFOzs7OzthQUNOLHdCQUFDLFVBQUQ7SUFBUSxlQUFlLFNBQVMsaUJBQWlCO0lBQUUsV0FBVTtjQUE3RCxDQUNJLHdCQUFDLGFBQUQsRUFBZTs7OztvQ0FDVjs7Ozs7WUFDUDs7Ozs7WUFFTCxPQUFPLEtBQUssaUJBQWlCLENBQUMsV0FBVyxJQUN0Qyx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBQ0ksd0JBQUMsV0FBRDtLQUFXLE1BQU07S0FBSSxXQUFVO0tBQW9COzs7OztJQUNuRCx3QkFBQyxLQUFELFlBQUcsc0NBQXNDOzs7OztJQUN6Qyx3QkFBQyxVQUFEO0tBQVEsZUFBZSxTQUFTLGlCQUFpQjtLQUFFLFdBQVU7ZUFBbUI7S0FFdkU7Ozs7O0lBQ1A7Ozs7O2FBRU4sd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFDVixPQUFPLE9BQU8saUJBQWlCLENBQUMsTUFBTSxHQUFHLE1BQU0sRUFBRSxLQUFLLEVBQUUsR0FBRyxDQUFDLEtBQUssV0FDOUQsd0JBQUMsT0FBRDtJQUFxQixXQUFVO2NBQS9CO0tBQ0ksd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDSSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBaEIsQ0FBNEIsWUFBUyxPQUFPLEdBQVU7Ozs7O2dCQUN0RCx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBaEI7UUFDSSx3QkFBQyxlQUFELEVBQWlCOzs7Ozs7UUFBRSxJQUFJLEtBQUssT0FBTyxNQUFNLENBQUMsb0JBQW9CO1FBQzNEOzs7OztlQUNMOzs7Ozs7S0FFTix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDVixPQUFPLFVBQVUsS0FBSyxNQUFNLFFBQ3pCLHdCQUFDLE9BQUQ7T0FBZSxXQUFVO2lCQUF6QjtRQUNJLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNYLHdCQUFDLE9BQUQ7VUFDSSxLQUFLLEtBQUssU0FBUyxHQUFHLFdBQVcsS0FBSyxXQUFXO1VBQ2pELEtBQUssS0FBSztVQUNWLFVBQVUsTUFBTTtBQUFFLGFBQUUsT0FBTyxNQUFNOztVQUNuQzs7Ozs7U0FDQTs7Ozs7UUFDTix3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNJLHdCQUFDLE1BQUQsWUFBSyxLQUFLLGdCQUFvQjs7OzttQkFDOUIsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCO1dBQWlDO1dBQU8sS0FBSztXQUFTO1dBQUssT0FBTyxLQUFLLGVBQWUsQ0FBQyxnQkFBZ0I7V0FBUTs7Ozs7a0JBQzdHOzs7Ozs7UUFDTix3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUF1QyxLQUNqQyxPQUFPLEtBQUssV0FBVyxLQUFLLGVBQWUsQ0FBQyxnQkFBZ0IsQ0FDNUQ7Ozs7OztRQUNKO1NBZkk7Ozs7Y0FlSixDQUNSO01BQ0E7Ozs7O0tBRU4sd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDSSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNJLHdCQUFDLFFBQUQsRUFBTSxXQUFVLGFBQW1COzs7O3NDQUNqQzs7Ozs7Z0JBQ04sd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FBZ0MsV0FDckIsd0JBQUMsUUFBRDtRQUFNO1FBQUUsT0FBTyxPQUFPLFlBQVksQ0FBQyxnQkFBZ0I7UUFBQztRQUFXOzs7O2dCQUNwRTs7Ozs7ZUFDSjs7Ozs7O0tBQ0o7TUFyQ0ksT0FBTzs7OztXQXFDWCxDQUNSO0dBQ0E7Ozs7V0FFUjs7Ozs7Ozs7Ozs7QUFJZCxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIk1pc1BlZGlkb3MuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgYXBpLCB7IEJBU0VfVVJMIH0gZnJvbSAnLi9hcGknOyBcclxuaW1wb3J0IHsgand0RGVjb2RlIH0gZnJvbSBcImp3dC1kZWNvZGVcIjtcclxuaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgeyBGYVNob3BwaW5nQmFnLCBGYUNhbGVuZGFyQWx0LCBGYUFycm93TGVmdCwgRmFSZWNlaXB0LCBGYUJveE9wZW4gfSBmcm9tIFwicmVhY3QtaWNvbnMvZmFcIjtcclxuaW1wb3J0ICcuL01pc1BlZGlkb3MuY3NzJztcclxuXHJcbmNvbnN0IE1pc1BlZGlkb3MgPSAoKSA9PiB7XHJcbiAgICBjb25zdCBbcGVkaWRvc0FncnVwYWRvcywgc2V0UGVkaWRvc0FncnVwYWRvc10gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcclxuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcclxuXHJcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGZldGNoUGVkaWRvcyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgICAgICAgY29uc3QgdG9rZW4gPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgndG9rZW4nKTtcclxuICAgICAgICAgICAgaWYgKCF0b2tlbikge1xyXG4gICAgICAgICAgICAgICAgbmF2aWdhdGUoXCIvbG9naW5cIik7XHJcbiAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBkZWNvZGVkID0gand0RGVjb2RlKHRva2VuKTtcclxuICAgICAgICAgICAgICAgIGNvbnN0IGlkX3VzdWFyaW8gPSBkZWNvZGVkLmlkX3VzdWFyaW8gfHwgZGVjb2RlZC5pZDtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL3Byb2R1Y3Rvcy9taXMtcGVkaWRvcy8ke2lkX3VzdWFyaW99YCk7XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIGNvbnN0IGFncnVwYWRvcyA9IHJlc3BvbnNlLmRhdGEucmVkdWNlKChhY2MsIGl0ZW0pID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoIWFjY1tpdGVtLmlkX3ZlbnRhXSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2NbaXRlbS5pZF92ZW50YV0gPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogaXRlbS5pZF92ZW50YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZlY2hhOiBpdGVtLmZlY2hhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdG90YWxQZWRpZG86IGl0ZW0udG90YWwsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcm9kdWN0b3M6IFtdXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGFjY1tpdGVtLmlkX3ZlbnRhXS5wcm9kdWN0b3MucHVzaChpdGVtKTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gYWNjO1xyXG4gICAgICAgICAgICAgICAgfSwge30pO1xyXG5cclxuICAgICAgICAgICAgICAgIHNldFBlZGlkb3NBZ3J1cGFkb3MoYWdydXBhZG9zKTtcclxuICAgICAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBhbCBjYXJnYXIgcGVkaWRvczpcIiwgZXJyb3IpO1xyXG4gICAgICAgICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICBmZXRjaFBlZGlkb3MoKTtcclxuICAgIH0sIFtuYXZpZ2F0ZV0pO1xyXG5cclxuICAgIGlmIChsb2FkaW5nKSB7XHJcbiAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXRhbG9nby1wYWdlIG5lb24tbG9hZGVyLWNvbnRhaW5lclwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJuZW9uLWxvYWRlci10ZXh0XCI+Q09OU1VMVEFORE8gSElTVE9SSUFMLi4uPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICk7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhdGFsb2dvLXBhZ2UgcGVkaWRvcy1wYWdlLXdyYXBwZXJcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoaXN0b3J5LWhlYWRlci1uZW9uXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhlYWRlci10aXRsZS1ib3hcIj5cclxuICAgICAgICAgICAgICAgICAgICA8aDI+TWlzIENvbXByYXMgUmVhbGl6YWRhcyA8RmFTaG9wcGluZ0JhZyBjbGFzc05hbWU9XCJpY29uLXB1bHNlXCIgLz48L2gyPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwPkhpc3RvcmlhbCBpbnRlcmFjdGl2byB5IHNlZ3VpbWllbnRvIGRlIHR1cyBwZWRpZG9zIGVuIHRpZW1wbyByZWFsLjwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZSgnL2hvbWUvY2F0YWxvZ28nKX0gY2xhc3NOYW1lPVwiYnRuLXJldHVybi1uZW9uXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPEZhQXJyb3dMZWZ0IC8+IFZvbHZlciBhIGxhIFRpZW5kYVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAge09iamVjdC5rZXlzKHBlZGlkb3NBZ3J1cGFkb3MpLmxlbmd0aCA9PT0gMCA/IChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZW1wdHktaGlzdG9yeS1uZW9uXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPEZhUmVjZWlwdCBzaXplPXs1MH0gY2xhc3NOYW1lPVwiZW1wdHktaWNvbi1nbG93XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8cD5ObyB0aWVuZXMgcGVkaWRvcyByZWdpc3RyYWRvcyBhw7puLjwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKCcvaG9tZS9jYXRhbG9nbycpfSBjbGFzc05hbWU9XCJidG4tZXhwbG9yZS1uZW9uXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEV4cGxvcmFyIENhdMOhbG9nb1xyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBlZGlkb3MtZ3JpZC1uZW9uXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge09iamVjdC52YWx1ZXMocGVkaWRvc0FncnVwYWRvcykuc29ydCgoYSwgYikgPT4gYi5pZCAtIGEuaWQpLm1hcCgocGVkaWRvKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtwZWRpZG8uaWR9IGNsYXNzTmFtZT1cInBlZGlkby1jYXJkLW5lb25cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZC1uZW9uLXRvcFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm9yZGVyLXRhZ1wiPlBFRElETyAje3BlZGlkby5pZH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwib3JkZXItZGF0ZS10YWdcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhQ2FsZW5kYXJBbHQgLz4ge25ldyBEYXRlKHBlZGlkby5mZWNoYSkudG9Mb2NhbGVEYXRlU3RyaW5nKCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkLW5lb24tYm9keVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwZWRpZG8ucHJvZHVjdG9zLm1hcCgocHJvZCwgaWR4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpZHh9IGNsYXNzTmFtZT1cInByb2R1Y3Qtcm93LW5lb25cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW1nLWNvbnRhaW5lci1uZW9uXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGltZyBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjPXtwcm9kLmltYWdlbiA/IGAke0JBU0VfVVJMfSR7cHJvZC5pbWFnZW59YCA6IFwiL2ltZy9kZWZhdWx0LmpwZ1wifSBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWx0PXtwcm9kLm5vbWJyZVByb2R1Y3RvfSBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25FcnJvcj17KGUpID0+IHsgZS50YXJnZXQuc3JjID0gXCIvaW1nL2RlZmF1bHQuanBnXCI7IH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9kdWN0LWluZm8tbmVvblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoND57cHJvZC5ub21icmVQcm9kdWN0b308L2g0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInByb2QtcXR5LXByaWNlXCI+Q2FudDoge3Byb2QuY2FudGlkYWR9IMOXICR7TnVtYmVyKHByb2QucHJlY2lvVW5pdGFyaW8pLnRvTG9jYWxlU3RyaW5nKCl9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2R1Y3Qtc3VidG90YWwtbmVvblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICR7TnVtYmVyKHByb2QuY2FudGlkYWQgKiBwcm9kLnByZWNpb1VuaXRhcmlvKS50b0xvY2FsZVN0cmluZygpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkLW5lb24tZm9vdGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdGF0dXMtbmVvbi1waWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImRvdC1wdWxzZVwiPjwvc3Bhbj4gRVNUQURPOiBFTlRSRUdBRE9cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRvdGFsLW5lb24tYm94XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRPVEFMOiA8c3Bhbj4ke051bWJlcihwZWRpZG8udG90YWxQZWRpZG8pLnRvTG9jYWxlU3RyaW5nKCl9IENPUDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IE1pc1BlZGlkb3M7Il19