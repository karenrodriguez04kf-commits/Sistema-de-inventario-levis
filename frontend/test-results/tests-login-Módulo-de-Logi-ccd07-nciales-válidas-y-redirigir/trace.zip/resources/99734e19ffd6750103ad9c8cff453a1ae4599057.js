import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/inventario.jsx");import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=66677652"; const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=66677652";
import api, { BASE_URL } from "/src/api.js";
import { FaBoxes, FaPlus, FaEdit, FaTrash, FaArrowLeft, FaUpload, FaTag } from "/node_modules/.vite/deps/react-icons_fa.js?v=66677652";
import "/src/inventario.css";
var _jsxFileName = "C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/inventario.jsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=66677652"; const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
const TALLAS_DEFAULT = [
	"S",
	"M",
	"L",
	"XL",
	"XXL"
];
function Inventario() {
	_s();
	const navigate = useNavigate();
	const [view, setView] = useState("listar");
	const [productos, setProductos] = useState([]);
	const [mostrarModal, setMostrarModal] = useState(false);
	const [editando, setEditando] = useState(false);
	const [idActual, setIdActual] = useState(null);
	const [proveedores, setProveedores] = useState([]);
	const [categorias, setCategorias] = useState([]);
	const [form, setForm] = useState({
		nombreProducto: "",
		precioProducto: "",
		color: "",
		genero: "",
		id_categoria: "",
		id_proveedor: "",
		imagen: null,
		tallas: TALLAS_DEFAULT.map((t) => ({
			talla: t,
			stock: 0
		}))
	});
	const cargarProductos = async () => {
		try {
			const res = await api.get("/productos");
			setProductos(res.data);
		} catch (err) {
			console.error("Error cargando inventario:", err);
		}
	};
	const cargarProveedores = async () => {
		try {
			const res = await api.get("/proveedores");
			setProveedores(res.data);
		} catch (err) {
			console.error("Error cargando proveedores:", err);
		}
	};
	const cargarCategorias = async () => {
		try {
			const res = await api.get("/productos/categorias");
			setCategorias(res.data);
		} catch (err) {
			console.error("Error cargando categorias:", err);
		}
	};
	useEffect(() => {
		cargarProductos();
		cargarProveedores();
		cargarCategorias();
	}, []);
	const stockTotal = (prod) => {
		if (!prod.tallas) return 0;
		const tallas = typeof prod.tallas === "string" ? JSON.parse(prod.tallas) : prod.tallas;
		return tallas.reduce((sum, t) => sum + (t.stock || 0), 0);
	};
	const eliminarProducto = async (id) => {
		if (window.confirm("¿Estás seguro de borrar este producto?")) {
			try {
				await api.delete(`/productos/${id}`);
				alert("Producto eliminado con éxito");
				cargarProductos();
			} catch (error) {
				alert("Error al eliminar");
			}
		}
	};
	const abrirModal = (prod = null) => {
		if (prod) {
			setEditando(true);
			setIdActual(prod.id_producto);
			const tallasExistentes = prod.tallas ? typeof prod.tallas === "string" ? JSON.parse(prod.tallas) : prod.tallas : TALLAS_DEFAULT.map((t) => ({
				talla: t,
				stock: 0
			}));
			setForm({
				nombreProducto: prod.nombreProducto || "",
				precioProducto: prod.precioProducto || "",
				color: prod.color || "",
				genero: prod.genero || "",
				id_categoria: prod.id_categoria || "",
				id_proveedor: prod.id_proveedor || "",
				imagen: null,
				tallas: tallasExistentes
			});
		} else {
			setEditando(false);
			setForm({
				nombreProducto: "",
				precioProducto: "",
				color: "",
				genero: "",
				id_categoria: "",
				id_proveedor: "",
				imagen: null,
				tallas: TALLAS_DEFAULT.map((t) => ({
					talla: t,
					stock: 0
				}))
			});
		}
		setMostrarModal(true);
	};
	const actualizarStockTalla = (index, valor) => {
		const nuevasTallas = [...form.tallas];
		nuevasTallas[index].stock = parseInt(valor) || 0;
		setForm({
			...form,
			tallas: nuevasTallas
		});
	};
	const guardarProducto = async () => {
		if (!form.nombreProducto.trim()) return alert("El nombre es obligatorio");
		if (!form.precioProducto) return alert("El precio es obligatorio");
		if (!form.genero) return alert("El género es obligatorio");
		const data = new FormData();
		data.append("nombreProducto", form.nombreProducto);
		data.append("precioProducto", form.precioProducto);
		data.append("color", form.color);
		data.append("genero", form.genero);
		data.append("id_categoria", form.id_categoria);
		data.append("id_proveedor", form.id_proveedor || "");
		data.append("tallas", JSON.stringify(form.tallas));
		if (form.imagen) data.append("imagen", form.imagen);
		const endpoint = editando ? `/productos/${idActual}` : "/productos";
		const metodo = editando ? "put" : "post";
		try {
			const response = await api[metodo](endpoint, data);
			if (response.status === 200 || response.status === 201) {
				alert(editando ? "¡Producto actualizado!" : "¡Producto guardado!");
				setMostrarModal(false);
				cargarProductos();
			}
		} catch (error) {
			const mensaje = error.response?.data?.error || "Error en la operación";
			alert(mensaje);
		}
	};
	const URL_IMAGENES = BASE_URL || "http://localhost:3002";
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "admin-main-wrapper pedidos-page-wrapper",
		children: [view === "listar" && /* @__PURE__ */ _jsxDEV("div", {
			className: "inventory-list-view",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "history-header-neon",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "header-title-box",
					children: [/* @__PURE__ */ _jsxDEV("h2", { children: ["GESTIÓN DE INVENTARIO ", /* @__PURE__ */ _jsxDEV(FaBoxes, { className: "icon-pulse" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 161,
						columnNumber: 41
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 161,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("p", { children: "Control de existencias, tallas y referencias en tiempo real." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 162,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 160,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					style: {
						display: "flex",
						gap: "12px"
					},
					children: [/* @__PURE__ */ _jsxDEV("button", {
						className: "btn-return-neon",
						onClick: () => navigate("/home/catalogo"),
						children: [/* @__PURE__ */ _jsxDEV(FaArrowLeft, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 166,
							columnNumber: 17
						}, this), " PANEL"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 165,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						className: "btn-explore-neon",
						onClick: () => abrirModal(),
						children: [/* @__PURE__ */ _jsxDEV(FaPlus, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 169,
							columnNumber: 17
						}, this), " NUEVO ITEM"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 168,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 164,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 159,
				columnNumber: 11
			}, this), productos.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
				className: "empty-history-neon",
				children: [
					/* @__PURE__ */ _jsxDEV(FaBoxes, {
						size: 50,
						className: "empty-icon-glow"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 176,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("p", { children: "No hay productos registrados en el inventario." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 177,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => abrirModal(),
						className: "btn-explore-neon",
						children: "Añadir Primer Producto"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 178,
						columnNumber: 15
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 175,
				columnNumber: 13
			}, this) : /* @__PURE__ */ _jsxDEV("div", {
				className: "pedidos-grid-neon",
				children: productos.map((prod) => {
					const tallas = prod.tallas ? typeof prod.tallas === "string" ? JSON.parse(prod.tallas) : prod.tallas : [];
					const totalStk = stockTotal(prod);
					return /* @__PURE__ */ _jsxDEV("div", {
						className: "pedido-card-neon",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "card-neon-top",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "order-tag",
									children: ["REF #", prod.id_producto]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 194,
									columnNumber: 23
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "order-date-tag",
									children: [
										/* @__PURE__ */ _jsxDEV(FaTag, {}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 196,
											columnNumber: 25
										}, this),
										" ",
										prod.categoria || "Sin categoría"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 195,
									columnNumber: 23
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 193,
								columnNumber: 21
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "card-neon-body",
								children: /* @__PURE__ */ _jsxDEV("div", {
									className: "product-row-neon",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "img-container-neon",
											children: /* @__PURE__ */ _jsxDEV("img", {
												src: `${URL_IMAGENES}${prod.imagen}`,
												alt: prod.nombreProducto,
												onError: (e) => {
													e.target.src = "/img/placeholder.png";
												}
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 203,
												columnNumber: 27
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 202,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "product-info-neon",
											children: [
												/* @__PURE__ */ _jsxDEV("h4", { children: prod.nombreProducto }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 210,
													columnNumber: 27
												}, this),
												/* @__PURE__ */ _jsxDEV("span", {
													className: "prod-qty-price",
													children: [
														"Color: ",
														prod.color || "N/A",
														" | Gen: ",
														prod.genero || "N/A"
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 211,
													columnNumber: 27
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													style: {
														marginTop: "6px",
														display: "flex",
														gap: "4px",
														flexWrap: "wrap"
													},
													children: tallas.filter((t) => t.stock > 0).map((t, i) => /* @__PURE__ */ _jsxDEV("span", {
														style: {
															background: "#222",
															color: "#aaa",
															padding: "1px 5px",
															borderRadius: "3px",
															fontSize: "10px",
															border: "1px solid #333"
														},
														children: [
															t.talla,
															": ",
															/* @__PURE__ */ _jsxDEV("strong", {
																style: { color: "#fff" },
																children: t.stock
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 215,
																columnNumber: 44
															}, this)
														]
													}, i, true, {
														fileName: _jsxFileName,
														lineNumber: 214,
														columnNumber: 31
													}, this))
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 212,
													columnNumber: 27
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 209,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "product-subtotal-neon",
											children: ["$", Number(prod.precioProducto).toLocaleString()]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 220,
											columnNumber: 25
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 201,
									columnNumber: 23
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 200,
								columnNumber: 21
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "card-neon-footer",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: `status-neon-pill ${totalStk < 10 ? "stock-warning" : ""}`,
									style: {
										color: totalStk < 10 ? "#c41230" : "#2ecc71",
										background: totalStk < 10 ? "rgba(196, 18, 48, 0.1)" : "rgba(46, 204, 113, 0.1)",
										borderColor: totalStk < 10 ? "rgba(196, 18, 48, 0.3)" : "rgba(46, 204, 113, 0.3)"
									},
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "dot-pulse",
											style: {
												backgroundColor: totalStk < 10 ? "#c41230" : "#2ecc71",
												boxShadow: `0 0 8px ${totalStk < 10 ? "#c41230" : "#2ecc71"}`
											}
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 228,
											columnNumber: 25
										}, this),
										"STOCK: ",
										totalStk,
										" UND"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 227,
									columnNumber: 23
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									style: {
										display: "flex",
										gap: "8px"
									},
									children: [/* @__PURE__ */ _jsxDEV("button", {
										className: "btn-icon edit",
										onClick: () => abrirModal(prod),
										title: "Editar producto",
										style: {
											background: "#222",
											border: "1px solid #444",
											color: "#3498db",
											padding: "6px 10px",
											borderRadius: "6px",
											cursor: "pointer"
										},
										children: /* @__PURE__ */ _jsxDEV(FaEdit, {}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 239,
											columnNumber: 27
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 233,
										columnNumber: 25
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										className: "btn-icon delete",
										onClick: () => eliminarProducto(prod.id_producto),
										title: "Eliminar producto",
										style: {
											background: "#222",
											border: "1px solid #444",
											color: "#c41230",
											padding: "6px 10px",
											borderRadius: "6px",
											cursor: "pointer"
										},
										children: /* @__PURE__ */ _jsxDEV(FaTrash, {}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 247,
											columnNumber: 27
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 241,
										columnNumber: 25
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 232,
									columnNumber: 23
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 226,
								columnNumber: 21
							}, this)
						]
					}, prod.id_producto, true, {
						fileName: _jsxFileName,
						lineNumber: 191,
						columnNumber: 19
					}, this);
				})
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 183,
				columnNumber: 13
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 157,
			columnNumber: 9
		}, this), mostrarModal && /* @__PURE__ */ _jsxDEV("div", {
			className: "modal-overlay",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "modal-card",
				children: [
					/* @__PURE__ */ _jsxDEV("h3", { children: editando ? "EDITAR REFERENCIA" : "AÑADIR A COLECCIÓN" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 263,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "modal-form-body",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "form-group",
								children: [/* @__PURE__ */ _jsxDEV("label", { children: "Nombre de la Referencia" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 267,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: form.nombreProducto,
									onChange: (e) => setForm({
										...form,
										nombreProducto: e.target.value
									}),
									placeholder: "Ej: Jeans 501 Original"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 268,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 266,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								style: {
									display: "flex",
									gap: "15px"
								},
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "form-group",
									style: { flex: 1 },
									children: [/* @__PURE__ */ _jsxDEV("label", { children: "Precio (COP)" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 275,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "number",
										value: form.precioProducto,
										onChange: (e) => setForm({
											...form,
											precioProducto: e.target.value
										})
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 276,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 274,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "form-group",
									style: { flex: 1 },
									children: [/* @__PURE__ */ _jsxDEV("label", { children: "Color" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 280,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: form.color,
										onChange: (e) => setForm({
											...form,
											color: e.target.value
										}),
										placeholder: "Ej: Azul, Negro..."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 281,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 279,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 273,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "form-group",
								children: [/* @__PURE__ */ _jsxDEV("label", { children: "Stock por Talla" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 288,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									style: {
										display: "flex",
										gap: "8px",
										flexWrap: "wrap",
										background: "#111",
										padding: "10px",
										borderRadius: "8px",
										border: "1px solid #333"
									},
									children: form.tallas.map((t, i) => /* @__PURE__ */ _jsxDEV("div", {
										style: {
											textAlign: "center",
											minWidth: "50px"
										},
										children: [/* @__PURE__ */ _jsxDEV("div", {
											style: {
												fontWeight: "bold",
												fontSize: "11px",
												color: "#888",
												marginBottom: "4px"
											},
											children: t.talla
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 292,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "number",
											min: "0",
											value: t.stock,
											onChange: (e) => actualizarStockTalla(i, e.target.value),
											style: {
												width: "50px",
												textAlign: "center",
												background: "#1a1a1a",
												border: "1px solid #444",
												color: "#fff",
												borderRadius: "4px",
												padding: "4px",
												outline: "none",
												MozAppearance: "textfield"
											}
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 293,
											columnNumber: 23
										}, this)]
									}, i, true, {
										fileName: _jsxFileName,
										lineNumber: 291,
										columnNumber: 21
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 289,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 287,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								style: {
									display: "flex",
									gap: "15px"
								},
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "form-group",
									style: { flex: 1 },
									children: [/* @__PURE__ */ _jsxDEV("label", { children: "Categoría" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 307,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("select", {
										value: form.id_categoria,
										onChange: (e) => setForm({
											...form,
											id_categoria: e.target.value
										}),
										className: "form-select",
										children: [/* @__PURE__ */ _jsxDEV("option", {
											value: "",
											children: "Seleccionar..."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 311,
											columnNumber: 21
										}, this), categorias.map((cat) => /* @__PURE__ */ _jsxDEV("option", {
											value: cat.id_categoria,
											children: cat.nombre
										}, cat.id_categoria, false, {
											fileName: _jsxFileName,
											lineNumber: 313,
											columnNumber: 23
										}, this))]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 308,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 306,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "form-group",
									style: { flex: 1 },
									children: [/* @__PURE__ */ _jsxDEV("label", { children: "Género" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 318,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("select", {
										value: form.genero,
										onChange: (e) => setForm({
											...form,
											genero: e.target.value
										}),
										className: "form-select",
										children: [
											/* @__PURE__ */ _jsxDEV("option", {
												value: "",
												children: "Seleccionar..."
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 322,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Hombre",
												children: "Hombre"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 323,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Mujer",
												children: "Mujer"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 324,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Niños",
												children: "Niños"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 325,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Unisex",
												children: "Unisex"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 326,
												columnNumber: 21
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 319,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 317,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 305,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "form-group",
								children: [/* @__PURE__ */ _jsxDEV("label", { children: "Proveedor" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 332,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("select", {
									value: form.id_proveedor || "",
									onChange: (e) => setForm({
										...form,
										id_proveedor: e.target.value
									}),
									className: "form-select",
									children: [/* @__PURE__ */ _jsxDEV("option", {
										value: "",
										children: "Sin proveedor"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 336,
										columnNumber: 19
									}, this), proveedores.map((prov) => /* @__PURE__ */ _jsxDEV("option", {
										value: prov.id_proveedor,
										children: prov.nombre
									}, prov.id_proveedor, false, {
										fileName: _jsxFileName,
										lineNumber: 338,
										columnNumber: 21
									}, this))]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 333,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 331,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "form-group",
								children: [
									/* @__PURE__ */ _jsxDEV("label", { children: "Imagen del Producto" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 344,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("input", {
										type: "file",
										accept: "image/*",
										onChange: (e) => setForm({
											...form,
											imagen: e.target.files[0]
										}),
										id: "file-upload",
										style: { display: "none" }
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 345,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("label", {
										htmlFor: "file-upload",
										className: "btn-upload-styled",
										children: [
											/* @__PURE__ */ _jsxDEV(UploadIconWrapper, {}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 349,
												columnNumber: 19
											}, this),
											" ",
											form.imagen ? form.imagen.name : "SELECCIONAR ARCHIVO"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 348,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 343,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 264,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "modal-footer",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							className: "btn-save",
							onClick: guardarProducto,
							children: "GUARDAR"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 355,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							className: "btn-cancel",
							onClick: () => setMostrarModal(false),
							children: "CANCELAR"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 356,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 354,
						columnNumber: 13
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 262,
				columnNumber: 11
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 261,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 155,
		columnNumber: 5
	}, this);
}
_s(Inventario, "GWOixKaq81p2cm6JpBZ8nmH0tsc=", false, function() {
	return [useNavigate];
});
_c = Inventario;
function UploadIconWrapper() {
	return /* @__PURE__ */ _jsxDEV(FaUpload, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 366,
		columnNumber: 10
	}, this);
}
_c2 = UploadIconWrapper;
export default Inventario;
var _c, _c2;
$RefreshReg$(_c, "Inventario");
$RefreshReg$(_c2, "UploadIconWrapper");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/inventario.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/inventario.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/inventario.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/inventario.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQWlCO0FBQzNDLFNBQVMsbUJBQW1CO0FBQzVCLE9BQU8sT0FBTyxnQkFBZ0I7QUFDOUIsU0FBUyxTQUFTLFFBQVEsUUFBUSxTQUFTLGFBQWEsVUFBVSxhQUFhO0FBQy9FLE9BQU87Ozs7QUFFUCxNQUFNLGlCQUFpQjtDQUFDO0NBQUs7Q0FBSztDQUFLO0NBQU07Q0FBTTtBQUVuRCxTQUFTLGFBQWE7O0NBQ3BCLE1BQU0sV0FBVyxhQUFhO0NBQzlCLE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBUyxTQUFTO0NBQzFDLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLEVBQUUsQ0FBQztDQUM5QyxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxNQUFNO0NBQ3ZELE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxNQUFNO0NBQy9DLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxLQUFLO0NBQzlDLE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEVBQUUsQ0FBQztDQUNsRCxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxFQUFFLENBQUM7Q0FFaEQsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTO0VBQy9CLGdCQUFnQjtFQUNoQixnQkFBZ0I7RUFDaEIsT0FBTztFQUNQLFFBQVE7RUFDUixjQUFjO0VBQ2QsY0FBYztFQUNkLFFBQVE7RUFDUixRQUFRLGVBQWUsS0FBSSxPQUFNO0dBQUUsT0FBTztHQUFHLE9BQU87R0FBRyxFQUFFO0VBQzFELENBQUM7Q0FFRixNQUFNLGtCQUFrQixZQUFZO0FBQ2xDLE1BQUk7R0FDRixNQUFNLE1BQU0sTUFBTSxJQUFJLElBQUksYUFBYTtBQUN2QyxnQkFBYSxJQUFJLEtBQUs7V0FDZixLQUFLO0FBQ1osV0FBUSxNQUFNLDhCQUE4QixJQUFJOzs7Q0FJcEQsTUFBTSxvQkFBb0IsWUFBWTtBQUNwQyxNQUFJO0dBQ0YsTUFBTSxNQUFNLE1BQU0sSUFBSSxJQUFJLGVBQWU7QUFDekMsa0JBQWUsSUFBSSxLQUFLO1dBQ2pCLEtBQUs7QUFDWixXQUFRLE1BQU0sK0JBQStCLElBQUk7OztDQUlyRCxNQUFNLG1CQUFtQixZQUFZO0FBQ25DLE1BQUk7R0FDRixNQUFNLE1BQU0sTUFBTSxJQUFJLElBQUksd0JBQXdCO0FBQ2xELGlCQUFjLElBQUksS0FBSztXQUNoQixLQUFLO0FBQ1osV0FBUSxNQUFNLDhCQUE4QixJQUFJOzs7QUFJcEQsaUJBQWdCO0FBQ2QsbUJBQWlCO0FBQ2pCLHFCQUFtQjtBQUNuQixvQkFBa0I7SUFDakIsRUFBRSxDQUFDO0NBRU4sTUFBTSxjQUFjLFNBQVM7QUFDM0IsTUFBSSxDQUFDLEtBQUssT0FBUSxRQUFPO0VBQ3pCLE1BQU0sU0FBUyxPQUFPLEtBQUssV0FBVyxXQUFXLEtBQUssTUFBTSxLQUFLLE9BQU8sR0FBRyxLQUFLO0FBQ2hGLFNBQU8sT0FBTyxRQUFRLEtBQUssTUFBTSxPQUFPLEVBQUUsU0FBUyxJQUFJLEVBQUU7O0NBRzNELE1BQU0sbUJBQW1CLE9BQU8sT0FBTztBQUNyQyxNQUFJLE9BQU8sUUFBUSx5Q0FBeUMsRUFBRTtBQUM1RCxPQUFJO0FBQ0YsVUFBTSxJQUFJLE9BQU8sY0FBYyxLQUFLO0FBQ3BDLFVBQU0sK0JBQStCO0FBQ3JDLHFCQUFpQjtZQUNWLE9BQU87QUFDZCxVQUFNLG9CQUFvQjs7OztDQUtoQyxNQUFNLGNBQWMsT0FBTyxTQUFTO0FBQ2xDLE1BQUksTUFBTTtBQUNSLGVBQVksS0FBSztBQUNqQixlQUFZLEtBQUssWUFBWTtHQUM3QixNQUFNLG1CQUFtQixLQUFLLFNBQ3pCLE9BQU8sS0FBSyxXQUFXLFdBQVcsS0FBSyxNQUFNLEtBQUssT0FBTyxHQUFHLEtBQUssU0FDbEUsZUFBZSxLQUFJLE9BQU07SUFBRSxPQUFPO0lBQUcsT0FBTztJQUFHLEVBQUU7QUFDckQsV0FBUTtJQUNOLGdCQUFnQixLQUFLLGtCQUFrQjtJQUN2QyxnQkFBZ0IsS0FBSyxrQkFBa0I7SUFDdkMsT0FBTyxLQUFLLFNBQVM7SUFDckIsUUFBUSxLQUFLLFVBQVU7SUFDdkIsY0FBYyxLQUFLLGdCQUFnQjtJQUNuQyxjQUFjLEtBQUssZ0JBQWdCO0lBQ25DLFFBQVE7SUFDUixRQUFRO0lBQ1QsQ0FBQztTQUNHO0FBQ0wsZUFBWSxNQUFNO0FBQ2xCLFdBQVE7SUFDTixnQkFBZ0I7SUFDaEIsZ0JBQWdCO0lBQ2hCLE9BQU87SUFDUCxRQUFRO0lBQ1IsY0FBYztJQUNkLGNBQWM7SUFDZCxRQUFRO0lBQ1IsUUFBUSxlQUFlLEtBQUksT0FBTTtLQUFFLE9BQU87S0FBRyxPQUFPO0tBQUcsRUFBRTtJQUMxRCxDQUFDOztBQUVKLGtCQUFnQixLQUFLOztDQUd2QixNQUFNLHdCQUF3QixPQUFPLFVBQVU7RUFDN0MsTUFBTSxlQUFlLENBQUMsR0FBRyxLQUFLLE9BQU87QUFDckMsZUFBYSxPQUFPLFFBQVEsU0FBUyxNQUFNLElBQUk7QUFDL0MsVUFBUTtHQUFFLEdBQUc7R0FBTSxRQUFRO0dBQWMsQ0FBQzs7Q0FHNUMsTUFBTSxrQkFBa0IsWUFBWTtBQUNsQyxNQUFJLENBQUMsS0FBSyxlQUFlLE1BQU0sQ0FBRSxRQUFPLE1BQU0sMkJBQTJCO0FBQ3pFLE1BQUksQ0FBQyxLQUFLLGVBQWdCLFFBQU8sTUFBTSwyQkFBMkI7QUFDbEUsTUFBSSxDQUFDLEtBQUssT0FBUSxRQUFPLE1BQU0sMkJBQTJCO0VBRTFELE1BQU0sT0FBTyxJQUFJLFVBQVU7QUFDM0IsT0FBSyxPQUFPLGtCQUFrQixLQUFLLGVBQWU7QUFDbEQsT0FBSyxPQUFPLGtCQUFrQixLQUFLLGVBQWU7QUFDbEQsT0FBSyxPQUFPLFNBQVMsS0FBSyxNQUFNO0FBQ2hDLE9BQUssT0FBTyxVQUFVLEtBQUssT0FBTztBQUNsQyxPQUFLLE9BQU8sZ0JBQWdCLEtBQUssYUFBYTtBQUM5QyxPQUFLLE9BQU8sZ0JBQWdCLEtBQUssZ0JBQWdCLEdBQUc7QUFDcEQsT0FBSyxPQUFPLFVBQVUsS0FBSyxVQUFVLEtBQUssT0FBTyxDQUFDO0FBRWxELE1BQUksS0FBSyxPQUFRLE1BQUssT0FBTyxVQUFVLEtBQUssT0FBTztFQUVuRCxNQUFNLFdBQVcsV0FBVyxjQUFjLGFBQWE7RUFDdkQsTUFBTSxTQUFTLFdBQVcsUUFBUTtBQUVsQyxNQUFJO0dBQ0YsTUFBTSxXQUFXLE1BQU0sSUFBSSxRQUFRLFVBQVUsS0FBSztBQUNsRCxPQUFJLFNBQVMsV0FBVyxPQUFPLFNBQVMsV0FBVyxLQUFLO0FBQ3RELFVBQU0sV0FBVywyQkFBMkIsc0JBQXNCO0FBQ2xFLG9CQUFnQixNQUFNO0FBQ3RCLHFCQUFpQjs7V0FFWixPQUFPO0dBQ2QsTUFBTSxVQUFVLE1BQU0sVUFBVSxNQUFNLFNBQVM7QUFDL0MsU0FBTSxRQUFROzs7Q0FJbEIsTUFBTSxlQUFlLFlBQVk7QUFFakMsUUFDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBQ0csU0FBUyxZQUNSLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FFRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE1BQUQsYUFBSSwwQkFBc0Isd0JBQUMsU0FBRCxFQUFTLFdBQVUsY0FBZTs7OztjQUFLOzs7O2VBQ2pFLHdCQUFDLEtBQUQsWUFBRyxnRUFBZ0U7Ozs7Y0FDL0Q7Ozs7O2NBQ04sd0JBQUMsT0FBRDtLQUFLLE9BQU87TUFBRSxTQUFTO01BQVEsS0FBSztNQUFRO2VBQTVDLENBQ0Usd0JBQUMsVUFBRDtNQUFRLFdBQVU7TUFBa0IsZUFBZSxTQUFTLGlCQUFpQjtnQkFBN0UsQ0FDRSx3QkFBQyxhQUFELEVBQWU7Ozs7eUJBQ1I7Ozs7O2VBQ1Qsd0JBQUMsVUFBRDtNQUFRLFdBQVU7TUFBbUIsZUFBZSxZQUFZO2dCQUFoRSxDQUNFLHdCQUFDLFFBQUQsRUFBVTs7Ozs4QkFDSDs7Ozs7Y0FDTDs7Ozs7YUFDRjs7Ozs7YUFFTCxVQUFVLFdBQVcsSUFDcEIsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLFNBQUQ7TUFBUyxNQUFNO01BQUksV0FBVTtNQUFvQjs7Ozs7S0FDakQsd0JBQUMsS0FBRCxZQUFHLGtEQUFrRDs7Ozs7S0FDckQsd0JBQUMsVUFBRDtNQUFRLGVBQWUsWUFBWTtNQUFFLFdBQVU7Z0JBQW1CO01BRXpEOzs7OztLQUNMOzs7OztjQUVOLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ1osVUFBVSxLQUFLLFNBQVM7S0FDdkIsTUFBTSxTQUFTLEtBQUssU0FDZixPQUFPLEtBQUssV0FBVyxXQUFXLEtBQUssTUFBTSxLQUFLLE9BQU8sR0FBRyxLQUFLLFNBQ2xFLEVBQUU7S0FDTixNQUFNLFdBQVcsV0FBVyxLQUFLO0FBRWpDLFlBQ0Usd0JBQUMsT0FBRDtNQUE0QixXQUFVO2dCQUF0QztPQUVFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWhCLENBQTRCLFNBQU0sS0FBSyxZQUFtQjs7Ozs7a0JBQzFELHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFoQjtVQUNFLHdCQUFDLE9BQUQsRUFBUzs7Ozs7O1VBQUUsS0FBSyxhQUFhO1VBQ3hCOzs7OztpQkFDSDs7Ozs7O09BRU4sd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ2Isd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFDYix3QkFBQyxPQUFEO1lBQ0UsS0FBSyxHQUFHLGVBQWUsS0FBSztZQUM1QixLQUFLLEtBQUs7WUFDVixVQUFVLE1BQU07QUFBRSxlQUFFLE9BQU8sTUFBTTs7WUFDakM7Ozs7O1dBQ0U7Ozs7O1VBQ04sd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWY7WUFDRSx3QkFBQyxNQUFELFlBQUssS0FBSyxnQkFBb0I7Ozs7O1lBQzlCLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUFoQjtjQUFpQztjQUFRLEtBQUssU0FBUztjQUFNO2NBQVMsS0FBSyxVQUFVO2NBQWE7Ozs7OztZQUNsRyx3QkFBQyxPQUFEO2FBQUssT0FBTztjQUFFLFdBQVc7Y0FBTyxTQUFTO2NBQVEsS0FBSztjQUFPLFVBQVU7Y0FBUTt1QkFDNUUsT0FBTyxRQUFPLE1BQUssRUFBRSxRQUFRLEVBQUUsQ0FBQyxLQUFLLEdBQUcsTUFDdkMsd0JBQUMsUUFBRDtjQUFjLE9BQU87ZUFBRSxZQUFZO2VBQVEsT0FBTztlQUFRLFNBQVM7ZUFBVyxjQUFjO2VBQU8sVUFBVTtlQUFRLFFBQVE7ZUFBa0I7d0JBQS9JO2VBQ0csRUFBRTtlQUFNO2VBQUUsd0JBQUMsVUFBRDtnQkFBUSxPQUFPLEVBQUUsT0FBTyxRQUFROzBCQUFHLEVBQUU7Z0JBQWU7Ozs7O2VBQzFEO2dCQUZJOzs7O3FCQUVKLENBQ1A7YUFDRTs7Ozs7WUFDRjs7Ozs7O1VBQ04sd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FBdUMsS0FDbkMsT0FBTyxLQUFLLGVBQWUsQ0FBQyxnQkFBZ0IsQ0FDMUM7Ozs7OztVQUNGOzs7Ozs7UUFDRjs7Ozs7T0FFTix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFXLG9CQUFvQixXQUFXLEtBQUssa0JBQWtCO1NBQU0sT0FBTztVQUFFLE9BQU8sV0FBVyxLQUFLLFlBQVk7VUFBVyxZQUFZLFdBQVcsS0FBSywyQkFBMkI7VUFBMkIsYUFBYSxXQUFXLEtBQUssMkJBQTJCO1VBQTJCO21CQUF4UztVQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO1dBQVksT0FBTztZQUFFLGlCQUFpQixXQUFXLEtBQUssWUFBWTtZQUFXLFdBQVcsV0FBVyxXQUFXLEtBQUssWUFBWTtZQUFhO1dBQVM7Ozs7OztVQUM3SjtVQUFTO1VBQ2I7Ozs7O2tCQUVOLHdCQUFDLE9BQUQ7U0FBSyxPQUFPO1VBQUUsU0FBUztVQUFRLEtBQUs7VUFBTzttQkFBM0MsQ0FDRSx3QkFBQyxVQUFEO1VBQ0UsV0FBVTtVQUNWLGVBQWUsV0FBVyxLQUFLO1VBQy9CLE9BQU07VUFDTixPQUFPO1dBQUUsWUFBWTtXQUFRLFFBQVE7V0FBa0IsT0FBTztXQUFXLFNBQVM7V0FBWSxjQUFjO1dBQU8sUUFBUTtXQUFXO29CQUV0SSx3QkFBQyxRQUFELEVBQVU7Ozs7O1VBQ0g7Ozs7bUJBQ1Qsd0JBQUMsVUFBRDtVQUNFLFdBQVU7VUFDVixlQUFlLGlCQUFpQixLQUFLLFlBQVk7VUFDakQsT0FBTTtVQUNOLE9BQU87V0FBRSxZQUFZO1dBQVEsUUFBUTtXQUFrQixPQUFPO1dBQVcsU0FBUztXQUFZLGNBQWM7V0FBTyxRQUFRO1dBQVc7b0JBRXRJLHdCQUFDLFNBQUQsRUFBVzs7Ozs7VUFDSjs7OztrQkFDTDs7Ozs7aUJBQ0Y7Ozs7OztPQUVGO1FBN0RJLEtBQUs7Ozs7YUE2RFQ7TUFFUjtJQUNFOzs7O1lBRUo7Ozs7O1lBR1AsZ0JBQ0Msd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFDYix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQ0Usd0JBQUMsTUFBRCxZQUFLLFdBQVcsc0JBQXNCLHNCQUEwQjs7Ozs7S0FDaEUsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FFRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFNBQUQsWUFBTywyQkFBK0I7Ozs7a0JBQ3RDLHdCQUFDLFNBQUQ7U0FBTyxNQUFLO1NBQU8sT0FBTyxLQUFLO1NBQzdCLFdBQVcsTUFBTSxRQUFRO1VBQUUsR0FBRztVQUFNLGdCQUFnQixFQUFFLE9BQU87VUFBTyxDQUFDO1NBQ3JFLGFBQVk7U0FBMkI7Ozs7aUJBQ3JDOzs7Ozs7T0FFTix3QkFBQyxPQUFEO1FBQUssT0FBTztTQUFFLFNBQVM7U0FBUSxLQUFLO1NBQVE7a0JBQTVDLENBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7U0FBYSxPQUFPLEVBQUUsTUFBTSxHQUFHO21CQUE5QyxDQUNFLHdCQUFDLFNBQUQsWUFBTyxnQkFBb0I7Ozs7bUJBQzNCLHdCQUFDLFNBQUQ7VUFBTyxNQUFLO1VBQVMsT0FBTyxLQUFLO1VBQy9CLFdBQVcsTUFBTSxRQUFRO1dBQUUsR0FBRztXQUFNLGdCQUFnQixFQUFFLE9BQU87V0FBTyxDQUFDO1VBQUk7Ozs7a0JBQ3ZFOzs7OztrQkFDTix3QkFBQyxPQUFEO1NBQUssV0FBVTtTQUFhLE9BQU8sRUFBRSxNQUFNLEdBQUc7bUJBQTlDLENBQ0Usd0JBQUMsU0FBRCxZQUFPLFNBQWE7Ozs7bUJBQ3BCLHdCQUFDLFNBQUQ7VUFBTyxNQUFLO1VBQU8sT0FBTyxLQUFLO1VBQzdCLFdBQVcsTUFBTSxRQUFRO1dBQUUsR0FBRztXQUFNLE9BQU8sRUFBRSxPQUFPO1dBQU8sQ0FBQztVQUM1RCxhQUFZO1VBQXVCOzs7O2tCQUNqQzs7Ozs7aUJBQ0Y7Ozs7OztPQUVOLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsU0FBRCxZQUFPLG1CQUF1Qjs7OztrQkFDOUIsd0JBQUMsT0FBRDtTQUFLLE9BQU87VUFBRSxTQUFTO1VBQVEsS0FBSztVQUFPLFVBQVU7VUFBUSxZQUFZO1VBQVEsU0FBUztVQUFRLGNBQWM7VUFBTyxRQUFRO1VBQWtCO21CQUM5SSxLQUFLLE9BQU8sS0FBSyxHQUFHLE1BQ25CLHdCQUFDLE9BQUQ7VUFBYSxPQUFPO1dBQUUsV0FBVztXQUFVLFVBQVU7V0FBUTtvQkFBN0QsQ0FDRSx3QkFBQyxPQUFEO1dBQUssT0FBTztZQUFFLFlBQVk7WUFBUSxVQUFVO1lBQVEsT0FBTztZQUFRLGNBQWM7WUFBTztxQkFBRyxFQUFFO1dBQVk7Ozs7b0JBQ3pHLHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0wsS0FBSTtXQUNKLE9BQU8sRUFBRTtXQUNULFdBQVcsTUFBTSxxQkFBcUIsR0FBRyxFQUFFLE9BQU8sTUFBTTtXQUN4RCxPQUFPO1lBQUUsT0FBTztZQUFRLFdBQVc7WUFBVSxZQUFZO1lBQVcsUUFBUTtZQUFrQixPQUFPO1lBQVEsY0FBYztZQUFPLFNBQVM7WUFBTyxTQUFTO1lBQVEsZUFBZTtZQUFhO1dBQy9MOzs7O21CQUNFO1lBVEk7Ozs7aUJBU0osQ0FDTjtTQUNFOzs7O2lCQUNGOzs7Ozs7T0FFTix3QkFBQyxPQUFEO1FBQUssT0FBTztTQUFFLFNBQVM7U0FBUSxLQUFLO1NBQVE7a0JBQTVDLENBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7U0FBYSxPQUFPLEVBQUUsTUFBTSxHQUFHO21CQUE5QyxDQUNFLHdCQUFDLFNBQUQsWUFBTyxhQUFpQjs7OzttQkFDeEIsd0JBQUMsVUFBRDtVQUFRLE9BQU8sS0FBSztVQUNsQixXQUFXLE1BQU0sUUFBUTtXQUFFLEdBQUc7V0FBTSxjQUFjLEVBQUUsT0FBTztXQUFPLENBQUM7VUFDbkUsV0FBVTtvQkFGWixDQUdFLHdCQUFDLFVBQUQ7V0FBUSxPQUFNO3FCQUFHO1dBQXVCOzs7O29CQUN2QyxXQUFXLEtBQUksUUFDZCx3QkFBQyxVQUFEO1dBQStCLE9BQU8sSUFBSTtxQkFBZSxJQUFJO1dBQWdCLEVBQWhFLElBQUk7Ozs7a0JBQTRELENBQzdFLENBQ0s7Ozs7O2tCQUNMOzs7OztrQkFDTix3QkFBQyxPQUFEO1NBQUssV0FBVTtTQUFhLE9BQU8sRUFBRSxNQUFNLEdBQUc7bUJBQTlDLENBQ0Usd0JBQUMsU0FBRCxZQUFPLFVBQWM7Ozs7bUJBQ3JCLHdCQUFDLFVBQUQ7VUFBUSxPQUFPLEtBQUs7VUFDbEIsV0FBVyxNQUFNLFFBQVE7V0FBRSxHQUFHO1dBQU0sUUFBUSxFQUFFLE9BQU87V0FBTyxDQUFDO1VBQzdELFdBQVU7b0JBRlo7V0FHRSx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBRztZQUF1Qjs7Ozs7V0FDeEMsd0JBQUMsVUFBRDtZQUFRLE9BQU07c0JBQVM7WUFBZTs7Ozs7V0FDdEMsd0JBQUMsVUFBRDtZQUFRLE9BQU07c0JBQVE7WUFBYzs7Ozs7V0FDcEMsd0JBQUMsVUFBRDtZQUFRLE9BQU07c0JBQVE7WUFBYzs7Ozs7V0FDcEMsd0JBQUMsVUFBRDtZQUFRLE9BQU07c0JBQVM7WUFBZTs7Ozs7V0FDL0I7Ozs7O2tCQUNMOzs7OztpQkFDRjs7Ozs7O09BRU4sd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxTQUFELFlBQU8sYUFBaUI7Ozs7a0JBQ3hCLHdCQUFDLFVBQUQ7U0FBUSxPQUFPLEtBQUssZ0JBQWdCO1NBQ2xDLFdBQVcsTUFBTSxRQUFRO1VBQUUsR0FBRztVQUFNLGNBQWMsRUFBRSxPQUFPO1VBQU8sQ0FBQztTQUNuRSxXQUFVO21CQUZaLENBR0Usd0JBQUMsVUFBRDtVQUFRLE9BQU07b0JBQUc7VUFBc0I7Ozs7bUJBQ3RDLFlBQVksS0FBSyxTQUNoQix3QkFBQyxVQUFEO1VBQWdDLE9BQU8sS0FBSztvQkFBZSxLQUFLO1VBQWdCLEVBQW5FLEtBQUs7Ozs7aUJBQThELENBQ2hGLENBQ0s7Ozs7O2lCQUNMOzs7Ozs7T0FFTix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLFNBQUQsWUFBTyx1QkFBMkI7Ozs7O1NBQ2xDLHdCQUFDLFNBQUQ7VUFBTyxNQUFLO1VBQU8sUUFBTztVQUN4QixXQUFXLE1BQU0sUUFBUTtXQUFFLEdBQUc7V0FBTSxRQUFRLEVBQUUsT0FBTyxNQUFNO1dBQUksQ0FBQztVQUNoRSxJQUFHO1VBQWMsT0FBTyxFQUFFLFNBQVMsUUFBUTtVQUFJOzs7OztTQUNqRCx3QkFBQyxTQUFEO1VBQU8sU0FBUTtVQUFjLFdBQVU7b0JBQXZDO1dBQ0Usd0JBQUMsbUJBQUQsRUFBcUI7Ozs7OztXQUFFLEtBQUssU0FBUyxLQUFLLE9BQU8sT0FBTztXQUNsRDs7Ozs7O1NBQ0o7Ozs7OztPQUNGOzs7Ozs7S0FFTix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFVBQUQ7T0FBUSxXQUFVO09BQVcsU0FBUztpQkFBaUI7T0FBZ0I7Ozs7Z0JBQ3ZFLHdCQUFDLFVBQUQ7T0FBUSxXQUFVO09BQWEsZUFBZSxnQkFBZ0IsTUFBTTtpQkFBRTtPQUFpQjs7OztlQUNuRjs7Ozs7O0tBQ0Y7Ozs7OztHQUNGOzs7O1dBRUo7Ozs7Ozs7OztFQUVUOztBQUVELFNBQVMsb0JBQW9CO0FBQzNCLFFBQU8sd0JBQUMsVUFBRCxFQUFZOzs7Ozs7O0FBR3JCLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiaW52ZW50YXJpby5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgYXBpLCB7IEJBU0VfVVJMIH0gZnJvbSBcIi4vYXBpXCI7XHJcbmltcG9ydCB7IEZhQm94ZXMsIEZhUGx1cywgRmFFZGl0LCBGYVRyYXNoLCBGYUFycm93TGVmdCwgRmFVcGxvYWQsIEZhVGFnIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCBcIi4vaW52ZW50YXJpby5jc3NcIjtcclxuXHJcbmNvbnN0IFRBTExBU19ERUZBVUxUID0gW1wiU1wiLCBcIk1cIiwgXCJMXCIsIFwiWExcIiwgXCJYWExcIl07XHJcblxyXG5mdW5jdGlvbiBJbnZlbnRhcmlvKCkge1xyXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcclxuICBjb25zdCBbdmlldywgc2V0Vmlld10gPSB1c2VTdGF0ZShcImxpc3RhclwiKTtcclxuICBjb25zdCBbcHJvZHVjdG9zLCBzZXRQcm9kdWN0b3NdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFttb3N0cmFyTW9kYWwsIHNldE1vc3RyYXJNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2VkaXRhbmRvLCBzZXRFZGl0YW5kb10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2lkQWN0dWFsLCBzZXRJZEFjdHVhbF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbcHJvdmVlZG9yZXMsIHNldFByb3ZlZWRvcmVzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbY2F0ZWdvcmlhcywgc2V0Q2F0ZWdvcmlhc10gPSB1c2VTdGF0ZShbXSk7XHJcblxyXG4gIGNvbnN0IFtmb3JtLCBzZXRGb3JtXSA9IHVzZVN0YXRlKHtcclxuICAgIG5vbWJyZVByb2R1Y3RvOiBcIlwiLFxyXG4gICAgcHJlY2lvUHJvZHVjdG86IFwiXCIsXHJcbiAgICBjb2xvcjogXCJcIixcclxuICAgIGdlbmVybzogXCJcIixcclxuICAgIGlkX2NhdGVnb3JpYTogXCJcIixcclxuICAgIGlkX3Byb3ZlZWRvcjogXCJcIixcclxuICAgIGltYWdlbjogbnVsbCxcclxuICAgIHRhbGxhczogVEFMTEFTX0RFRkFVTFQubWFwKHQgPT4gKHsgdGFsbGE6IHQsIHN0b2NrOiAwIH0pKVxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBjYXJnYXJQcm9kdWN0b3MgPSBhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KFwiL3Byb2R1Y3Rvc1wiKTtcclxuICAgICAgc2V0UHJvZHVjdG9zKHJlcy5kYXRhKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgY2FyZ2FuZG8gaW52ZW50YXJpbzpcIiwgZXJyKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBjYXJnYXJQcm92ZWVkb3JlcyA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoXCIvcHJvdmVlZG9yZXNcIik7XHJcbiAgICAgIHNldFByb3ZlZWRvcmVzKHJlcy5kYXRhKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgY2FyZ2FuZG8gcHJvdmVlZG9yZXM6XCIsIGVycik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgY2FyZ2FyQ2F0ZWdvcmlhcyA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoXCIvcHJvZHVjdG9zL2NhdGVnb3JpYXNcIik7XHJcbiAgICAgIHNldENhdGVnb3JpYXMocmVzLmRhdGEpO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBjYXJnYW5kbyBjYXRlZ29yaWFzOlwiLCBlcnIpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjYXJnYXJQcm9kdWN0b3MoKTtcclxuICAgIGNhcmdhclByb3ZlZWRvcmVzKCk7XHJcbiAgICBjYXJnYXJDYXRlZ29yaWFzKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBzdG9ja1RvdGFsID0gKHByb2QpID0+IHtcclxuICAgIGlmICghcHJvZC50YWxsYXMpIHJldHVybiAwO1xyXG4gICAgY29uc3QgdGFsbGFzID0gdHlwZW9mIHByb2QudGFsbGFzID09PSAnc3RyaW5nJyA/IEpTT04ucGFyc2UocHJvZC50YWxsYXMpIDogcHJvZC50YWxsYXM7XHJcbiAgICByZXR1cm4gdGFsbGFzLnJlZHVjZSgoc3VtLCB0KSA9PiBzdW0gKyAodC5zdG9jayB8fCAwKSwgMCk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZWxpbWluYXJQcm9kdWN0byA9IGFzeW5jIChpZCkgPT4ge1xyXG4gICAgaWYgKHdpbmRvdy5jb25maXJtKFwiwr9Fc3TDoXMgc2VndXJvIGRlIGJvcnJhciBlc3RlIHByb2R1Y3RvP1wiKSkge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGF3YWl0IGFwaS5kZWxldGUoYC9wcm9kdWN0b3MvJHtpZH1gKTtcclxuICAgICAgICBhbGVydChcIlByb2R1Y3RvIGVsaW1pbmFkbyBjb24gw6l4aXRvXCIpO1xyXG4gICAgICAgIGNhcmdhclByb2R1Y3RvcygpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGFsZXJ0KFwiRXJyb3IgYWwgZWxpbWluYXJcIik7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBhYnJpck1vZGFsID0gKHByb2QgPSBudWxsKSA9PiB7XHJcbiAgICBpZiAocHJvZCkge1xyXG4gICAgICBzZXRFZGl0YW5kbyh0cnVlKTtcclxuICAgICAgc2V0SWRBY3R1YWwocHJvZC5pZF9wcm9kdWN0byk7XHJcbiAgICAgIGNvbnN0IHRhbGxhc0V4aXN0ZW50ZXMgPSBwcm9kLnRhbGxhc1xyXG4gICAgICAgID8gKHR5cGVvZiBwcm9kLnRhbGxhcyA9PT0gJ3N0cmluZycgPyBKU09OLnBhcnNlKHByb2QudGFsbGFzKSA6IHByb2QudGFsbGFzKVxyXG4gICAgICAgIDogVEFMTEFTX0RFRkFVTFQubWFwKHQgPT4gKHsgdGFsbGE6IHQsIHN0b2NrOiAwIH0pKTtcclxuICAgICAgc2V0Rm9ybSh7XHJcbiAgICAgICAgbm9tYnJlUHJvZHVjdG86IHByb2Qubm9tYnJlUHJvZHVjdG8gfHwgXCJcIixcclxuICAgICAgICBwcmVjaW9Qcm9kdWN0bzogcHJvZC5wcmVjaW9Qcm9kdWN0byB8fCBcIlwiLFxyXG4gICAgICAgIGNvbG9yOiBwcm9kLmNvbG9yIHx8IFwiXCIsXHJcbiAgICAgICAgZ2VuZXJvOiBwcm9kLmdlbmVybyB8fCBcIlwiLFxyXG4gICAgICAgIGlkX2NhdGVnb3JpYTogcHJvZC5pZF9jYXRlZ29yaWEgfHwgXCJcIixcclxuICAgICAgICBpZF9wcm92ZWVkb3I6IHByb2QuaWRfcHJvdmVlZG9yIHx8IFwiXCIsXHJcbiAgICAgICAgaW1hZ2VuOiBudWxsLFxyXG4gICAgICAgIHRhbGxhczogdGFsbGFzRXhpc3RlbnRlc1xyXG4gICAgICB9KTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldEVkaXRhbmRvKGZhbHNlKTtcclxuICAgICAgc2V0Rm9ybSh7XHJcbiAgICAgICAgbm9tYnJlUHJvZHVjdG86IFwiXCIsXHJcbiAgICAgICAgcHJlY2lvUHJvZHVjdG86IFwiXCIsXHJcbiAgICAgICAgY29sb3I6IFwiXCIsXHJcbiAgICAgICAgZ2VuZXJvOiBcIlwiLFxyXG4gICAgICAgIGlkX2NhdGVnb3JpYTogXCJcIixcclxuICAgICAgICBpZF9wcm92ZWVkb3I6IFwiXCIsXHJcbiAgICAgICAgaW1hZ2VuOiBudWxsLFxyXG4gICAgICAgIHRhbGxhczogVEFMTEFTX0RFRkFVTFQubWFwKHQgPT4gKHsgdGFsbGE6IHQsIHN0b2NrOiAwIH0pKVxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICAgIHNldE1vc3RyYXJNb2RhbCh0cnVlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBhY3R1YWxpemFyU3RvY2tUYWxsYSA9IChpbmRleCwgdmFsb3IpID0+IHtcclxuICAgIGNvbnN0IG51ZXZhc1RhbGxhcyA9IFsuLi5mb3JtLnRhbGxhc107XHJcbiAgICBudWV2YXNUYWxsYXNbaW5kZXhdLnN0b2NrID0gcGFyc2VJbnQodmFsb3IpIHx8IDA7XHJcbiAgICBzZXRGb3JtKHsgLi4uZm9ybSwgdGFsbGFzOiBudWV2YXNUYWxsYXMgfSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZ3VhcmRhclByb2R1Y3RvID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgaWYgKCFmb3JtLm5vbWJyZVByb2R1Y3RvLnRyaW0oKSkgcmV0dXJuIGFsZXJ0KFwiRWwgbm9tYnJlIGVzIG9ibGlnYXRvcmlvXCIpO1xyXG4gICAgaWYgKCFmb3JtLnByZWNpb1Byb2R1Y3RvKSByZXR1cm4gYWxlcnQoXCJFbCBwcmVjaW8gZXMgb2JsaWdhdG9yaW9cIik7XHJcbiAgICBpZiAoIWZvcm0uZ2VuZXJvKSByZXR1cm4gYWxlcnQoXCJFbCBnw6luZXJvIGVzIG9ibGlnYXRvcmlvXCIpO1xyXG5cclxuICAgIGNvbnN0IGRhdGEgPSBuZXcgRm9ybURhdGEoKTtcclxuICAgIGRhdGEuYXBwZW5kKFwibm9tYnJlUHJvZHVjdG9cIiwgZm9ybS5ub21icmVQcm9kdWN0byk7XHJcbiAgICBkYXRhLmFwcGVuZChcInByZWNpb1Byb2R1Y3RvXCIsIGZvcm0ucHJlY2lvUHJvZHVjdG8pO1xyXG4gICAgZGF0YS5hcHBlbmQoXCJjb2xvclwiLCBmb3JtLmNvbG9yKTtcclxuICAgIGRhdGEuYXBwZW5kKFwiZ2VuZXJvXCIsIGZvcm0uZ2VuZXJvKTtcclxuICAgIGRhdGEuYXBwZW5kKFwiaWRfY2F0ZWdvcmlhXCIsIGZvcm0uaWRfY2F0ZWdvcmlhKTtcclxuICAgIGRhdGEuYXBwZW5kKFwiaWRfcHJvdmVlZG9yXCIsIGZvcm0uaWRfcHJvdmVlZG9yIHx8IFwiXCIpO1xyXG4gICAgZGF0YS5hcHBlbmQoXCJ0YWxsYXNcIiwgSlNPTi5zdHJpbmdpZnkoZm9ybS50YWxsYXMpKTtcclxuXHJcbiAgICBpZiAoZm9ybS5pbWFnZW4pIGRhdGEuYXBwZW5kKFwiaW1hZ2VuXCIsIGZvcm0uaW1hZ2VuKTtcclxuXHJcbiAgICBjb25zdCBlbmRwb2ludCA9IGVkaXRhbmRvID8gYC9wcm9kdWN0b3MvJHtpZEFjdHVhbH1gIDogXCIvcHJvZHVjdG9zXCI7XHJcbiAgICBjb25zdCBtZXRvZG8gPSBlZGl0YW5kbyA/IFwicHV0XCIgOiBcInBvc3RcIjtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaVttZXRvZG9dKGVuZHBvaW50LCBkYXRhKTtcclxuICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1cyA9PT0gMjAwIHx8IHJlc3BvbnNlLnN0YXR1cyA9PT0gMjAxKSB7XHJcbiAgICAgICAgYWxlcnQoZWRpdGFuZG8gPyBcIsKhUHJvZHVjdG8gYWN0dWFsaXphZG8hXCIgOiBcIsKhUHJvZHVjdG8gZ3VhcmRhZG8hXCIpO1xyXG4gICAgICAgIHNldE1vc3RyYXJNb2RhbChmYWxzZSk7XHJcbiAgICAgICAgY2FyZ2FyUHJvZHVjdG9zKCk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnN0IG1lbnNhamUgPSBlcnJvci5yZXNwb25zZT8uZGF0YT8uZXJyb3IgfHwgXCJFcnJvciBlbiBsYSBvcGVyYWNpw7NuXCI7XHJcbiAgICAgIGFsZXJ0KG1lbnNhamUpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IFVSTF9JTUFHRU5FUyA9IEJBU0VfVVJMIHx8IFwiaHR0cDovL2xvY2FsaG9zdDozMDAyXCI7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImFkbWluLW1haW4td3JhcHBlciBwZWRpZG9zLXBhZ2Utd3JhcHBlclwiPlxyXG4gICAgICB7dmlldyA9PT0gXCJsaXN0YXJcIiAmJiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpbnZlbnRvcnktbGlzdC12aWV3XCI+XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGlzdG9yeS1oZWFkZXItbmVvblwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhlYWRlci10aXRsZS1ib3hcIj5cclxuICAgICAgICAgICAgICA8aDI+R0VTVEnDk04gREUgSU5WRU5UQVJJTyA8RmFCb3hlcyBjbGFzc05hbWU9XCJpY29uLXB1bHNlXCIgLz48L2gyPlxyXG4gICAgICAgICAgICAgIDxwPkNvbnRyb2wgZGUgZXhpc3RlbmNpYXMsIHRhbGxhcyB5IHJlZmVyZW5jaWFzIGVuIHRpZW1wbyByZWFsLjwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGdhcDogXCIxMnB4XCIgfX0+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4tcmV0dXJuLW5lb25cIiBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZShcIi9ob21lL2NhdGFsb2dvXCIpfT5cclxuICAgICAgICAgICAgICAgIDxGYUFycm93TGVmdCAvPiBQQU5FTFxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuLWV4cGxvcmUtbmVvblwiIG9uQ2xpY2s9eygpID0+IGFicmlyTW9kYWwoKX0+XHJcbiAgICAgICAgICAgICAgICA8RmFQbHVzIC8+IE5VRVZPIElURU1cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7cHJvZHVjdG9zLmxlbmd0aCA9PT0gMCA/IChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJlbXB0eS1oaXN0b3J5LW5lb25cIj5cclxuICAgICAgICAgICAgICA8RmFCb3hlcyBzaXplPXs1MH0gY2xhc3NOYW1lPVwiZW1wdHktaWNvbi1nbG93XCIgLz5cclxuICAgICAgICAgICAgICA8cD5ObyBoYXkgcHJvZHVjdG9zIHJlZ2lzdHJhZG9zIGVuIGVsIGludmVudGFyaW8uPC9wPlxyXG4gICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gYWJyaXJNb2RhbCgpfSBjbGFzc05hbWU9XCJidG4tZXhwbG9yZS1uZW9uXCI+XHJcbiAgICAgICAgICAgICAgICBBw7FhZGlyIFByaW1lciBQcm9kdWN0b1xyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGVkaWRvcy1ncmlkLW5lb25cIj5cclxuICAgICAgICAgICAgICB7cHJvZHVjdG9zLm1hcCgocHJvZCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgdGFsbGFzID0gcHJvZC50YWxsYXNcclxuICAgICAgICAgICAgICAgICAgPyAodHlwZW9mIHByb2QudGFsbGFzID09PSAnc3RyaW5nJyA/IEpTT04ucGFyc2UocHJvZC50YWxsYXMpIDogcHJvZC50YWxsYXMpXHJcbiAgICAgICAgICAgICAgICAgIDogW107XHJcbiAgICAgICAgICAgICAgICBjb25zdCB0b3RhbFN0ayA9IHN0b2NrVG90YWwocHJvZCk7XHJcblxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e3Byb2QuaWRfcHJvZHVjdG99IGNsYXNzTmFtZT1cInBlZGlkby1jYXJkLW5lb25cIj5cclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQtbmVvbi10b3BcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm9yZGVyLXRhZ1wiPlJFRiAje3Byb2QuaWRfcHJvZHVjdG99PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwib3JkZXItZGF0ZS10YWdcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEZhVGFnIC8+IHtwcm9kLmNhdGVnb3JpYSB8fCBcIlNpbiBjYXRlZ29yw61hXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZC1uZW9uLWJvZHlcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZHVjdC1yb3ctbmVvblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImltZy1jb250YWluZXItbmVvblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxpbWcgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcmM9e2Ake1VSTF9JTUFHRU5FU30ke3Byb2QuaW1hZ2VufWB9IFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWx0PXtwcm9kLm5vbWJyZVByb2R1Y3RvfSBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uRXJyb3I9eyhlKSA9PiB7IGUudGFyZ2V0LnNyYyA9IFwiL2ltZy9wbGFjZWhvbGRlci5wbmdcIjsgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9kdWN0LWluZm8tbmVvblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxoND57cHJvZC5ub21icmVQcm9kdWN0b308L2g0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInByb2QtcXR5LXByaWNlXCI+Q29sb3I6IHtwcm9kLmNvbG9yIHx8IFwiTi9BXCJ9IHwgR2VuOiB7cHJvZC5nZW5lcm8gfHwgXCJOL0FcIn08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBtYXJnaW5Ub3A6IFwiNnB4XCIsIGRpc3BsYXk6IFwiZmxleFwiLCBnYXA6IFwiNHB4XCIsIGZsZXhXcmFwOiBcIndyYXBcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0YWxsYXMuZmlsdGVyKHQgPT4gdC5zdG9jayA+IDApLm1hcCgodCwgaSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBrZXk9e2l9IHN0eWxlPXt7IGJhY2tncm91bmQ6IFwiIzIyMlwiLCBjb2xvcjogXCIjYWFhXCIsIHBhZGRpbmc6IFwiMXB4IDVweFwiLCBib3JkZXJSYWRpdXM6IFwiM3B4XCIsIGZvbnRTaXplOiBcIjEwcHhcIiwgYm9yZGVyOiBcIjFweCBzb2xpZCAjMzMzXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3QudGFsbGF9OiA8c3Ryb25nIHN0eWxlPXt7IGNvbG9yOiBcIiNmZmZcIiB9fT57dC5zdG9ja308L3N0cm9uZz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2R1Y3Qtc3VidG90YWwtbmVvblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICR7TnVtYmVyKHByb2QucHJlY2lvUHJvZHVjdG8pLnRvTG9jYWxlU3RyaW5nKCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZC1uZW9uLWZvb3RlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BzdGF0dXMtbmVvbi1waWxsICR7dG90YWxTdGsgPCAxMCA/IFwic3RvY2std2FybmluZ1wiIDogXCJcIn1gfSBzdHlsZT17eyBjb2xvcjogdG90YWxTdGsgPCAxMCA/IFwiI2M0MTIzMFwiIDogXCIjMmVjYzcxXCIsIGJhY2tncm91bmQ6IHRvdGFsU3RrIDwgMTAgPyBcInJnYmEoMTk2LCAxOCwgNDgsIDAuMSlcIiA6IFwicmdiYSg0NiwgMjA0LCAxMTMsIDAuMSlcIiwgYm9yZGVyQ29sb3I6IHRvdGFsU3RrIDwgMTAgPyBcInJnYmEoMTk2LCAxOCwgNDgsIDAuMylcIiA6IFwicmdiYSg0NiwgMjA0LCAxMTMsIDAuMylcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZG90LXB1bHNlXCIgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiB0b3RhbFN0ayA8IDEwID8gXCIjYzQxMjMwXCIgOiBcIiMyZWNjNzFcIiwgYm94U2hhZG93OiBgMCAwIDhweCAke3RvdGFsU3RrIDwgMTAgPyBcIiNjNDEyMzBcIiA6IFwiIzJlY2M3MVwifWAgfX0+PC9zcGFuPiBcclxuICAgICAgICAgICAgICAgICAgICAgICAgU1RPQ0s6IHt0b3RhbFN0a30gVU5EXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgZ2FwOiBcIjhweFwiIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0bi1pY29uIGVkaXRcIiBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBhYnJpck1vZGFsKHByb2QpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiRWRpdGFyIHByb2R1Y3RvXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBiYWNrZ3JvdW5kOiBcIiMyMjJcIiwgYm9yZGVyOiBcIjFweCBzb2xpZCAjNDQ0XCIsIGNvbG9yOiBcIiMzNDk4ZGJcIiwgcGFkZGluZzogXCI2cHggMTBweFwiLCBib3JkZXJSYWRpdXM6IFwiNnB4XCIsIGN1cnNvcjogXCJwb2ludGVyXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxGYUVkaXQgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYnRuLWljb24gZGVsZXRlXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gZWxpbWluYXJQcm9kdWN0byhwcm9kLmlkX3Byb2R1Y3RvKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkVsaW1pbmFyIHByb2R1Y3RvXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBiYWNrZ3JvdW5kOiBcIiMyMjJcIiwgYm9yZGVyOiBcIjFweCBzb2xpZCAjNDQ0XCIsIGNvbG9yOiBcIiNjNDEyMzBcIiwgcGFkZGluZzogXCI2cHggMTBweFwiLCBib3JkZXJSYWRpdXM6IFwiNnB4XCIsIGN1cnNvcjogXCJwb2ludGVyXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxGYVRyYXNoIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIHttb3N0cmFyTW9kYWwgJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibW9kYWwtb3ZlcmxheVwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtb2RhbC1jYXJkXCI+XHJcbiAgICAgICAgICAgIDxoMz57ZWRpdGFuZG8gPyBcIkVESVRBUiBSRUZFUkVOQ0lBXCIgOiBcIkHDkUFESVIgQSBDT0xFQ0NJw5NOXCJ9PC9oMz5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtb2RhbC1mb3JtLWJvZHlcIj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWw+Tm9tYnJlIGRlIGxhIFJlZmVyZW5jaWE8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgdmFsdWU9e2Zvcm0ubm9tYnJlUHJvZHVjdG99XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybSh7IC4uLmZvcm0sIG5vbWJyZVByb2R1Y3RvOiBlLnRhcmdldC52YWx1ZSB9KX1cclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFajogSmVhbnMgNTAxIE9yaWdpbmFsXCIgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgZ2FwOiBcIjE1cHhcIiB9fT5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cFwiIHN0eWxlPXt7IGZsZXg6IDEgfX0+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbD5QcmVjaW8gKENPUCk8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cIm51bWJlclwiIHZhbHVlPXtmb3JtLnByZWNpb1Byb2R1Y3RvfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybSh7IC4uLmZvcm0sIHByZWNpb1Byb2R1Y3RvOiBlLnRhcmdldC52YWx1ZSB9KX0gLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwXCIgc3R5bGU9e3sgZmxleDogMSB9fT5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsPkNvbG9yPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgdmFsdWU9e2Zvcm0uY29sb3J9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtKHsgLi4uZm9ybSwgY29sb3I6IGUudGFyZ2V0LnZhbHVlIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRWo6IEF6dWwsIE5lZ3JvLi4uXCIgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbD5TdG9jayBwb3IgVGFsbGE8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgZ2FwOiBcIjhweFwiLCBmbGV4V3JhcDogXCJ3cmFwXCIsIGJhY2tncm91bmQ6IFwiIzExMVwiLCBwYWRkaW5nOiBcIjEwcHhcIiwgYm9yZGVyUmFkaXVzOiBcIjhweFwiLCBib3JkZXI6IFwiMXB4IHNvbGlkICMzMzNcIiB9fT5cclxuICAgICAgICAgICAgICAgICAge2Zvcm0udGFsbGFzLm1hcCgodCwgaSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpfSBzdHlsZT17eyB0ZXh0QWxpZ246IFwiY2VudGVyXCIsIG1pbldpZHRoOiBcIjUwcHhcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFdlaWdodDogXCJib2xkXCIsIGZvbnRTaXplOiBcIjExcHhcIiwgY29sb3I6IFwiIzg4OFwiLCBtYXJnaW5Cb3R0b206IFwiNHB4XCIgfX0+e3QudGFsbGF9PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1pbj1cIjBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dC5zdG9ja31cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBhY3R1YWxpemFyU3RvY2tUYWxsYShpLCBlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBcIjUwcHhcIiwgdGV4dEFsaWduOiBcImNlbnRlclwiLCBiYWNrZ3JvdW5kOiBcIiMxYTFhMWFcIiwgYm9yZGVyOiBcIjFweCBzb2xpZCAjNDQ0XCIsIGNvbG9yOiBcIiNmZmZcIiwgYm9yZGVyUmFkaXVzOiBcIjRweFwiLCBwYWRkaW5nOiBcIjRweFwiLCBvdXRsaW5lOiBcIm5vbmVcIiwgTW96QXBwZWFyYW5jZTogXCJ0ZXh0ZmllbGRcIiB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgZ2FwOiBcIjE1cHhcIiB9fT5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cFwiIHN0eWxlPXt7IGZsZXg6IDEgfX0+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbD5DYXRlZ29yw61hPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPHNlbGVjdCB2YWx1ZT17Zm9ybS5pZF9jYXRlZ29yaWF9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtKHsgLi4uZm9ybSwgaWRfY2F0ZWdvcmlhOiBlLnRhcmdldC52YWx1ZSB9KX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmb3JtLXNlbGVjdFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5TZWxlY2Npb25hci4uLjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIHtjYXRlZ29yaWFzLm1hcChjYXQgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2NhdC5pZF9jYXRlZ29yaWF9IHZhbHVlPXtjYXQuaWRfY2F0ZWdvcmlhfT57Y2F0Lm5vbWJyZX08L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cFwiIHN0eWxlPXt7IGZsZXg6IDEgfX0+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbD5Hw6luZXJvPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPHNlbGVjdCB2YWx1ZT17Zm9ybS5nZW5lcm99XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtKHsgLi4uZm9ybSwgZ2VuZXJvOiBlLnRhcmdldC52YWx1ZSB9KX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmb3JtLXNlbGVjdFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5TZWxlY2Npb25hci4uLjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJIb21icmVcIj5Ib21icmU8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiTXVqZXJcIj5NdWplcjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJOacOxb3NcIj5OacOxb3M8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiVW5pc2V4XCI+VW5pc2V4PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsPlByb3ZlZWRvcjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8c2VsZWN0IHZhbHVlPXtmb3JtLmlkX3Byb3ZlZWRvciB8fCBcIlwifVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZvcm0oeyAuLi5mb3JtLCBpZF9wcm92ZWVkb3I6IGUudGFyZ2V0LnZhbHVlIH0pfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmb3JtLXNlbGVjdFwiPlxyXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2luIHByb3ZlZWRvcjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICB7cHJvdmVlZG9yZXMubWFwKChwcm92KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e3Byb3YuaWRfcHJvdmVlZG9yfSB2YWx1ZT17cHJvdi5pZF9wcm92ZWVkb3J9Pntwcm92Lm5vbWJyZX08L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWw+SW1hZ2VuIGRlbCBQcm9kdWN0bzwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cImZpbGVcIiBhY2NlcHQ9XCJpbWFnZS8qXCJcclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtKHsgLi4uZm9ybSwgaW1hZ2VuOiBlLnRhcmdldC5maWxlc1swXSB9KX1cclxuICAgICAgICAgICAgICAgICAgaWQ9XCJmaWxlLXVwbG9hZFwiIHN0eWxlPXt7IGRpc3BsYXk6IFwibm9uZVwiIH19IC8+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cImZpbGUtdXBsb2FkXCIgY2xhc3NOYW1lPVwiYnRuLXVwbG9hZC1zdHlsZWRcIj5cclxuICAgICAgICAgICAgICAgICAgPFVwbG9hZEljb25XcmFwcGVyIC8+IHtmb3JtLmltYWdlbiA/IGZvcm0uaW1hZ2VuLm5hbWUgOiBcIlNFTEVDQ0lPTkFSIEFSQ0hJVk9cIn1cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtb2RhbC1mb290ZXJcIj5cclxuICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0bi1zYXZlXCIgb25DbGljaz17Z3VhcmRhclByb2R1Y3RvfT5HVUFSREFSPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4tY2FuY2VsXCIgb25DbGljaz17KCkgPT4gc2V0TW9zdHJhck1vZGFsKGZhbHNlKX0+Q0FOQ0VMQVI8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIFVwbG9hZEljb25XcmFwcGVyKCkge1xyXG4gIHJldHVybiA8RmFVcGxvYWQgLz47XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEludmVudGFyaW87Il19