import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=66677652"; const StrictMode = __vite__cjsImport0_react["StrictMode"];
import __vite__cjsImport1_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=66677652"; const createRoot = __vite__cjsImport1_reactDom_client["createRoot"];
import App from "/src/app.jsx";
var _jsxFileName = "C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/main.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=66677652"; const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];
createRoot(document.getElementById("root")).render(/* @__PURE__ */ _jsxDEV(StrictMode, { children: /* @__PURE__ */ _jsxDEV(App, {}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 8,
	columnNumber: 5
}, this) }, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 7,
	columnNumber: 3
}, this));

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxrQkFBa0I7QUFFM0IsT0FBTyxTQUFTOzs7QUFFaEIsV0FBVyxTQUFTLGVBQWUsT0FBTyxDQUFDLENBQUMsT0FDMUMsd0JBQUMsWUFBRCxZQUNFLHdCQUFDLEtBQUQsRUFBTzs7OztVQUNJOzs7O1NBQ2QiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsibWFpbi5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgU3RyaWN0TW9kZSB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyBjcmVhdGVSb290IH0gZnJvbSAncmVhY3QtZG9tL2NsaWVudCdcclxuXHJcbmltcG9ydCBBcHAgZnJvbSAnLi9hcHAuanN4J1xyXG5cclxuY3JlYXRlUm9vdChkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncm9vdCcpKS5yZW5kZXIoXHJcbiAgPFN0cmljdE1vZGU+XHJcbiAgICA8QXBwIC8+XHJcbiAgPC9TdHJpY3RNb2RlPixcclxuKVxyXG4iXX0=