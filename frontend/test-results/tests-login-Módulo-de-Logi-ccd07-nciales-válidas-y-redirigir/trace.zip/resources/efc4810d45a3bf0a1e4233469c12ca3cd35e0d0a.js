import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/landing.jsx");import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=66677652"; const React = __vite__cjsImport0_react;
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=66677652";
import "/src/Landing.css";
var _jsxFileName = "C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/landing.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=66677652"; const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
const Landing = () => {
	_s();
	const navigate = useNavigate();
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "landing-container",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "landing-content",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "landing-logo",
					children: "LEVI'S®"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 11,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("div", { className: "landing-divider" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 12,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("h2", {
					className: "landing-titulo",
					children: "DESDE 1853"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 13,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "landing-descripcion",
					children: [
						"Somos un almacén de ropa con más de 170 años vistiendo al mundo.",
						/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 15,
							columnNumber: 85
						}, this),
						"Jeans, chaquetas y accesorios con el estilo auténtico que nunca pasa de moda."
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 14,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("div", { className: "landing-divider" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 18,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "landing-slogan",
					children: "QUALITY NEVER GOES OUT OF STYLE."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 19,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: "btn-landing-login",
					onClick: () => navigate("/login"),
					children: "INGRESAR A LA TIENDA"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 20,
					columnNumber: 17
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 10,
			columnNumber: 13
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 9,
		columnNumber: 9
	}, this);
};
_s(Landing, "CzcTeTziyjMsSrAVmHuCCb6+Bfg=", false, function() {
	return [useNavigate];
});
_c = Landing;
export default Landing;
var _c;
$RefreshReg$(_c, "Landing");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/landing.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/landing.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/landing.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/landing.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsbUJBQW1CO0FBQzVCLE9BQU87Ozs7QUFFUCxNQUFNLGdCQUFnQjs7Q0FDbEIsTUFBTSxXQUFXLGFBQWE7QUFFOUIsUUFDSSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUNYLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFDSSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFlO0tBQWE7Ozs7O0lBQzNDLHdCQUFDLE9BQUQsRUFBSyxXQUFVLG1CQUFvQjs7Ozs7SUFDbkMsd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBaUI7S0FBZTs7Ozs7SUFDOUMsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBYjtNQUFtQztNQUNpQyx3QkFBQyxNQUFELEVBQU07Ozs7OztNQUV0RTs7Ozs7O0lBQ0osd0JBQUMsT0FBRCxFQUFLLFdBQVUsbUJBQW9COzs7OztJQUNuQyx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUFpQjtLQUFvQzs7Ozs7SUFDbEUsd0JBQUMsVUFBRDtLQUFRLE1BQUs7S0FBUyxXQUFVO0tBQW9CLGVBQWUsU0FBUyxTQUFTO2VBQUU7S0FFOUU7Ozs7O0lBQ1A7Ozs7OztFQUNKOzs7Ozs7Ozs7O0FBSWQsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJsYW5kaW5nLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xyXG5pbXBvcnQgJy4vTGFuZGluZy5jc3MnO1xyXG5cclxuY29uc3QgTGFuZGluZyA9ICgpID0+IHtcclxuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGFuZGluZy1jb250YWluZXJcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsYW5kaW5nLWNvbnRlbnRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGFuZGluZy1sb2dvXCI+TEVWSSdTwq48L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGFuZGluZy1kaXZpZGVyXCIgLz5cclxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJsYW5kaW5nLXRpdHVsb1wiPkRFU0RFIDE4NTM8L2gyPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibGFuZGluZy1kZXNjcmlwY2lvblwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFNvbW9zIHVuIGFsbWFjw6luIGRlIHJvcGEgY29uIG3DoXMgZGUgMTcwIGHDsW9zIHZpc3RpZW5kbyBhbCBtdW5kby48YnIgLz5cclxuICAgICAgICAgICAgICAgICAgICBKZWFucywgY2hhcXVldGFzIHkgYWNjZXNvcmlvcyBjb24gZWwgZXN0aWxvIGF1dMOpbnRpY28gcXVlIG51bmNhIHBhc2EgZGUgbW9kYS5cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGFuZGluZy1kaXZpZGVyXCIgLz5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImxhbmRpbmctc2xvZ2FuXCI+UVVBTElUWSBORVZFUiBHT0VTIE9VVCBPRiBTVFlMRS48L3A+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJidG4tbGFuZGluZy1sb2dpblwiIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKCcvbG9naW4nKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgSU5HUkVTQVIgQSBMQSBUSUVOREFcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBMYW5kaW5nOyJdfQ==