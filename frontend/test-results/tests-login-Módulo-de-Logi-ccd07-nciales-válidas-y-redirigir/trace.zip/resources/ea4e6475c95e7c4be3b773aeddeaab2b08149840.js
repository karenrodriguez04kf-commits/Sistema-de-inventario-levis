import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/login.jsx");import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=66677652"; const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];
import api from "/src/api.js";
import { useNavigate, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=66677652";
import "/src/Login.css";
var _jsxFileName = "C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/login.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=66677652"; const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
const Login = () => {
	_s();
	const [email, setEmail] = useState("");
	const [password, setPassword] = useState("");
	const navigate = useNavigate();
	const handleLogin = async (e) => {
		e.preventDefault();
		try {
			const res = await api.post("/auth/login", {
				email,
				password
			});
			if (res.data.Status === "Exito") {
				// Sanitización estricta para SonarQube
				const rawToken = res.data.Token;
				const rawRol = res.data.Rol;
				const rawId = res.data.id_usuario;
				// Validamos y sanitizamos el token (agregando un límite de longitud seguro)
				const safeToken = typeof rawToken === "string" && rawToken.trim() !== "" ? rawToken.trim().slice(0, 500) : "";
				// Validamos el rol (restringiendo estrictamente a valores permitidos)
				const safeRol = rawRol === "admin" || rawRol === "cliente" ? rawRol : "";
				// Sanitizamos el ID convirtiéndolo a entero seguro en texto
				const safeId = rawId !== null && rawId !== undefined && !isNaN(parseInt(rawId, 10)) ? String(parseInt(rawId, 10)) : "";
				// Condición de seguridad exigida por SonarQube para evitar almacenar datos taint sin validar
				if (safeToken && safeRol && safeId) {
					localStorage.setItem("token", safeToken);
					localStorage.setItem("rol", safeRol);
					localStorage.setItem("id_usuario", safeId);
					navigate(safeRol === "admin" ? "/home" : "/home/catalogo");
				} else {
					alert("Respuesta del servidor inválida o corrupta");
				}
			}
		} catch (err) {
			const mensaje = err.response?.data?.Message || "Error al conectar con el servidor";
			alert(mensaje);
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "login-container",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "login-box",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "login-logo",
				children: "LEVI'S"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 51,
				columnNumber: 17
			}, this), /* @__PURE__ */ _jsxDEV("form", {
				onSubmit: handleLogin,
				className: "login-form",
				children: [
					/* @__PURE__ */ _jsxDEV("input", {
						type: "email",
						placeholder: "EMAIL",
						onChange: (e) => setEmail(e.target.value),
						required: true
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 53,
						columnNumber: 21
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						type: "password",
						placeholder: "CONTRASEÑA",
						onChange: (e) => setPassword(e.target.value),
						required: true
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 54,
						columnNumber: 21
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						type: "submit",
						className: "btn-login",
						children: "INGRESAR"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 55,
						columnNumber: 21
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "login-footer",
						children: [
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								style: {
									color: "#666",
									fontSize: "13px"
								},
								children: "¿No tienes cuenta? "
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 58,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV(Link, {
								to: "/registro",
								className: "link-registro",
								children: "Regístrate aquí"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 59,
								columnNumber: 29
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 57,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV(Link, {
								to: "/recuperar",
								className: "link-recuperar",
								children: "¿Olvidaste tu contraseña?"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 61,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV(Link, {
								to: "/",
								className: "link-recuperar",
								children: "← Volver al inicio"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 62,
								columnNumber: 25
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 56,
						columnNumber: 21
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 52,
				columnNumber: 17
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 50,
			columnNumber: 13
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 49,
		columnNumber: 9
	}, this);
};
_s(Login, "c2wIto1x3gXhpzB0t7jZCju9+tI=", false, function() {
	return [useNavigate];
});
_c = Login;
export default Login;
var _c;
$RefreshReg$(_c, "Login");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/login.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/login.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/login.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/login.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxPQUFPLFNBQVM7QUFDaEIsU0FBUyxhQUFhLFlBQVk7QUFDbEMsT0FBTzs7OztBQUVQLE1BQU0sY0FBYzs7Q0FDaEIsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEdBQUc7Q0FDdEMsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLEdBQUc7Q0FDNUMsTUFBTSxXQUFXLGFBQWE7Q0FFOUIsTUFBTSxjQUFjLE9BQU8sTUFBTTtBQUM3QixJQUFFLGdCQUFnQjtBQUNsQixNQUFJO0dBQ0EsTUFBTSxNQUFNLE1BQU0sSUFBSSxLQUFLLGVBQWU7SUFBRTtJQUFPO0lBQVUsQ0FBQztBQUU5RCxPQUFJLElBQUksS0FBSyxXQUFXLFNBQVM7O0lBRTdCLE1BQU0sV0FBVyxJQUFJLEtBQUs7SUFDMUIsTUFBTSxTQUFTLElBQUksS0FBSztJQUN4QixNQUFNLFFBQVEsSUFBSSxLQUFLOztJQUd2QixNQUFNLFlBQWEsT0FBTyxhQUFhLFlBQVksU0FBUyxNQUFNLEtBQUssS0FBTSxTQUFTLE1BQU0sQ0FBQyxNQUFNLEdBQUcsSUFBSSxHQUFHOztJQUc3RyxNQUFNLFVBQVcsV0FBVyxXQUFXLFdBQVcsWUFBYSxTQUFTOztJQUd4RSxNQUFNLFNBQVUsVUFBVSxRQUFRLFVBQVUsYUFBYSxDQUFDLE1BQU0sU0FBUyxPQUFPLEdBQUcsQ0FBQyxHQUFJLE9BQU8sU0FBUyxPQUFPLEdBQUcsQ0FBQyxHQUFHOztBQUd0SCxRQUFJLGFBQWEsV0FBVyxRQUFRO0FBQ2hDLGtCQUFhLFFBQVEsU0FBUyxVQUFVO0FBQ3hDLGtCQUFhLFFBQVEsT0FBTyxRQUFRO0FBQ3BDLGtCQUFhLFFBQVEsY0FBYyxPQUFPO0FBRTFDLGNBQVMsWUFBWSxVQUFVLFVBQVUsaUJBQWlCO1dBQ3ZEO0FBQ0gsV0FBTSw2Q0FBNkM7OztXQUd0RCxLQUFLO0dBQ1YsTUFBTSxVQUFVLElBQUksVUFBVSxNQUFNLFdBQVc7QUFDL0MsU0FBTSxRQUFROzs7QUFJdEIsUUFDSSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUNYLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDSSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFhO0lBQVk7Ozs7YUFDeEMsd0JBQUMsUUFBRDtJQUFNLFVBQVU7SUFBYSxXQUFVO2NBQXZDO0tBQ0ksd0JBQUMsU0FBRDtNQUFPLE1BQUs7TUFBUSxhQUFZO01BQVEsV0FBVSxNQUFLLFNBQVMsRUFBRSxPQUFPLE1BQU07TUFBRTtNQUFXOzs7OztLQUM1Rix3QkFBQyxTQUFEO01BQU8sTUFBSztNQUFXLGFBQVk7TUFBYSxXQUFVLE1BQUssWUFBWSxFQUFFLE9BQU8sTUFBTTtNQUFFO01BQVc7Ozs7O0tBQ3ZHLHdCQUFDLFVBQUQ7TUFBUSxNQUFLO01BQVMsV0FBVTtnQkFBWTtNQUFpQjs7Ozs7S0FDN0Qsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDSSx3QkFBQyxPQUFELGFBQ0ksd0JBQUMsUUFBRDtRQUFNLE9BQU87U0FBRSxPQUFPO1NBQVEsVUFBVTtTQUFRO2tCQUFFO1FBQTBCOzs7O2lCQUM1RSx3QkFBQyxNQUFEO1FBQU0sSUFBRztRQUFZLFdBQVU7a0JBQWdCO1FBQXNCOzs7O2dCQUNuRTs7Ozs7T0FDTix3QkFBQyxNQUFEO1FBQU0sSUFBRztRQUFhLFdBQVU7a0JBQWlCO1FBQWdDOzs7OztPQUNqRix3QkFBQyxNQUFEO1FBQU0sSUFBRztRQUFJLFdBQVU7a0JBQWlCO1FBQXlCOzs7OztPQUMvRDs7Ozs7O0tBQ0g7Ozs7O1lBQ0w7Ozs7OztFQUNKOzs7Ozs7Ozs7O0FBSWQsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJsb2dpbi5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgYXBpIGZyb20gJy4vYXBpJztcclxuaW1wb3J0IHsgdXNlTmF2aWdhdGUsIExpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcclxuaW1wb3J0ICcuL0xvZ2luLmNzcyc7IC8vIEltcG9ydGFjacOzbiBkZWwgQ1NTXHJcblxyXG5jb25zdCBMb2dpbiA9ICgpID0+IHtcclxuICAgIGNvbnN0IFtlbWFpbCwgc2V0RW1haWxdID0gdXNlU3RhdGUoJycpO1xyXG4gICAgY29uc3QgW3Bhc3N3b3JkLCBzZXRQYXNzd29yZF0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XHJcblxyXG4gICAgY29uc3QgaGFuZGxlTG9naW4gPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkucG9zdCgnL2F1dGgvbG9naW4nLCB7IGVtYWlsLCBwYXNzd29yZCB9KTtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIGlmIChyZXMuZGF0YS5TdGF0dXMgPT09IFwiRXhpdG9cIikge1xyXG4gICAgICAgICAgICAgICAgLy8gU2FuaXRpemFjacOzbiBlc3RyaWN0YSBwYXJhIFNvbmFyUXViZVxyXG4gICAgICAgICAgICAgICAgY29uc3QgcmF3VG9rZW4gPSByZXMuZGF0YS5Ub2tlbjtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHJhd1JvbCA9IHJlcy5kYXRhLlJvbDtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHJhd0lkID0gcmVzLmRhdGEuaWRfdXN1YXJpbztcclxuXHJcbiAgICAgICAgICAgICAgICAvLyBWYWxpZGFtb3MgeSBzYW5pdGl6YW1vcyBlbCB0b2tlbiAoYWdyZWdhbmRvIHVuIGzDrW1pdGUgZGUgbG9uZ2l0dWQgc2VndXJvKVxyXG4gICAgICAgICAgICAgICAgY29uc3Qgc2FmZVRva2VuID0gKHR5cGVvZiByYXdUb2tlbiA9PT0gJ3N0cmluZycgJiYgcmF3VG9rZW4udHJpbSgpICE9PSAnJykgPyByYXdUb2tlbi50cmltKCkuc2xpY2UoMCwgNTAwKSA6ICcnO1xyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAvLyBWYWxpZGFtb3MgZWwgcm9sIChyZXN0cmluZ2llbmRvIGVzdHJpY3RhbWVudGUgYSB2YWxvcmVzIHBlcm1pdGlkb3MpXHJcbiAgICAgICAgICAgICAgICBjb25zdCBzYWZlUm9sID0gKHJhd1JvbCA9PT0gJ2FkbWluJyB8fCByYXdSb2wgPT09ICdjbGllbnRlJykgPyByYXdSb2wgOiAnJztcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgLy8gU2FuaXRpemFtb3MgZWwgSUQgY29udmlydGnDqW5kb2xvIGEgZW50ZXJvIHNlZ3VybyBlbiB0ZXh0b1xyXG4gICAgICAgICAgICAgICAgY29uc3Qgc2FmZUlkID0gKHJhd0lkICE9PSBudWxsICYmIHJhd0lkICE9PSB1bmRlZmluZWQgJiYgIWlzTmFOKHBhcnNlSW50KHJhd0lkLCAxMCkpKSA/IFN0cmluZyhwYXJzZUludChyYXdJZCwgMTApKSA6ICcnO1xyXG5cclxuICAgICAgICAgICAgICAgIC8vIENvbmRpY2nDs24gZGUgc2VndXJpZGFkIGV4aWdpZGEgcG9yIFNvbmFyUXViZSBwYXJhIGV2aXRhciBhbG1hY2VuYXIgZGF0b3MgdGFpbnQgc2luIHZhbGlkYXJcclxuICAgICAgICAgICAgICAgIGlmIChzYWZlVG9rZW4gJiYgc2FmZVJvbCAmJiBzYWZlSWQpIHtcclxuICAgICAgICAgICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgndG9rZW4nLCBzYWZlVG9rZW4pO1xyXG4gICAgICAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCdyb2wnLCBzYWZlUm9sKTtcclxuICAgICAgICAgICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnaWRfdXN1YXJpbycsIHNhZmVJZCk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIG5hdmlnYXRlKHNhZmVSb2wgPT09ICdhZG1pbicgPyAnL2hvbWUnIDogJy9ob21lL2NhdGFsb2dvJyk7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGFsZXJ0KFwiUmVzcHVlc3RhIGRlbCBzZXJ2aWRvciBpbnbDoWxpZGEgbyBjb3JydXB0YVwiKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgICBjb25zdCBtZW5zYWplID0gZXJyLnJlc3BvbnNlPy5kYXRhPy5NZXNzYWdlIHx8IFwiRXJyb3IgYWwgY29uZWN0YXIgY29uIGVsIHNlcnZpZG9yXCI7XHJcbiAgICAgICAgICAgIGFsZXJ0KG1lbnNhamUpO1xyXG4gICAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxvZ2luLWNvbnRhaW5lclwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxvZ2luLWJveFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsb2dpbi1sb2dvXCI+TEVWSSdTPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlTG9naW59IGNsYXNzTmFtZT1cImxvZ2luLWZvcm1cIj5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cImVtYWlsXCIgcGxhY2Vob2xkZXI9XCJFTUFJTFwiIG9uQ2hhbmdlPXtlID0+IHNldEVtYWlsKGUudGFyZ2V0LnZhbHVlKX0gcmVxdWlyZWQgLz5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInBhc3N3b3JkXCIgcGxhY2Vob2xkZXI9XCJDT05UUkFTRcORQVwiIG9uQ2hhbmdlPXtlID0+IHNldFBhc3N3b3JkKGUudGFyZ2V0LnZhbHVlKX0gcmVxdWlyZWQgLz5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBjbGFzc05hbWU9XCJidG4tbG9naW5cIj5JTkdSRVNBUjwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibG9naW4tZm9vdGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogJyM2NjYnLCBmb250U2l6ZTogJzEzcHgnIH19PsK/Tm8gdGllbmVzIGN1ZW50YT8gPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmsgdG89XCIvcmVnaXN0cm9cIiBjbGFzc05hbWU9XCJsaW5rLXJlZ2lzdHJvXCI+UmVnw61zdHJhdGUgYXF1w608L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8TGluayB0bz1cIi9yZWN1cGVyYXJcIiBjbGFzc05hbWU9XCJsaW5rLXJlY3VwZXJhclwiPsK/T2x2aWRhc3RlIHR1IGNvbnRyYXNlw7FhPzwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPExpbmsgdG89XCIvXCIgY2xhc3NOYW1lPVwibGluay1yZWN1cGVyYXJcIj7ihpAgVm9sdmVyIGFsIGluaWNpbzwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgTG9naW47Il19