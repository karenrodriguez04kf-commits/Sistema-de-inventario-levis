import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/registro.jsx");import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=66677652"; const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];
import api from "/src/api.js";
import { useNavigate, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=66677652";
import "/src/Registro.css";
var _jsxFileName = "C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/registro.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=66677652"; const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
const Registro = () => {
	_s();
	const [nombre, setNombre] = useState("");
	const [email, setEmail] = useState("");
	const [password, setPassword] = useState("");
	const navigate = useNavigate();
	const handleRegistro = async (e) => {
		e.preventDefault();
		try {
			const response = await api.post("/auth/register", {
				nombre,
				email,
				password
			});
			if (response.data.Status === "Exito") {
				alert("¡Usuario registrado con éxito en Levi's! ✅");
				navigate("/login");
			}
		} catch (error) {
			alert(error.response?.data?.Message || "Error al conectar con el servidor");
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "registro-container",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "registro-box",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "registro-logo",
				children: "LEVI'S"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 28,
				columnNumber: 17
			}, this), /* @__PURE__ */ _jsxDEV("form", {
				onSubmit: handleRegistro,
				className: "registro-form",
				children: [
					/* @__PURE__ */ _jsxDEV("input", {
						type: "text",
						placeholder: "NOMBRE COMPLETO",
						onChange: (e) => setNombre(e.target.value),
						required: true
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 30,
						columnNumber: 21
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						type: "email",
						placeholder: "EMAIL",
						onChange: (e) => setEmail(e.target.value),
						required: true
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 31,
						columnNumber: 21
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						type: "password",
						placeholder: "CONTRASEÑA",
						onChange: (e) => setPassword(e.target.value),
						required: true
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 32,
						columnNumber: 21
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						type: "submit",
						className: "btn-registro",
						children: "CREAR CUENTA"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 33,
						columnNumber: 21
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "registro-footer",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							style: {
								color: "#666",
								fontSize: "13px"
							},
							children: "¿Ya tienes cuenta? "
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 35,
							columnNumber: 25
						}, this), /* @__PURE__ */ _jsxDEV(Link, {
							to: "/login",
							className: "link-login",
							children: "Inicia sesión"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 36,
							columnNumber: 25
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 34,
						columnNumber: 21
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 29,
				columnNumber: 17
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 27,
			columnNumber: 13
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 26,
		columnNumber: 9
	}, this);
};
_s(Registro, "PjeQ+B+VWjx+BTLYf0BooOf2dcM=", false, function() {
	return [useNavigate];
});
_c = Registro;
export default Registro;
var _c;
$RefreshReg$(_c, "Registro");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/registro.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/registro.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/registro.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/registro.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxPQUFPLFNBQVM7QUFDaEIsU0FBUyxhQUFhLFlBQVk7QUFDbEMsT0FBTzs7OztBQUVQLE1BQU0saUJBQWlCOztDQUNuQixNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsR0FBRztDQUN4QyxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsR0FBRztDQUN0QyxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsR0FBRztDQUM1QyxNQUFNLFdBQVcsYUFBYTtDQUU5QixNQUFNLGlCQUFpQixPQUFPLE1BQU07QUFDaEMsSUFBRSxnQkFBZ0I7QUFDbEIsTUFBSTtHQUNBLE1BQU0sV0FBVyxNQUFNLElBQUksS0FBSyxrQkFBa0I7SUFBRTtJQUFRO0lBQU87SUFBVSxDQUFDO0FBQzlFLE9BQUksU0FBUyxLQUFLLFdBQVcsU0FBUztBQUNsQyxVQUFNLDZDQUE2QztBQUNuRCxhQUFTLFNBQVM7O1dBRWpCLE9BQU87QUFDWixTQUFNLE1BQU0sVUFBVSxNQUFNLFdBQVcsb0NBQW9DOzs7QUFJbkYsUUFDSSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUNYLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDSSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFnQjtJQUFZOzs7O2FBQzNDLHdCQUFDLFFBQUQ7SUFBTSxVQUFVO0lBQWdCLFdBQVU7Y0FBMUM7S0FDSSx3QkFBQyxTQUFEO01BQU8sTUFBSztNQUFPLGFBQVk7TUFBa0IsV0FBVSxNQUFLLFVBQVUsRUFBRSxPQUFPLE1BQU07TUFBRTtNQUFXOzs7OztLQUN0Ryx3QkFBQyxTQUFEO01BQU8sTUFBSztNQUFRLGFBQVk7TUFBUSxXQUFVLE1BQUssU0FBUyxFQUFFLE9BQU8sTUFBTTtNQUFFO01BQVc7Ozs7O0tBQzVGLHdCQUFDLFNBQUQ7TUFBTyxNQUFLO01BQVcsYUFBWTtNQUFhLFdBQVUsTUFBSyxZQUFZLEVBQUUsT0FBTyxNQUFNO01BQUU7TUFBVzs7Ozs7S0FDdkcsd0JBQUMsVUFBRDtNQUFRLE1BQUs7TUFBUyxXQUFVO2dCQUFlO01BQXFCOzs7OztLQUNwRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNJLHdCQUFDLFFBQUQ7T0FBTSxPQUFPO1FBQUUsT0FBTztRQUFRLFVBQVU7UUFBUTtpQkFBRTtPQUEwQjs7OztnQkFDNUUsd0JBQUMsTUFBRDtPQUFNLElBQUc7T0FBUyxXQUFVO2lCQUFhO09BQW9COzs7O2VBQzNEOzs7Ozs7S0FDSDs7Ozs7WUFDTDs7Ozs7O0VBQ0o7Ozs7Ozs7Ozs7QUFJZCxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbInJlZ2lzdHJvLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCBhcGkgZnJvbSAnLi9hcGknO1xyXG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSwgTGluayB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xyXG5pbXBvcnQgJy4vUmVnaXN0cm8uY3NzJztcclxuXHJcbmNvbnN0IFJlZ2lzdHJvID0gKCkgPT4ge1xyXG4gICAgY29uc3QgW25vbWJyZSwgc2V0Tm9tYnJlXSA9IHVzZVN0YXRlKCcnKTtcclxuICAgIGNvbnN0IFtlbWFpbCwgc2V0RW1haWxdID0gdXNlU3RhdGUoJycpO1xyXG4gICAgY29uc3QgW3Bhc3N3b3JkLCBzZXRQYXNzd29yZF0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XHJcblxyXG4gICAgY29uc3QgaGFuZGxlUmVnaXN0cm8gPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5wb3N0KCcvYXV0aC9yZWdpc3RlcicsIHsgbm9tYnJlLCBlbWFpbCwgcGFzc3dvcmQgfSk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5kYXRhLlN0YXR1cyA9PT0gXCJFeGl0b1wiKSB7XHJcbiAgICAgICAgICAgICAgICBhbGVydChcIsKhVXN1YXJpbyByZWdpc3RyYWRvIGNvbiDDqXhpdG8gZW4gTGV2aSdzISDinIVcIik7XHJcbiAgICAgICAgICAgICAgICBuYXZpZ2F0ZSgnL2xvZ2luJyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgICBhbGVydChlcnJvci5yZXNwb25zZT8uZGF0YT8uTWVzc2FnZSB8fCBcIkVycm9yIGFsIGNvbmVjdGFyIGNvbiBlbCBzZXJ2aWRvclwiKTtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWdpc3Ryby1jb250YWluZXJcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWdpc3Ryby1ib3hcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVnaXN0cm8tbG9nb1wiPkxFVkknUzwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVJlZ2lzdHJvfSBjbGFzc05hbWU9XCJyZWdpc3Ryby1mb3JtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgcGxhY2Vob2xkZXI9XCJOT01CUkUgQ09NUExFVE9cIiBvbkNoYW5nZT17ZSA9PiBzZXROb21icmUoZS50YXJnZXQudmFsdWUpfSByZXF1aXJlZCAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiZW1haWxcIiBwbGFjZWhvbGRlcj1cIkVNQUlMXCIgb25DaGFuZ2U9e2UgPT4gc2V0RW1haWwoZS50YXJnZXQudmFsdWUpfSByZXF1aXJlZCAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwicGFzc3dvcmRcIiBwbGFjZWhvbGRlcj1cIkNPTlRSQVNFw5FBXCIgb25DaGFuZ2U9e2UgPT4gc2V0UGFzc3dvcmQoZS50YXJnZXQudmFsdWUpfSByZXF1aXJlZCAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiIGNsYXNzTmFtZT1cImJ0bi1yZWdpc3Ryb1wiPkNSRUFSIENVRU5UQTwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVnaXN0cm8tZm9vdGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiAnIzY2NicsIGZvbnRTaXplOiAnMTNweCcgfX0+wr9ZYSB0aWVuZXMgY3VlbnRhPyA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIHRvPVwiL2xvZ2luXCIgY2xhc3NOYW1lPVwibGluay1sb2dpblwiPkluaWNpYSBzZXNpw7NuPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBSZWdpc3RybzsiXX0=