import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ReporteVentas.jsx");import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=66677652"; const React = __vite__cjsImport0_react; const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];
import api, { BASE_URL } from "/src/api.js";
import "/src/ReporteVentas.css";
var _jsxFileName = "C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/ReporteVentas.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=66677652"; const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
const ReporteVentas = () => {
	_s();
	const [ventas, setVentas] = useState([]);
	const [loading, setLoading] = useState(true);
	const [ventaAbierta, setVentaAbierta] = useState(null);
	useEffect(() => {
		const fetchVentas = async () => {
			try {
				const response = await api.get("/productos/ReporteVentas");
				const agrupadas = response.data.reduce((acc, venta) => {
					if (!acc[venta.id_venta]) {
						acc[venta.id_venta] = {
							id: venta.id_venta,
							fecha: venta.fecha,
							total: venta.total_venta,
							usuario: venta.nombre_usuario,
							email: venta.email_usuario,
							productos: []
						};
					}
					acc[venta.id_venta].productos.push(venta);
					return acc;
				}, {});
				setVentas(agrupadas);
			} catch (err) {
				console.error("Error al cargar reporte:", err);
			} finally {
				setLoading(false);
			}
		};
		fetchVentas();
	}, []);
	if (loading) return /* @__PURE__ */ _jsxDEV("div", {
		className: "rv-loading",
		children: "Cargando reporte de ventas..."
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 38,
		columnNumber: 25
	}, this);
	const ventasArray = Object.values(ventas).sort((a, b) => b.id - a.id);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "rv-container",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "rv-header",
			children: [/* @__PURE__ */ _jsxDEV("h2", {
				className: "rv-titulo",
				children: "REPORTE DE VENTAS"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 45,
				columnNumber: 17
			}, this), /* @__PURE__ */ _jsxDEV("span", {
				className: "rv-count",
				children: [ventasArray.length, " ventas registradas"]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 46,
				columnNumber: 17
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 44,
			columnNumber: 13
		}, this), ventasArray.length === 0 ? /* @__PURE__ */ _jsxDEV("p", {
			className: "rv-vacio",
			children: "No se han registrado ventas aún."
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 50,
			columnNumber: 17
		}, this) : /* @__PURE__ */ _jsxDEV("div", {
			className: "rv-lista",
			children: ventasArray.map((venta) => /* @__PURE__ */ _jsxDEV("div", {
				className: "rv-card",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: `rv-card-header ${ventaAbierta === venta.id ? "abierto" : ""}`,
					onClick: () => setVentaAbierta(ventaAbierta === venta.id ? null : venta.id),
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "rv-venta-id",
							children: ["#", venta.id]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 59,
							columnNumber: 33
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "rv-venta-usuario",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "rv-avatar",
								children: venta.usuario.charAt(0).toUpperCase()
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 61,
								columnNumber: 37
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "rv-usuario-info",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "rv-nombre",
									children: venta.usuario
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 63,
									columnNumber: 41
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "rv-email",
									children: venta.email
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 64,
									columnNumber: 41
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 62,
								columnNumber: 37
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 60,
							columnNumber: 33
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "rv-venta-meta",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "rv-fecha",
								children: new Date(venta.fecha).toLocaleDateString("es-CO", {
									day: "2-digit",
									month: "short",
									year: "numeric"
								})
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 68,
								columnNumber: 37
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "rv-productos-count",
								children: [venta.productos.length, " producto(s)"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 69,
								columnNumber: 37
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 67,
							columnNumber: 33
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "rv-total",
							children: [
								"$",
								Number(venta.total).toLocaleString(),
								" COP"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 71,
							columnNumber: 33
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "rv-chevron",
							children: ventaAbierta === venta.id ? "▲" : "▼"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 72,
							columnNumber: 33
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 55,
					columnNumber: 29
				}, this), ventaAbierta === venta.id && /* @__PURE__ */ _jsxDEV("div", {
					className: "rv-productos",
					children: [venta.productos.map((prod, i) => /* @__PURE__ */ _jsxDEV("div", {
						className: "rv-producto",
						children: [
							/* @__PURE__ */ _jsxDEV("img", {
								src: `${BASE_URL}${prod.imagen}`,
								alt: prod.nombreProducto,
								onError: (e) => e.target.src = "/img/placeholder.png"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 79,
								columnNumber: 45
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "rv-producto-info",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "rv-producto-nombre",
									children: prod.nombreProducto
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 85,
									columnNumber: 49
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "rv-producto-detalle",
									children: [
										"Cantidad: ",
										prod.cantidad,
										" × $",
										Number(prod.precioUnitario).toLocaleString()
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 86,
									columnNumber: 49
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 84,
								columnNumber: 45
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "rv-subtotal",
								children: ["$", Number(prod.cantidad * prod.precioUnitario).toLocaleString()]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 88,
								columnNumber: 45
							}, this)
						]
					}, i, true, {
						fileName: _jsxFileName,
						lineNumber: 78,
						columnNumber: 41
					}, this)), /* @__PURE__ */ _jsxDEV("div", {
						className: "rv-total-detalle",
						children: [/* @__PURE__ */ _jsxDEV("span", { children: "Total de la venta" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 92,
							columnNumber: 41
						}, this), /* @__PURE__ */ _jsxDEV("strong", { children: [
							"$",
							Number(venta.total).toLocaleString(),
							" COP"
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 93,
							columnNumber: 41
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 91,
						columnNumber: 37
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 76,
					columnNumber: 33
				}, this)]
			}, venta.id, true, {
				fileName: _jsxFileName,
				lineNumber: 54,
				columnNumber: 25
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 52,
			columnNumber: 17
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 43,
		columnNumber: 9
	}, this);
};
_s(ReporteVentas, "/XjzB+nRznN11yhBb2zIHWYfmTY=");
_c = ReporteVentas;
export default ReporteVentas;
var _c;
$RefreshReg$(_c, "ReporteVentas");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/ReporteVentas.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/ReporteVentas.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/ReporteVentas.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/ReporteVentas.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFdBQVcsZ0JBQWdCO0FBQzNDLE9BQU8sT0FBTyxnQkFBZ0I7QUFDOUIsT0FBTzs7OztBQUVQLE1BQU0sc0JBQXNCOztDQUN4QixNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsRUFBRSxDQUFDO0NBQ3hDLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxLQUFLO0NBQzVDLE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFTLEtBQUs7QUFFdEQsaUJBQWdCO0VBQ1osTUFBTSxjQUFjLFlBQVk7QUFDNUIsT0FBSTtJQUNBLE1BQU0sV0FBVyxNQUFNLElBQUksSUFBSSwyQkFBMkI7SUFDMUQsTUFBTSxZQUFZLFNBQVMsS0FBSyxRQUFRLEtBQUssVUFBVTtBQUNuRCxTQUFJLENBQUMsSUFBSSxNQUFNLFdBQVc7QUFDdEIsVUFBSSxNQUFNLFlBQVk7T0FDbEIsSUFBSSxNQUFNO09BQ1YsT0FBTyxNQUFNO09BQ2IsT0FBTyxNQUFNO09BQ2IsU0FBUyxNQUFNO09BQ2YsT0FBTyxNQUFNO09BQ2IsV0FBVyxFQUFFO09BQ2hCOztBQUVMLFNBQUksTUFBTSxVQUFVLFVBQVUsS0FBSyxNQUFNO0FBQ3pDLFlBQU87T0FDUixFQUFFLENBQUM7QUFDTixjQUFVLFVBQVU7WUFDZixLQUFLO0FBQ1YsWUFBUSxNQUFNLDRCQUE0QixJQUFJO2FBQ3hDO0FBQ04sZUFBVyxNQUFNOzs7QUFHekIsZUFBYTtJQUNkLEVBQUUsQ0FBQztBQUVOLEtBQUksUUFBUyxRQUFPLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWE7RUFBbUM7Ozs7O0NBRW5GLE1BQU0sY0FBYyxPQUFPLE9BQU8sT0FBTyxDQUFDLE1BQU0sR0FBRyxNQUFNLEVBQUUsS0FBSyxFQUFFLEdBQUc7QUFFckUsUUFDSSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBQ0ksd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNJLHdCQUFDLE1BQUQ7SUFBSSxXQUFVO2NBQVk7SUFBc0I7Ozs7YUFDaEQsd0JBQUMsUUFBRDtJQUFNLFdBQVU7Y0FBaEIsQ0FBNEIsWUFBWSxRQUFPLHNCQUEwQjs7Ozs7WUFDdkU7Ozs7O1lBRUwsWUFBWSxXQUFXLElBQ3BCLHdCQUFDLEtBQUQ7R0FBRyxXQUFVO2FBQVc7R0FBb0M7Ozs7YUFFNUQsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFDVixZQUFZLEtBQUksVUFDYix3QkFBQyxPQUFEO0lBQW9CLFdBQVU7Y0FBOUIsQ0FDSSx3QkFBQyxPQUFEO0tBQ0ksV0FBVyxrQkFBa0IsaUJBQWlCLE1BQU0sS0FBSyxZQUFZO0tBQ3JFLGVBQWUsZ0JBQWdCLGlCQUFpQixNQUFNLEtBQUssT0FBTyxNQUFNLEdBQUc7ZUFGL0U7TUFJSSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUE2QixLQUFFLE1BQU0sR0FBUzs7Ozs7O01BQzlDLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0ksd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWEsTUFBTSxRQUFRLE9BQU8sRUFBRSxDQUFDLGFBQWE7UUFBTzs7OztpQkFDeEUsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDSSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBYSxNQUFNO1NBQWU7Ozs7a0JBQ2xELHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFZLE1BQU07U0FBYTs7OztpQkFDN0M7Ozs7O2dCQUNKOzs7Ozs7TUFDTix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNJLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFZLElBQUksS0FBSyxNQUFNLE1BQU0sQ0FBQyxtQkFBbUIsU0FBUztTQUFFLEtBQUs7U0FBVyxPQUFPO1NBQVMsTUFBTTtTQUFXLENBQUM7UUFBUTs7OztpQkFDMUksd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWhCLENBQXNDLE1BQU0sVUFBVSxRQUFPLGVBQW1COzs7OztnQkFDOUU7Ozs7OztNQUNOLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQTBCO1FBQUUsT0FBTyxNQUFNLE1BQU0sQ0FBQyxnQkFBZ0I7UUFBQztRQUFVOzs7Ozs7TUFDM0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWMsaUJBQWlCLE1BQU0sS0FBSyxNQUFNO09BQVU7Ozs7O01BQ3ZFOzs7OztjQUVMLGlCQUFpQixNQUFNLE1BQ3BCLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDSyxNQUFNLFVBQVUsS0FBSyxNQUFNLE1BQ3hCLHdCQUFDLE9BQUQ7TUFBYSxXQUFVO2dCQUF2QjtPQUNJLHdCQUFDLE9BQUQ7UUFDSSxLQUFLLEdBQUcsV0FBVyxLQUFLO1FBQ3hCLEtBQUssS0FBSztRQUNWLFVBQVMsTUFBSyxFQUFFLE9BQU8sTUFBTTtRQUMvQjs7Ozs7T0FDRix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNJLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFzQixLQUFLO1NBQXNCOzs7O2tCQUNqRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBaEI7VUFBc0M7VUFBVyxLQUFLO1VBQVM7VUFBSyxPQUFPLEtBQUssZUFBZSxDQUFDLGdCQUFnQjtVQUFROzs7OztpQkFDdEg7Ozs7OztPQUNOLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFoQixDQUE4QixLQUFFLE9BQU8sS0FBSyxXQUFXLEtBQUssZUFBZSxDQUFDLGdCQUFnQixDQUFROzs7Ozs7T0FDbEc7UUFYSTs7OzthQVdKLENBQ1IsRUFDRix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNJLHdCQUFDLFFBQUQsWUFBTSxxQkFBd0I7Ozs7Z0JBQzlCLHdCQUFDLFVBQUQ7T0FBUTtPQUFFLE9BQU8sTUFBTSxNQUFNLENBQUMsZ0JBQWdCO09BQUM7T0FBYTs7OztlQUMxRDs7Ozs7Y0FDSjs7Ozs7YUFFUjtNQTNDSSxNQUFNOzs7O1dBMkNWLENBQ1I7R0FDQTs7OztXQUVSOzs7Ozs7Ozs7QUFJZCxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlJlcG9ydGVWZW50YXMuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgYXBpLCB7IEJBU0VfVVJMIH0gZnJvbSAnLi9hcGknO1xyXG5pbXBvcnQgJy4vUmVwb3J0ZVZlbnRhcy5jc3MnO1xyXG5cclxuY29uc3QgUmVwb3J0ZVZlbnRhcyA9ICgpID0+IHtcclxuICAgIGNvbnN0IFt2ZW50YXMsIHNldFZlbnRhc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcclxuICAgIGNvbnN0IFt2ZW50YUFiaWVydGEsIHNldFZlbnRhQWJpZXJ0YV0gPSB1c2VTdGF0ZShudWxsKTtcclxuXHJcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGZldGNoVmVudGFzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KCcvcHJvZHVjdG9zL1JlcG9ydGVWZW50YXMnKTtcclxuICAgICAgICAgICAgICAgIGNvbnN0IGFncnVwYWRhcyA9IHJlc3BvbnNlLmRhdGEucmVkdWNlKChhY2MsIHZlbnRhKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFhY2NbdmVudGEuaWRfdmVudGFdKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY1t2ZW50YS5pZF92ZW50YV0gPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogdmVudGEuaWRfdmVudGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmZWNoYTogdmVudGEuZmVjaGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3RhbDogdmVudGEudG90YWxfdmVudGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1c3VhcmlvOiB2ZW50YS5ub21icmVfdXN1YXJpbyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVtYWlsOiB2ZW50YS5lbWFpbF91c3VhcmlvLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvZHVjdG9zOiBbXVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBhY2NbdmVudGEuaWRfdmVudGFdLnByb2R1Y3Rvcy5wdXNoKHZlbnRhKTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gYWNjO1xyXG4gICAgICAgICAgICAgICAgfSwge30pO1xyXG4gICAgICAgICAgICAgICAgc2V0VmVudGFzKGFncnVwYWRhcyk7XHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGFsIGNhcmdhciByZXBvcnRlOlwiLCBlcnIpO1xyXG4gICAgICAgICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG4gICAgICAgIGZldGNoVmVudGFzKCk7XHJcbiAgICB9LCBbXSk7XHJcblxyXG4gICAgaWYgKGxvYWRpbmcpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInJ2LWxvYWRpbmdcIj5DYXJnYW5kbyByZXBvcnRlIGRlIHZlbnRhcy4uLjwvZGl2PjtcclxuXHJcbiAgICBjb25zdCB2ZW50YXNBcnJheSA9IE9iamVjdC52YWx1ZXModmVudGFzKS5zb3J0KChhLCBiKSA9PiBiLmlkIC0gYS5pZCk7XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJ2LWNvbnRhaW5lclwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJ2LWhlYWRlclwiPlxyXG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInJ2LXRpdHVsb1wiPlJFUE9SVEUgREUgVkVOVEFTPC9oMj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJ2LWNvdW50XCI+e3ZlbnRhc0FycmF5Lmxlbmd0aH0gdmVudGFzIHJlZ2lzdHJhZGFzPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHt2ZW50YXNBcnJheS5sZW5ndGggPT09IDAgPyAoXHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJydi12YWNpb1wiPk5vIHNlIGhhbiByZWdpc3RyYWRvIHZlbnRhcyBhw7puLjwvcD5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicnYtbGlzdGFcIj5cclxuICAgICAgICAgICAgICAgICAgICB7dmVudGFzQXJyYXkubWFwKHZlbnRhID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e3ZlbnRhLmlkfSBjbGFzc05hbWU9XCJydi1jYXJkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcnYtY2FyZC1oZWFkZXIgJHt2ZW50YUFiaWVydGEgPT09IHZlbnRhLmlkID8gJ2FiaWVydG8nIDogJyd9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRWZW50YUFiaWVydGEodmVudGFBYmllcnRhID09PSB2ZW50YS5pZCA/IG51bGwgOiB2ZW50YS5pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJydi12ZW50YS1pZFwiPiN7dmVudGEuaWR9PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJydi12ZW50YS11c3VhcmlvXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicnYtYXZhdGFyXCI+e3ZlbnRhLnVzdWFyaW8uY2hhckF0KDApLnRvVXBwZXJDYXNlKCl9PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicnYtdXN1YXJpby1pbmZvXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJydi1ub21icmVcIj57dmVudGEudXN1YXJpb308L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJydi1lbWFpbFwiPnt2ZW50YS5lbWFpbH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicnYtdmVudGEtbWV0YVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJydi1mZWNoYVwiPntuZXcgRGF0ZSh2ZW50YS5mZWNoYSkudG9Mb2NhbGVEYXRlU3RyaW5nKCdlcy1DTycsIHsgZGF5OiAnMi1kaWdpdCcsIG1vbnRoOiAnc2hvcnQnLCB5ZWFyOiAnbnVtZXJpYycgfSl9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJydi1wcm9kdWN0b3MtY291bnRcIj57dmVudGEucHJvZHVjdG9zLmxlbmd0aH0gcHJvZHVjdG8ocyk8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJydi10b3RhbFwiPiR7TnVtYmVyKHZlbnRhLnRvdGFsKS50b0xvY2FsZVN0cmluZygpfSBDT1A8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJ2LWNoZXZyb25cIj57dmVudGFBYmllcnRhID09PSB2ZW50YS5pZCA/ICfilrInIDogJ+KWvCd9PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dmVudGFBYmllcnRhID09PSB2ZW50YS5pZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJydi1wcm9kdWN0b3NcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3ZlbnRhLnByb2R1Y3Rvcy5tYXAoKHByb2QsIGkpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpfSBjbGFzc05hbWU9XCJydi1wcm9kdWN0b1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjPXtgJHtCQVNFX1VSTH0ke3Byb2QuaW1hZ2VufWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsdD17cHJvZC5ub21icmVQcm9kdWN0b31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25FcnJvcj17ZSA9PiBlLnRhcmdldC5zcmMgPSBcIi9pbWcvcGxhY2Vob2xkZXIucG5nXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJ2LXByb2R1Y3RvLWluZm9cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicnYtcHJvZHVjdG8tbm9tYnJlXCI+e3Byb2Qubm9tYnJlUHJvZHVjdG99PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJydi1wcm9kdWN0by1kZXRhbGxlXCI+Q2FudGlkYWQ6IHtwcm9kLmNhbnRpZGFkfSDDlyAke051bWJlcihwcm9kLnByZWNpb1VuaXRhcmlvKS50b0xvY2FsZVN0cmluZygpfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJydi1zdWJ0b3RhbFwiPiR7TnVtYmVyKHByb2QuY2FudGlkYWQgKiBwcm9kLnByZWNpb1VuaXRhcmlvKS50b0xvY2FsZVN0cmluZygpfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJydi10b3RhbC1kZXRhbGxlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5Ub3RhbCBkZSBsYSB2ZW50YTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+JHtOdW1iZXIodmVudGEudG90YWwpLnRvTG9jYWxlU3RyaW5nKCl9IENPUDwvc3Ryb25nPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgUmVwb3J0ZVZlbnRhczsiXX0=