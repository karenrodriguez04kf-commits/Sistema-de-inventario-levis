import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/bienvenida.jsx");import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=66677652"; const React = __vite__cjsImport0_react; const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=66677652";
import { jwtDecode } from "/node_modules/.vite/deps/jwt-decode.js?v=66677652";
import "/src/bienvenida.css";
var _jsxFileName = "C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/bienvenida.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=66677652"; const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
const Bienvenida = () => {
	_s();
	const [nombreUsuario, setNombreUsuario] = useState("");
	const [visible, setVisible] = useState(false);
	const navigate = useNavigate();
	useEffect(() => {
		const token = localStorage.getItem("token");
		if (token) {
			try {
				const decoded = jwtDecode(token);
				const displayUser = decoded.nombre || decoded.email || "USUARIO";
				setNombreUsuario(displayUser);
			} catch (error) {
				setNombreUsuario("USUARIO");
			}
		}
		setTimeout(() => setVisible(true), 100);
	}, []);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "bienvenida-container",
		children: [
			/* @__PURE__ */ _jsxDEV("div", { className: "neon-orb orb-1" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 28,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("div", { className: "neon-orb orb-2" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 29,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("div", { className: "neon-orb orb-3" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 30,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: `bienvenida-card ${visible ? "visible" : ""}`,
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bienvenida-badge",
						children: "LEVI'S®"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 33,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "bienvenida-saludo",
						children: "Bienvenid@,"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 35,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV("h1", {
						className: "bienvenida-nombre",
						children: nombreUsuario.toUpperCase()
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 36,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { className: "bienvenida-divider" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 37,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "bienvenida-subtexto",
						children: "Explora nuestra colección y encuentra tu estilo"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 38,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bienvenida-botones",
						children: /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => navigate("/home/catalogo"),
							className: "btn-catalogo",
							children: "VER CATÁLOGO →"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 43,
							columnNumber: 21
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 42,
						columnNumber: 17
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 32,
				columnNumber: 13
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 26,
		columnNumber: 9
	}, this);
};
_s(Bienvenida, "IxMJLE/KP5ZI9AdVGss0iFDn0XQ=", false, function() {
	return [useNavigate];
});
_c = Bienvenida;
export default Bienvenida;
var _c;
$RefreshReg$(_c, "Bienvenida");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/bienvenida.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/bienvenida.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/bienvenida.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/bienvenida.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFdBQVcsZ0JBQWdCO0FBQzNDLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsaUJBQWlCO0FBQzFCLE9BQU87Ozs7QUFFUCxNQUFNLG1CQUFtQjs7Q0FDckIsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQVMsR0FBRztDQUN0RCxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsTUFBTTtDQUM3QyxNQUFNLFdBQVcsYUFBYTtBQUU5QixpQkFBZ0I7RUFDWixNQUFNLFFBQVEsYUFBYSxRQUFRLFFBQVE7QUFDM0MsTUFBSSxPQUFPO0FBQ1AsT0FBSTtJQUNBLE1BQU0sVUFBVSxVQUFVLE1BQU07SUFDaEMsTUFBTSxjQUFjLFFBQVEsVUFBVSxRQUFRLFNBQVM7QUFDdkQscUJBQWlCLFlBQVk7WUFDeEIsT0FBTztBQUNaLHFCQUFpQixVQUFVOzs7QUFHbkMsbUJBQWlCLFdBQVcsS0FBSyxFQUFFLElBQUk7SUFDeEMsRUFBRSxDQUFDO0FBRU4sUUFDSSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBRUksd0JBQUMsT0FBRCxFQUFLLFdBQVUsa0JBQW1COzs7OztHQUNsQyx3QkFBQyxPQUFELEVBQUssV0FBVSxrQkFBbUI7Ozs7O0dBQ2xDLHdCQUFDLE9BQUQsRUFBSyxXQUFVLGtCQUFtQjs7Ozs7R0FFbEMsd0JBQUMsT0FBRDtJQUFLLFdBQVcsbUJBQW1CLFVBQVUsWUFBWTtjQUF6RDtLQUNJLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFtQjtNQUFhOzs7OztLQUUvQyx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBb0I7TUFBZTs7Ozs7S0FDaEQsd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQXFCLGNBQWMsYUFBYTtNQUFNOzs7OztLQUNwRSx3QkFBQyxPQUFELEVBQUssV0FBVSxzQkFBdUI7Ozs7O0tBQ3RDLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFzQjtNQUUvQjs7Ozs7S0FFSix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDWCx3QkFBQyxVQUFEO09BQVEsZUFBZSxTQUFTLGlCQUFpQjtPQUFFLFdBQVU7aUJBQWU7T0FFbkU7Ozs7O01BQ1A7Ozs7O0tBQ0o7Ozs7OztHQUNKOzs7Ozs7Ozs7OztBQUlkLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiYmllbnZlbmlkYS5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XHJcbmltcG9ydCB7IGp3dERlY29kZSB9IGZyb20gXCJqd3QtZGVjb2RlXCI7XHJcbmltcG9ydCAnLi9iaWVudmVuaWRhLmNzcyc7XHJcblxyXG5jb25zdCBCaWVudmVuaWRhID0gKCkgPT4ge1xyXG4gICAgY29uc3QgW25vbWJyZVVzdWFyaW8sIHNldE5vbWJyZVVzdWFyaW9dID0gdXNlU3RhdGUoJycpO1xyXG4gICAgY29uc3QgW3Zpc2libGUsIHNldFZpc2libGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xyXG5cclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgdG9rZW4gPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgndG9rZW4nKTtcclxuICAgICAgICBpZiAodG9rZW4pIHtcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IGRlY29kZWQgPSBqd3REZWNvZGUodG9rZW4pO1xyXG4gICAgICAgICAgICAgICAgY29uc3QgZGlzcGxheVVzZXIgPSBkZWNvZGVkLm5vbWJyZSB8fCBkZWNvZGVkLmVtYWlsIHx8ICdVU1VBUklPJztcclxuICAgICAgICAgICAgICAgIHNldE5vbWJyZVVzdWFyaW8oZGlzcGxheVVzZXIpO1xyXG4gICAgICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgICAgICAgc2V0Tm9tYnJlVXN1YXJpbygnVVNVQVJJTycpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0VmlzaWJsZSh0cnVlKSwgMTAwKTtcclxuICAgIH0sIFtdKTtcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmllbnZlbmlkYS1jb250YWluZXJcIj5cclxuICAgICAgICAgICAgey8qIEx1Y2VzIG5lb24gZGUgZm9uZG8gKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibmVvbi1vcmIgb3JiLTFcIiAvPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm5lb24tb3JiIG9yYi0yXCIgLz5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJuZW9uLW9yYiBvcmItM1wiIC8+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YGJpZW52ZW5pZGEtY2FyZCAke3Zpc2libGUgPyAndmlzaWJsZScgOiAnJ31gfT5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmllbnZlbmlkYS1iYWRnZVwiPkxFVkknU8KuPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiYmllbnZlbmlkYS1zYWx1ZG9cIj5CaWVudmVuaWRALDwvcD5cclxuICAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJiaWVudmVuaWRhLW5vbWJyZVwiPntub21icmVVc3VhcmlvLnRvVXBwZXJDYXNlKCl9PC9oMT5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmllbnZlbmlkYS1kaXZpZGVyXCIgLz5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImJpZW52ZW5pZGEtc3VidGV4dG9cIj5cclxuICAgICAgICAgICAgICAgICAgICBFeHBsb3JhIG51ZXN0cmEgY29sZWNjacOzbiB5IGVuY3VlbnRyYSB0dSBlc3RpbG9cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJpZW52ZW5pZGEtYm90b25lc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gbmF2aWdhdGUoJy9ob21lL2NhdGFsb2dvJyl9IGNsYXNzTmFtZT1cImJ0bi1jYXRhbG9nb1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBWRVIgQ0FUw4FMT0dPIOKGklxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEJpZW52ZW5pZGE7Il19