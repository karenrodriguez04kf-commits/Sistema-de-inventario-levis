import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/recuperar.jsx");import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=66677652"; const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];
import api from "/src/api.js";
import { useNavigate, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=66677652";
import "/src/Recuperar.css";
var _jsxFileName = "C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/recuperar.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=66677652"; const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
const Recuperar = () => {
	_s();
	const [email, setEmail] = useState("");
	const [codigo, setCodigo] = useState("");
	const [newPassword, setNewPassword] = useState("");
	const navigate = useNavigate();
	const handleRecuperar = async (e) => {
		e.preventDefault();
		if (codigo !== "123456") {
			alert("Código de verificación incorrecto. Usa 123456 (Modo de prueba)");
			return;
		}
		try {
			const res = await api.post("/auth/recuperar", {
				email,
				codigo,
				newPassword
			});
			if (res.data.Status === "Exito") {
				alert("¡Contraseña actualizada correctamente! ✅");
				navigate("/login");
			}
		} catch (err) {
			alert(err.response?.data?.Message || "Los datos no coinciden con nuestros registros o el servidor falló");
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "recuperar-container",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "recuperar-box",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "recuperar-logo",
					children: "LEVI'S"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 34,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("h2", {
					className: "recuperar-titulo",
					children: "RECUPERAR CONTRASEÑA"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 35,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("form", {
					onSubmit: handleRecuperar,
					className: "recuperar-form",
					children: [
						/* @__PURE__ */ _jsxDEV("input", {
							type: "email",
							placeholder: "CORREO ELECTRÓNICO",
							value: email,
							onChange: (e) => setEmail(e.target.value),
							required: true
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 38,
							columnNumber: 21
						}, this),
						/* @__PURE__ */ _jsxDEV("input", {
							type: "text",
							maxLength: "6",
							placeholder: "INGRESE CÓDIGO DE VERIFICACIÓN",
							value: codigo,
							onChange: (e) => setCodigo(e.target.value),
							style: {
								textAlign: "center",
								letterSpacing: "2px",
								fontFamily: "monospace"
							},
							required: true
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 46,
							columnNumber: 21
						}, this),
						/* @__PURE__ */ _jsxDEV("input", {
							type: "password",
							placeholder: "NUEVA CONTRASEÑA",
							value: newPassword,
							onChange: (e) => setNewPassword(e.target.value),
							required: true
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 56,
							columnNumber: 21
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							type: "submit",
							className: "btn-actualizar",
							children: "ACTUALIZAR CONTRASEÑA"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 64,
							columnNumber: 21
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "recuperar-footer",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								style: {
									color: "#666",
									fontSize: "13px"
								},
								children: "¿Recordaste tu clave? "
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 67,
								columnNumber: 25
							}, this), /* @__PURE__ */ _jsxDEV(Link, {
								to: "/login",
								className: "link-login",
								children: "Inicia sesión"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 68,
								columnNumber: 25
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 66,
							columnNumber: 21
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 37,
					columnNumber: 17
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 33,
			columnNumber: 13
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 32,
		columnNumber: 9
	}, this);
};
_s(Recuperar, "VOlxRdITjz1lee5nhZggQ6ZNJE8=", false, function() {
	return [useNavigate];
});
_c = Recuperar;
export default Recuperar;
var _c;
$RefreshReg$(_c, "Recuperar");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/recuperar.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/recuperar.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/recuperar.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Usuario/Desktop/rama mia/Sistema-de-inventario-levis/frontend/src/recuperar.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxPQUFPLFNBQVM7QUFDaEIsU0FBUyxhQUFhLFlBQVk7QUFDbEMsT0FBTzs7OztBQUVQLE1BQU0sa0JBQWtCOztDQUNwQixNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsR0FBRztDQUN0QyxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsR0FBRztDQUN4QyxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxHQUFHO0NBQ2xELE1BQU0sV0FBVyxhQUFhO0NBRTlCLE1BQU0sa0JBQWtCLE9BQU8sTUFBTTtBQUNqQyxJQUFFLGdCQUFnQjtBQUVsQixNQUFJLFdBQVcsVUFBVTtBQUNyQixTQUFNLGlFQUFpRTtBQUN2RTs7QUFHSixNQUFJO0dBQ0EsTUFBTSxNQUFNLE1BQU0sSUFBSSxLQUFLLG1CQUFtQjtJQUFFO0lBQU87SUFBUTtJQUFhLENBQUM7QUFDN0UsT0FBSSxJQUFJLEtBQUssV0FBVyxTQUFTO0FBQzdCLFVBQU0sMkNBQTJDO0FBQ2pELGFBQVMsU0FBUzs7V0FFakIsS0FBSztBQUNWLFNBQU0sSUFBSSxVQUFVLE1BQU0sV0FBVyxvRUFBb0U7OztBQUlqSCxRQUNJLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQ1gsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNJLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWlCO0tBQVk7Ozs7O0lBQzVDLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQW1CO0tBQXlCOzs7OztJQUUxRCx3QkFBQyxRQUFEO0tBQU0sVUFBVTtLQUFpQixXQUFVO2VBQTNDO01BQ0ksd0JBQUMsU0FBRDtPQUNJLE1BQUs7T0FDTCxhQUFZO09BQ1osT0FBTztPQUNQLFdBQVUsTUFBSyxTQUFTLEVBQUUsT0FBTyxNQUFNO09BQ3ZDO09BQ0Y7Ozs7O01BRUYsd0JBQUMsU0FBRDtPQUNJLE1BQUs7T0FDTCxXQUFVO09BQ1YsYUFBWTtPQUNaLE9BQU87T0FDUCxXQUFVLE1BQUssVUFBVSxFQUFFLE9BQU8sTUFBTTtPQUN4QyxPQUFPO1FBQUUsV0FBVztRQUFVLGVBQWU7UUFBTyxZQUFZO1FBQWE7T0FDN0U7T0FDRjs7Ozs7TUFFRix3QkFBQyxTQUFEO09BQ0ksTUFBSztPQUNMLGFBQVk7T0FDWixPQUFPO09BQ1AsV0FBVSxNQUFLLGVBQWUsRUFBRSxPQUFPLE1BQU07T0FDN0M7T0FDRjs7Ozs7TUFFRix3QkFBQyxVQUFEO09BQVEsTUFBSztPQUFTLFdBQVU7aUJBQWlCO09BQThCOzs7OztNQUUvRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNJLHdCQUFDLFFBQUQ7UUFBTSxPQUFPO1NBQUUsT0FBTztTQUFRLFVBQVU7U0FBUTtrQkFBRTtRQUE2Qjs7OztpQkFDL0Usd0JBQUMsTUFBRDtRQUFNLElBQUc7UUFBUyxXQUFVO2tCQUFhO1FBQW9COzs7O2dCQUMzRDs7Ozs7O01BQ0g7Ozs7OztJQUNMOzs7Ozs7RUFDSjs7Ozs7Ozs7OztBQUlkLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsicmVjdXBlcmFyLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCBhcGkgZnJvbSAnLi9hcGknO1xyXG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSwgTGluayB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xyXG5pbXBvcnQgJy4vUmVjdXBlcmFyLmNzcyc7XHJcblxyXG5jb25zdCBSZWN1cGVyYXIgPSAoKSA9PiB7XHJcbiAgICBjb25zdCBbZW1haWwsIHNldEVtYWlsXSA9IHVzZVN0YXRlKCcnKTtcclxuICAgIGNvbnN0IFtjb2RpZ28sIHNldENvZGlnb10gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgICBjb25zdCBbbmV3UGFzc3dvcmQsIHNldE5ld1Bhc3N3b3JkXSA9IHVzZVN0YXRlKCcnKTtcclxuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcclxuXHJcbiAgICBjb25zdCBoYW5kbGVSZWN1cGVyYXIgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICBcclxuICAgICAgICBpZiAoY29kaWdvICE9PSBcIjEyMzQ1NlwiKSB7XHJcbiAgICAgICAgICAgIGFsZXJ0KFwiQ8OzZGlnbyBkZSB2ZXJpZmljYWNpw7NuIGluY29ycmVjdG8uIFVzYSAxMjM0NTYgKE1vZG8gZGUgcHJ1ZWJhKVwiKTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLnBvc3QoJy9hdXRoL3JlY3VwZXJhcicsIHsgZW1haWwsIGNvZGlnbywgbmV3UGFzc3dvcmQgfSk7XHJcbiAgICAgICAgICAgIGlmIChyZXMuZGF0YS5TdGF0dXMgPT09IFwiRXhpdG9cIikge1xyXG4gICAgICAgICAgICAgICAgYWxlcnQoXCLCoUNvbnRyYXNlw7FhIGFjdHVhbGl6YWRhIGNvcnJlY3RhbWVudGUhIOKchVwiKTtcclxuICAgICAgICAgICAgICAgIG5hdmlnYXRlKCcvbG9naW4nKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgICBhbGVydChlcnIucmVzcG9uc2U/LmRhdGE/Lk1lc3NhZ2UgfHwgXCJMb3MgZGF0b3Mgbm8gY29pbmNpZGVuIGNvbiBudWVzdHJvcyByZWdpc3Ryb3MgbyBlbCBzZXJ2aWRvciBmYWxsw7NcIik7XHJcbiAgICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVjdXBlcmFyLWNvbnRhaW5lclwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlY3VwZXJhci1ib3hcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVjdXBlcmFyLWxvZ29cIj5MRVZJJ1M8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJyZWN1cGVyYXItdGl0dWxvXCI+UkVDVVBFUkFSIENPTlRSQVNFw5FBPC9oMj5cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVJlY3VwZXJhcn0gY2xhc3NOYW1lPVwicmVjdXBlcmFyLWZvcm1cIj5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXQgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJlbWFpbFwiIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkNPUlJFTyBFTEVDVFLDk05JQ09cIiBcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2VtYWlsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRFbWFpbChlLnRhcmdldC52YWx1ZSl9IFxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZCBcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIiBcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWF4TGVuZ3RoPVwiNlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiSU5HUkVTRSBDw5NESUdPIERFIFZFUklGSUNBQ0nDk05cIiBcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2NvZGlnb31cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0Q29kaWdvKGUudGFyZ2V0LnZhbHVlKX0gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHRleHRBbGlnbjogJ2NlbnRlcicsIGxldHRlclNwYWNpbmc6ICcycHgnLCBmb250RmFtaWx5OiAnbW9ub3NwYWNlJyB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZCBcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiTlVFVkEgQ09OVFJBU0XDkUFcIiBcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e25ld1Bhc3N3b3JkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXROZXdQYXNzd29yZChlLnRhcmdldC52YWx1ZSl9IFxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZCBcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiIGNsYXNzTmFtZT1cImJ0bi1hY3R1YWxpemFyXCI+QUNUVUFMSVpBUiBDT05UUkFTRcORQTwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVjdXBlcmFyLWZvb3RlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogJyM2NjYnLCBmb250U2l6ZTogJzEzcHgnIH19PsK/UmVjb3JkYXN0ZSB0dSBjbGF2ZT8gPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8TGluayB0bz1cIi9sb2dpblwiIGNsYXNzTmFtZT1cImxpbmstbG9naW5cIj5JbmljaWEgc2VzacOzbjwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgUmVjdXBlcmFyOyJdfQ==